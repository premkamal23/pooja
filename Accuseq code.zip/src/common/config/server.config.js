export default {
  "restServerOptions":{
    "host":"10.53.19.158",
    "port":"8080",
    "isSecure":false,
    "basePath":"/api/v1"
  }
}
