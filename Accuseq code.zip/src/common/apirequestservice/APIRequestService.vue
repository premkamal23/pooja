
<script src="./apiRequestService.component.js"></script>


