import configData from '../config/server.config';
import axios from 'axios';

export default {
    /**
     * Generic GET request endpoint any component can call
     */
    getApiRequest(path,success, error) {
        var http="";
        if(configData.restServerOptions.isSecure){
            http="https://"
        }else{
            http="http://"
        }
        var url=http+configData.restServerOptions.host+":"+configData.restServerOptions.port+
        configData.restServerOptions.basePath+path;
        axios.get(url).then(
            (response) => {
                success(response.data)
            },
            (response) => {
                error(response)
            }
        );
    },
    /**
     *  Generic POST request endpoint any component can call
     * required params :- path,data
     *
     */
    postApiRequest(path,data,success, error) {
        var http="";
        if(configData.restServerOptions.isSecure){
            http="https://"
        }else{
            http="http://"
        }
        var url=http+configData.restServerOptions.host+":"+configData.restServerOptions.port+
        configData.restServerOptions.basePath+path;
        axios.post(url,data).then(
            (response) => {
                success(response)
            }
        ).catch((errorData)=>error(errorData));
    }
}
