<template src="./esign-component.html"></template>
<script src="./esign-component.js"></script>
<style src="./esign-component.css"></style>