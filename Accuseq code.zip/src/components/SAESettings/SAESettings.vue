<template src="./sae-component.html"></template>
<script src="./sae-component.js"></script>
<style src="./sae-component.css"></style>