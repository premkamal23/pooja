<template src="./username-password-component.html"></template>
<script src="./username-password-component.js"></script>
<style src="./username-password-component.css"></style>