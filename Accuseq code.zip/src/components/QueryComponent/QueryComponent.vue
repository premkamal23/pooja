<template src="./query-component.html"></template>
<script src="./query-component.js"></script>
<style src="./query-component.css"></style>