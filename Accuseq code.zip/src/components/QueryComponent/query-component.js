export default ({
  data() {
    return {
    }
  },
  props: ['query'],

  created: function () {

  },
  methods: {
  }
})