import ApiRequestService from '../../common/apirequestservice/apiRequestService.component';
var userData = {
    'userId': 1,
    'username': '',
    'firstName': '',
    'lastName': '',
    'roles': [],
    'status': '',
    'eSign': false,
    'password': '',
    'confirmPassword': '',
    'passwordUpdated': false,
    'emailId': ''
}
export default ({
    data() {
        return {
            userDetails: userData,
            roles: '',
            categories: [],
            headers: [
                {
                    text: 'User Name',
                    sortable: true,
                    value: 'username'
                },
                { text: 'First Name', value: 'firstName' },
                { text: 'Last Name', value: 'lastName' },
                { text: 'Roles', value: 'roles' },
                { text: 'Status', value: 'status' },
                { text: 'E-Sign', value: 'esign' },
                { text: 'Updated On', value: 'modifiedDate' },
                { text: 'Actions', value: 'actions' }
            ]
        }
    },
    props: ['query'],

    created: function () {
        this.loadData();
    },
    methods: {
        loadData() {
            ApiRequestService.getApiRequest('/users', (response) => {
                this.categories = response;
            }, (error) => this.errors.push(error));
        },

        addUser() {
            this.$modal.show('input-focus-modal');
        },

        closeModal() {
            this.$modal.hide('input-focus-modal');
        },

        getRoles() {
            this.userDetails.roles.push(this.roles);
        },

        createNewUser() {
            this.getRoles();
            delete this.userDetails['userId'];
            console.log(this.userDetails);
            ApiRequestService.postApiRequest('/users/save', this.userDetails, (response) => {
                console.log(response);
                this.$modal.hide('input-focus-modal');
                this.loadData();
            });
        },

        checkstatus(event) {
            this.userDetails.eSign = event.target.checked;
        },
        editItem(props) {
            console.log(props);
            this.userDetails.userId = props.userId;
            this.userDetails.firstName = props.firstName;
            this.userDetails.lastName = props.lastName;
            this.userDetails.username = props.username;
            this.userDetails.status = props.status;
            this.userDetails.eSign = props.eSign;
            this.userDetails.passwordUpdated = props.passwordUpdated;
            this.userDetails.emailId = props.emailId;
            this.userDetails.roles[0] = props.roles[0];
            //this.$modal.show('input-focus-modal', this.userDetails);
        }
    }
})