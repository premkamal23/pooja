<template src="./tools-component.html"></template>
<script src="./tools-component.js"></script>
<style src="./tools-component.css"></style>