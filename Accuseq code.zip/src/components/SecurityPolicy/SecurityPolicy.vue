<template src="./security-component.html"></template>
<script src="./security-component.js"></script>
<style src="./security-component.css"></style>