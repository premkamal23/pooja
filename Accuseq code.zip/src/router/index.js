import Vue from 'vue'
import Router from 'vue-router'
import Vuetify from 'vuetify'

Vue.use(Router)
Vue.use(Vuetify)

function loadView(view) {
  return () => import(/* webpackChunkName: "view-[request]" */ `@/components/${view}/${view}.vue`)
}

export default new Router({
  routes: [
    {
      path: '/', component: loadView('QueryComponent')
    },
    {
      path: '/sae',
      component: loadView('QueryComponent'),
      children: [
        {
          path: "sae-settings",
          name: "sae-settings",
          component: loadView('SAESettings'),
          children: [
            {
              path: "security-policy",
              component: loadView('SecurityPolicy')
            }, {
              path: "username-password",
              component: loadView('UsernamePasswordComponent')
            }, {
              path: "esign",
              component: loadView('EsignComponent')
            }
          ]
        }, {
          path: "users",
          name: "users",
          component: loadView('UsersComponent')
        }, {
          path: "audit",
          name: "audit",
          component: loadView('AuditComponent')
        }, {
          path: "tools",
          name: "tools",
          component: loadView('ToolsComponent')
        }
      ]
    }
  ]
})
