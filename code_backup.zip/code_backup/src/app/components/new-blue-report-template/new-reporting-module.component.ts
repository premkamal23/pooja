import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ReportModuleService } from '../../common/services/report-module.service';
import { DialogService } from 'ng2-bootstrap-modal';
import { LogoBrowseComponent } from '../logo-list/logo-browse.component';
declare var $: any;

interface LType {
  logo1_name?: any;
  logo2_name?: any;
  path?: any;
  id?: any;
  description?: any;
  logo1_path?: any;
  logo2_path?: any;
}

@Component({
  selector: 'app-new-reporting-module',
  templateUrl: './new-reporting-module.component.html',
  styleUrls: ['./new-reporting-module.component.css']
})
export class NewReportingModuleComponent implements OnInit {
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  @Input() editdata: any;
  @Input() createReport: any;
  preview_boolean: boolean = true;
  report_sections: any;
  dropdownSettings = {};
  selectedItems = [];
  logoDetails: LType = {};
  data: any = {};
  selectedChange: any;
  logo1: any;
  logo2: string;
  editFlag: boolean = false;
  readonlyFlag: boolean = false;
  createReportFlag: any;
  errorMessage: string;
  parentCheckedStatus: boolean;
  errorList: Array<any>;
  templateText: boolean = false;
  testids_selected: boolean = false;
  constructor(
    private service: ReportModuleService,
    private dialogService: DialogService
  ) { }

  ngOnInit() {

    this.getLoadData();
  }

  ngAfterViewInit() {
    $(document).on("click", ".set-display", function (e) {
      e.stopPropagation();
    });

    $(document).click(function () {
      $('.set-display').removeClass('set-display');
    });

    this.getDataOnChange();
  }

  ngOnDestroy() {
    this.editdata = {};
    this.data = {};
    // this.report_sections= {};
  }

  getDataOnChange() {
    if (this.editdata && this.createReport === false) {
      if (this.editdata.specimen_details.receive_date) {
        this.editdata.specimen_details.receive_date = this.convertToDateFormat(this.editdata.specimen_details.receive_date);
      }
      if (this.editdata.specimen_details.report_date) {
        this.editdata.specimen_details.report_date = this.convertToDateFormat(this.editdata.specimen_details.report_date);
      }
      if (this.editdata.specimen_details.collection_date) {
        this.editdata.specimen_details.collection_date = this.convertToDateFormat(this.editdata.specimen_details.collection_date);
      }
      if (this.editdata.patient_details.patient_dob) {
        this.editdata.patient_details.patient_dob = this.convertToDateFormat(this.editdata.patient_details.patient_dob);
      }
      this.data = this.editdata;
      this.report_sections = this.editdata.label_list;
      this.editFlag = true;
      this.logo1 = this.editdata.logo1_path;
      this.logo2 = this.editdata.logo2_path;
      //this.preview_boolean = true;
    }
    else {
      //this.getLoadData();
      this.service.getReportSections().subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        if (response.data.specimen_details.receive_date) {
          response.data.specimen_details.receive_date = this.convertToDateFormat(response.data.specimen_details.receive_date);
        }
        if (response.data.specimen_details.report_date) {
          response.data.specimen_details.report_date = this.convertToDateFormat(response.data.specimen_details.report_date);
        }
        if (response.data.specimen_details.collection_date) {
          response.data.specimen_details.collection_date = this.convertToDateFormat(response.data.specimen_details.collection_date);
        }
        if (response.data.patient_details.patient_dob) {
          response.data.patient_details.patient_dob = this.convertToDateFormat(response.data.patient_details.patient_dob);
        }
        this.data = response.data;
        this.report_sections = response.data.label_list;
      });
    }
  }

  getLoadData() {
    this.getreportingSections();
    this.dropdownSettings = {
      text: "Select Details",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: "myclass custom-class",
      textField: 'id',
      labelKey: 'label'
    };
  }


  convertToDateFormat(rdate) {
    var d = new Date(rdate);
    return d;
  }

  getreportingSections() {
    if (this.editdata) {
      if (this.editdata.specimen_details && this.editdata.specimen_details.receive_date) {
        this.editdata.specimen_details.receive_date = this.convertToDateFormat(this.editdata.specimen_details.receive_date);
      }
      if (this.editdata.specimen_details && this.editdata.specimen_details.report_date) {
        this.editdata.specimen_details.report_date = this.convertToDateFormat(this.editdata.specimen_details.report_date);
      }
      if (this.editdata.specimen_details && this.editdata.specimen_details.collection_date) {
        this.editdata.specimen_details.collection_date = this.convertToDateFormat(this.editdata.specimen_details.collection_date);
      }
      if (this.editdata.patient_details && this.editdata.patient_details.patient_dob) {
        this.editdata.patient_details.patient_dob = this.convertToDateFormat(this.editdata.patient_details.patient_dob);
      }

      this.data = this.editdata;
      this.report_sections = this.editdata.label_list;
    } else {
      this.service.getReportSections().subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        if (this.editdata.specimen_details && response.data.specimen_details.receive_date) {
          response.data.specimen_details.receive_date = this.convertToDateFormat(response.data.specimen_details.receive_date);
        }
        if (this.editdata.specimen_details && response.data.specimen_details.report_date) {
          response.data.specimen_details.report_date = this.convertToDateFormat(response.data.specimen_details.report_date);
        }
        if (this.editdata.specimen_details && response.data.specimen_details.collection_date) {
          response.data.specimen_details.collection_date = this.convertToDateFormat(response.data.specimen_details.collection_date);
        }
        if (this.editdata.patient_details && response.data.patient_details.patient_dob) {
          response.data.patient_details.patient_dob = this.convertToDateFormat(response.data.patient_details.patient_dob);
        }
        this.data = response.data;
        this.report_sections = response.data.label_list;
      });
    }
  }

  getPreviewWindow() {
    this.preview_boolean = true;
  }

  setItem(event, label, child, childArr) {
    let newLabel = label.slice(5);
    if (this.data) {
      let val = event.target.value;
      this.data[newLabel][event.target.value] = event.target.checked;
      const id = this.report_sections.findIndex(x => x.id === label);
      const c_id = this.report_sections[id].children.findIndex(x => x.id === child);
      this.report_sections[id].children[c_id].flag = event.target.checked;
    }
    if (this.data[newLabel]) {
      for (var i in this.data[newLabel]) {
        if (this.data[newLabel][i])
          this.data[label] = true;
        break;
      }
    }

    let val: boolean = true;
    for (var key in childArr) {
      if (this.report_sections.hasOwnProperty(key)) {
        if (childArr[key].flag === false) {
          val = false;
        }
      }
    }
    if (val) {
      $('#selectall_' + label).prop("checked", true);
    } else {
      $('#selectall_' + label).prop("checked", false);
    }
  }

  setParentItem(event, sectionArr) {
    let newStr = event.target.value;
    this.data[newStr] = event.target.checked;
    let chekcedFlag = true;

    for (var i in sectionArr) {
      if (sectionArr[i].flag === false) {
        chekcedFlag = false;
      }
    }
    if (chekcedFlag) {
      $('#selectAllReportSection').prop("checked", true);
    } else {
      $('#selectAllReportSection').prop("checked", false);
    }
  }

  selectLogo(position) {
    this.dialogService.addDialog(LogoBrowseComponent, {})
      .subscribe((response: any) => {
        if (response) {
          if (position === 'left') {
            this.logoDetails = response;
            this.data.logo1_path = response.path;
            this.data.logo1_name = response.name;
            this.logo1 = response.name;
          } else {
            this.logoDetails = response;
            this.data.logo2_path = response.path;
            this.data.logo2_name = response.name;
            this.logo2 = response.name;
          }
        }
      });

  }

  removeLogo(position) {
    this.data.logo1_path = position === 'left' ? null : this.data.logo1_path;
    this.data.logo2_path = position === 'right' ? null : this.data.logo2_path;
  }

  onNotify(message: string): void {
    this.getLoadData();
    this.preview_boolean = false;
    this.data = {};
    this.report_sections = [];
    this.notify.emit('Success');
  }

  setReprotsection(sectionName, value) {
    
  }

  selectAllCheckboxes(event) {
    for (var key in this.report_sections) {
      if (this.report_sections.hasOwnProperty(key)) {
        var val = this.report_sections[key];
        this.report_sections[key].flag = event.target.checked;
        this.data[this.report_sections[key].id] = event.target.checked;
      }
    }
  }

  selectAllTreeviewCheckboxes(event, arrChild, label) {
    for (var key in arrChild) {
      arrChild[key].flag = event.target.checked;
      let childKey = arrChild[key].id;
      let str = arrChild[key].label;
      let newStr = str.replace(/\s/g, "_");
      let id = arrChild[key].id;
      let newLabel = label.slice(5);
      if (this.data) {
        this.data[newLabel][childKey] = event.target.checked;
      }
      if (this.data[newLabel]) {
        for (var i in this.data[newLabel]) {
          if (this.data[newLabel][i])
            this.data[label] = event.target.checked;
          break;
        }
      }
    }
  }

  setParentFlag(event, id, sectionArr) {
    event.stopPropagation();
    this.data[id] = event.target.checked;
    this.readonlyFlag = this.readonlyFlag + id;
    if (event.target.checked) {
      $('.set-display').removeClass('set-display');
      $('.' + id).addClass('set-display');
      //   $('#sec_' + id).removeAttr('readonly');
    } else {
      $('#sec_' + id).attr('readonly', 'readonly');
      $('.set-display').removeClass('set-display');
    }
    if (event.target.checked) {
      this.parentCheckedStatus = true;
    } else {
      this.parentCheckedStatus = false;
    }

    let chekcedFlag = true;
    for (var i in sectionArr) {
      if (sectionArr[i].flag === false) {
        chekcedFlag = false;
      }
    }
    if (chekcedFlag) {
      $('#selectAllReportSection').prop("checked", true);
    } else {
      $('#selectAllReportSection').prop("checked", false);
    }
  }

  setParentFlagInput(event, id) {
    //event.stopPropagation();
    // this.data[id] = event.target.checked;
    this.readonlyFlag = this.readonlyFlag + id;
    const parentStatus = $('#' + id).is(':checked');
    setTimeout(function () {
      if (parentStatus) {
        $('.' + id).addClass('set-display');
      }
    }, 0);
  }

  hideDisplay() {
    $('.set-display').removeClass('set-display');
  }


  checkForDefault() {
    if (this.data.id.toLowerCase() === 'default') {
      this.errorMessage = "Report template with name 'DEFAULT' already exists and cannot be created.";
      $('#errorReportAlert').modal('toggle');
    }
  }
}

