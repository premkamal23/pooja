import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {

  isUserActive = false;
  isRoleActive = false;
  isClientActive = true;
  constructor(private router: Router) { }

  ngOnInit() {
    this.router.navigate(['app/user-management/clients']);
  }

  getRolesBoard() {
    
    this.router.navigate(['app/user-management/roles']);
    this.isRoleActive = true;
    this.isUserActive = false;
    this.isClientActive = false;
  }

  getUserBoard() {
    this.router.navigate(['app/user-management/users']);
    this.isRoleActive = false;
    this.isUserActive = true;
    this.isClientActive = false;
  }

  getClientBoard() {
    this.router.navigate(['app/user-management/clients']);
    this.isClientActive = true;
    this.isRoleActive = false;
    this.isUserActive = false;
  }

}
