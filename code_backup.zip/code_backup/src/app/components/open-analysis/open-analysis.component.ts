import { Component, OnInit, ViewChild } from '@angular/core';
import { OpenAnalysisService } from '../../common/services/open-analysis.service';
import { ProjectService } from '../../common/services/project.service';
import { AcmgCalculatorComponent } from '../acmg-calculator/acmg-calculator.component';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DialogService } from 'ng2-bootstrap-modal';
import { ModalComponentComponent } from '../modal-component/modal-component.component';
import { merge, cloneDeep } from 'lodash';
import { DomSanitizer } from '@angular/platform-browser';
import { ReportTemplateService } from '../../common/services/report-template.service';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { ReportModuleService } from '../../common/services/report-module.service';
import { ClinicalNotesService } from '../../common/services/clinical-notes.service';
import { VariantsForSectionComponent } from '../variants-for-section/variants-for-section.component';
import { AddVariantAnalysisComponent } from '../add-variant-analysis/add-variant-analysis.component';
declare var $: any;

@Component({
  selector: 'app-open-analysis',
  templateUrl: './open-analysis.component.html',
  styleUrls: ['./open-analysis.component.css']
})
export class OpenAnalysisComponent implements OnInit {
  checkTestMessage: any;
  analysis_id: string;
  ACMGOutput: any;
  firstRecord = 0;
  acmgFlag = false;
  savevariant = false;
  saveSelectedRow: any;
  selectedrow: any;
  defaultData: any = {};
  nofilterData: any = {};
  reportData: any = {};
  dataPayload: any;
  filter = '00';
  dashboardData: any;
  selectedRow: any;
  lowerPanelContentLength = 0;
  filterArray: Array<any> = [];
  variants_marked_for_hide = [];
  filterName = 'New Filter';
  filters: any;
  appliedFilter: any;
  popupMsg: string;
  rowData: any;
  refiningFilter: string; // = 'Default Filter';
  selectedRefiningFilter: any;
  filterPopUp = false;
  flag = false;
  finalObj: any = {};
  initialPage = 1;
  totalRecords = 0;
  Gridcontent: any[] = [];
  lowerPanelContent: any;
  altFieldValue: number;
  boolClinical = false;
  boolSanger = false;
  dataChange = false;
  gene_class = 'GCD';
  location = 'NON-UTR';
  columnId = 'gene';
  sortdir = 'asc';
  report_notes = '';
  sample_flag = false;
  filterSaveError = false;
  filterSaveErrorMessage = '';
  filterSaveSuccess = false;
  deleteFilterError = false;
  mark_for_hidden = false;
  globalElement: any = {
    'analysis_id': '1',
    'gene_class': this.gene_class,
    'location': this.location,
    'sub_type': '00',
    'isEdit': this.flag,
    'sample_flag': this.sample_flag,
    'analysis_id_for_count': 1
  };

  filterData = {
    analysis_id: this.analysis_id,
    gene_class: this.gene_class,
    location: this.location,
    filter: this.filter
  };

  acmgDetails: any = {
    'acmgData': this.ACMGOutput
  };

  analysisData: any = {
    analysis_id: this.analysis_id
  }
  boolEdit = false;
  boolDisplay = false;
  boolSave = false;
  boolPopOver = false;
  boolPaginate = false;
  boolOther = false;
  alert = false;
  showSaveAlert = false;
  success = false;
  refstatus = false;
  altstatus = false;
  chromstatus = false;
  startStatus = false;
  stopstatus = false;
  sample_boolean = false;
  hide_boolean = false;
  id: number;
  hidden_count: number;
  hidden_boolean: boolean = false;
  refiningFilterList: Array<any>;
  newFilterPayload: any;
  tempPayload: any;
  filterApplied = false;
  editedVariants = [];
  filterList: any;
  client_list: any;
  client_ids = [];
  filterPayload: any;
  clinical_report: string;
  clinical_report_dialogue: string;
  defaultFilterList = [
    'Default Filter',
    'No Filter',
    'New Filter',
    'All Variants Marked for Report',
    'All Variants Marked for Analysis',
    'All Variants Marked for Hold Report',
    'All Variants Marked for Sanger Required',
    'All Variants Marked for Sanger Confirmed',
    'All Variants Marked as Hidden'
  ];
  newGridData: any;
  analysis_name: string;
  API_END_POINT = '/api/variants';
  saveFilterUrl = '/api/filter';
  refiningFilterUrl = '/api/refiningFilter';
  variantUrl = '/api/variant';
  variantUrlForSingleDeselect = '/api/variant/deselectSingleShowHidden';
  acmgUrl = '/api/acmgResult';
  totalElements = 0;
  totalPages = 0;
  urlParams: any = {
    analysis_id: '1',
    gene_class: 'GCD',
    location: 'NON-UTR',
    sortBy: 'gene',
    sortDir: 'asc',
    sub_type: '00',
    offset: 0,
    limit: 15
  };
  session: any;
  apiResponse: any;
  markForAnalysis: any;
  resetPagination = true;
  callback: Function;
  refiningFilters: any;
  selectedRowData = { chrom: '', genomic_start: '', genomic_stop: '', analysisId: '-1' };
  jBrowseUrl: any = '';
  sampleNotes: string = '';
  selectedFilterId: any = null;
  customFilterSelected = false;
  addVariantPermissions = false;
  navigateGene = false;
  edit_clinical_report: boolean = false;
  view_analysis: boolean = false;
  edit_analysis: boolean = false;
  pki_class_list: any;
  clinical_notes_list: any;
  navigateVariant = false;
  CkeditorConfig_new = {
    allowedContent: true,
    height: 100,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    title: false,
    fontSize_defaultLabel: '11',
    extraPlugins: "divarea",
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };
  CkeditorConfig = {
    allowedContent: true,
    height: 100,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    fontSize_defaultLabel: '11',
    extraPlugins: "divarea",
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };
  NotesCkeditorConfig = {
    allowedContent: true,
    height: 510,
    resize_enabled: false,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker,JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock'
  };
  selectedGene: any;
  scrollHeight: string = '100px';
  hideClickFlag: boolean = false;
  @ViewChild("ckeditor") ckeditor: any;
  rowChangeCount: any = 1;
  saveFlag: boolean = false;
  rowchangeNewFlag: boolean = false;
  alertCount: any = 0;
  notesSectionClicked: boolean = false;

  constructor(
    private openanalysisService: OpenAnalysisService,
    private router: Router,
    private http: HttpClient,
    private dialogService: DialogService,
    private route: ActivatedRoute,
    public sanitizer: DomSanitizer,
    private reportTemplateService: ReportTemplateService,
    private dashboard: DashboardComponent,
    private service: ProjectService,
    private notesService: ClinicalNotesService,
    private reportService: ReportModuleService
  ) {
    this.session = sessionStorage;
    this.callback = this.getData;
  }

  ngOnInit() {
    const permissions = sessionStorage.getItem('permissions').split(',');
    this.addVariantPermissions = permissions.includes('ADD_NEW_VARIANT') ? true : false;
    this.navigateVariant = permissions.includes('VIEW_MASTER_VARIANT_TABLE') ? true : false;
    this.navigateGene = permissions.includes('VIEW_MASTER_GENE_TABLE') ? true : false;
    this.edit_clinical_report = permissions.includes('EDIT_CLINICAL_REPORT_DATA') ? true : false;
    this.view_analysis = permissions.includes('VIEW_ANALYSIS') ? true : false;
    this.edit_analysis = permissions.includes('EDIT_ANALYSIS') ? true : false;
    this.analysis_id = this.route.snapshot.paramMap.get('analysis_id');
    this.globalElement.analysis_id_for_count = this.analysis_id;
    this.getSubtype(this.location);
    this.jBrowseUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.jBrowseUrl);
    this.http.get('/api/analysis/' + this.analysis_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.analysis_name = response.data.name;
    });
    this.globalElement.analysis_id = this.route.snapshot.paramMap.get('analysis_id');
    this.getAllSavedFilters();
    this.getClientIDs();
    this.getHiddenVariantCount();
    this.getPkiClass();
    this.getClinicalNotes();
  }

  on() {
    document.getElementById("overlay").style.display = "block";
  }

  off() {
    document.getElementById("overlay").style.display = "none";
  }

  onReady($event: any): void {
    if (this.ckeditor) {
      this.ckeditor.instance.setData(this.selectedRow);
    }
  }

  getPkiClass() {
    this.service.getPKIClass().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.pki_class_list = response.data.content;
    });
  }

  getHiddenVariantCount() {
    this.openanalysisService.getHiddenDataCount(this.analysis_id, this.gene_class, this.location, this.filter)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.hidden_count = response.data;
        this.hidden_boolean = this.hidden_count !== 0 ? true : false;
      });
  }

  getClientIDs() {
    const user_id = sessionStorage.getItem('user_id');
    this.http.get('/api/client/user/' + user_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.client_ids = [];
      this.client_list = response.data;
      this.client_list.forEach(ids => {
        this.client_ids = this.client_ids.concat(ids.id);
      });
    });
  }

  closeAlert() {
    this.success = false;
    this.selectedRow = this.selectedrow;
  }

  getSubtype(location) {
    this.openanalysisService.getSubTypeData(location).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.filterList = response.data;
    });
  }

  setGene(var1, var2) {
    this.mark_for_hidden = false;
    this.defaultData = {
      priority: 'high'
    };
    if (var1) {
      this.urlParams.gene_class = var2;
      this.gene_class = var2;
      this.globalElement.gene_class = var2;
    } else {
      this.urlParams.location = var2;
      this.location = var2;
      this.globalElement.location = var2;
      this.getSubtype(var2);
    }
    this.getHiddenVariantCount();
    this.callback = this.getPostData;
    this.urlParams.offset = 0;
    this.firstRecord = 0;
    this.resetPagination = true;
    this.filter = '00';
    this.refiningFilter = 'Default Filter';
    this.callback();
  }

  getData() {
    const url = this.getParameterizedUrl();
    return this.http.get(url).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.apiResponse = data.data.variants;
      this.sampleNotes = data.data.sample_level_note;
      this.apiResponse.content.map(response => {
        response.chromosome = response.chrom;
        response.start = response.genomic_start;
        response.stop = response.genomic_stop;
        return response;
      });
      this.selectedRow = data.data.variants.content[0];
      this.totalRecords = this.apiResponse.totalElements;
      this.Gridcontent = [...this.apiResponse.content];
      this.getHiddenVariantCount();
    });
  }

  getPostData() { // post api
    const url = this.getParameterizedUrl();
    return this.http.post(url, this.defaultData).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.apiResponse = data.data.variants;
      this.sampleNotes = data.data.sample_level_note;
      this.apiResponse.content.map(response => {
        response.chromosome = response.chrom;
        response.start = response.genomic_start;
        response.stop = response.genomic_stop;
        return response;
      });
      this.selectedRow = data.data.variants.content[0];
      this.totalRecords = this.apiResponse.totalElements;
      this.Gridcontent = [...this.apiResponse.content];
      this.getHiddenVariantCount();
    });
  }

  getClinicalNotes() {
    this.notesService.getClinicalNotes().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.clinical_notes_list = response.data;
    });
  }

  getClinicalReports() {
    if (this.selectedRow.clinical_report_data.report_notes !== '') {
      this.selectedRow.clinical_report_data.report_notes = this.selectedRow.clinical_report_data.report_notes + this.clinical_report
    } else {
      this.selectedRow.clinical_report_data.report_notes = this.clinical_report;
    }
    this.notesSectionClicked = true;
    this.alert = true;
    this.onChangeOfNotesTemplate();
    this.clinical_report = "0: undefined";
  }

  getClinicalReportsOnNotesDialogue() {
    if (this.report_notes !== '') {
      this.report_notes = this.report_notes + this.clinical_report_dialogue;
    } else {
      this.report_notes = this.clinical_report_dialogue;
    }
  }

  getFilterData() {
    this.mark_for_hidden = false;
    this.defaultData = {
      priority: 'high'
    };
    this.callback = this.getPostData;
    this.refiningFilter = 'Default Filter';
    this.urlParams.offset = 0;
    this.firstRecord = 0;
    this.resetPagination = true;
    this.callback();
  }

  getFilteredData(payload) { // api for refining filter
    this.variants_marked_for_hide = [];
    if (!this.boolPaginate) {
      this.urlParams.offset = 0;
      this.firstRecord = 0;
    }
    const url = this.getParameterizedUrl('/api/refiningFilter');
    this.http.post(url, this.tempPayload)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.apiResponse = response.data.variants;
        this.sampleNotes = response.data.sample_level_note;
        this.apiResponse.content.map(response => {
          response.chromosome = response.chrom;
          response.start = response.genomic_start;
          response.stop = response.genomic_stop;
          return response;
        });
        if (this.apiResponse.content.length !== 0) {
          if (this.savevariant) {
            this.saveSelectedRow = this.selectedRow;
            for (let i = 0; i < this.apiResponse.content.length; i++) {
              if (this.saveSelectedRow.id === this.apiResponse.content[i].id) {
                this.selectedRow = this.apiResponse.content[i];
                break;
              } else {
                this.selectedRow = response.data.variants.content[0];
              }
            }
            this.savevariant = false;
          } else {
            this.selectedRow = response.data.variants.content[0];
          }
        } else {
          this.selectedRow = undefined;
        }
        this.totalRecords = this.apiResponse.totalElements;
        this.Gridcontent = [...this.apiResponse.content];
        this.getAllSavedFilters();
        this.getHiddenVariantCount();
      });
  }

  getParameterizedUrl(API_END_POINT?) {
    API_END_POINT = API_END_POINT || this.API_END_POINT;
    const locationSubTypeMapping = {
      'NON-UTR': 'non-UTR',
      'Non-coding': 'non-Coding',
      'UTR': 'UTR'
    };

    this.urlParams = {
      analysis_id: this.analysis_id,
      gene_class: this.gene_class,
      location: this.location,
      sub_type: this.filter,
      sortBy: this.columnId,
      sortDir: this.sortdir,
      offset: this.urlParams.offset,
      limit: this.urlParams.limit
    };
    this.globalElement.sub_type = this.filter;
    this.filter = this.filter;

    if (this.filter === '00') {
      this.urlParams.sub_type = this.filter;
      this.globalElement.sub_type = this.filter;
    }

    const keys = Object.keys(this.urlParams);
    const params = keys.map(k => `${k}=${this.urlParams[k]}`).join('&');

    return `${API_END_POINT}?${params}`;
  }

  getUrlForReporting() {
    this.variants_marked_for_hide = [];
    if (!this.boolPaginate) {
      this.urlParams.offset = 0;
      this.firstRecord = 0;
    }
    const url = '/api/variants?analysis_id=' + this.analysis_id + '&sub_type=00' + '&sortBy=' + this.urlParams.sortBy + '&sortDir=' + this.sortDir + '&offset=' + this.urlParams.offset + '&limit=15';
    this.http.post(url, this.reportData).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.apiResponse = data.data.variants;
      this.sampleNotes = data.data.sample_level_note;
      this.apiResponse.content.map(response => {
        response.chromosome = response.chrom;
        response.start = response.genomic_start;
        response.stop = response.genomic_stop;
        return response;
      });
      if (data && data.data.variants && data.data.variants.content.length > 0) {
        if (this.savevariant) {
          this.saveSelectedRow = this.selectedRow;
          this.selectedRow = data.data.variants.content[0];
          for (let i = 0; i < this.apiResponse.content.length; i++) {
            if (this.saveSelectedRow.id === this.apiResponse.content[i].id) {
              this.selectedRow = this.apiResponse.content[i];
              break;
            } else {
              this.selectedRow = data.data.variants.content[0];
            }
          }
          this.savevariant = false;
        } else {
          this.selectedRow = data.data.variants.content[0];
        }
      } else {
        this.selectedRow = undefined;
      }
      if (this.selectedRow) {
        for (let i = 0; i < this.filterList.length; i++) {
          if (this.selectedRow.sub_type === this.filterList[i].id) {
            this.filter = this.filterList[i].id;
            break;
          }
        }
      }
      this.totalRecords = this.apiResponse.totalElements;
      this.Gridcontent = [...this.apiResponse.content];
      this.getHiddencount();
    });
  }

  getUrl() {
    const keys = Object.keys(this.globalElement);
    return this.refiningFilterUrl + '?' + keys.map(k => `${k}=${this.globalElement[k]}`).join('&');
  }

  setRefiningFlags() {
    this.customFilterSelected = false;
    this.firstRecord = 0;
    this.boolEdit = false;
    this.boolDisplay = true;
    this.boolSave = false;
    this.boolPopOver = false;
    this.callback = this.getUrlForReporting;
  }

  getFilterPopUp() { // 3
    this.getHiddenVariantCount();
    this.mark_for_hidden = false;
    this.filterPopUp = this.refiningFilter === 'New Filter';
    this.resetPagination = true;
    if (this.filterPopUp) {
      this.firstRecord = 0;
      this.customFilterSelected = false;
      this.callback = this.getFilteredData;
      this.globalElement.analysis_id = this.analysis_id;
      const disposable = this.dialogService.addDialog(ModalComponentComponent, this.globalElement);
      this.boolEdit = true;
      this.boolSave = true;
      this.boolDisplay = false;
      this.boolPopOver = true;
      disposable.subscribe((response: any) => {
        if (response) {
          this.variants_marked_for_hide = [];
          if (response.name === 'No Filter') {
            let filter: any;
            if (this.selectedRefiningFilter) {
              filter = this.filterArray.find(x => x.name === this.selectedRefiningFilter.name);
            }
            if (filter) {
              this.refiningFilter = filter.name;
              this.filterName = filter.name;
              const filter_categories = filter.filter_categories;
              this.newFilterPayload = {
                'refining_filter': {
                  name: filter.name,
                  filter_categories: filter_categories,
                  analysis_id: filter.analysis_id,
                  sample_filter_value: filter.sample_filter_value
                }
              };
              this.tempPayload = {
                'refining_filter': {
                  name: filter.name,
                  filter_categories: filter_categories,
                  analysis_id: filter.analysis_id,
                  sample_filter_value: filter.sample_filter_value
                }
              };
              this.callback(filter);
            } else {
              this.refiningFilter = 'Default Filter';
              this.firstRecord = 0;
              this.customFilterSelected = false;
              this.callback = this.getPostData;
              this.boolEdit = false;
              this.boolSave = false;
              this.boolDisplay = false;
              this.boolPopOver = false;
              this.defaultData = {
                priority: 'high'
              };
              this.callback();
            }
          } else if (response.name.includes('Sample_Filter_')) {
            this.boolEdit = true;
            this.boolSave = false;
            this.boolDisplay = false;
            this.boolPopOver = true;
            this.newFilterPayload = { 'refining_filter': response };
            this.tempPayload = { 'refining_filter': response };
            this.callback(response);
            this.filters = response.filter_categories;
            this.id = response.analysis_id;
            this.sample_boolean = response.sample_filter_value;
            this.appliedFilter = response.name;
            this.filterName = response.name;
            this.getAllSavedFilters(response.name);
            this.getHiddencount();
          } else {
            this.newFilterPayload = { 'refining_filter': response };
            this.tempPayload = { 'refining_filter': response };
            this.callback(response);
            this.filters = response.filter_categories;
            this.id = response.analysis_id;
            this.sample_boolean = response.sample_filter_value;
            this.appliedFilter = response.name;
            this.filterName = response.name;
            let sessionFilters = this.session.getItem('sessionFilters');
            if (sessionFilters) {
              sessionFilters = JSON.parse(sessionFilters);
              const currentFilter = sessionFilters.find(f => f.name === this.appliedFilter);
              if (currentFilter) {
                currentFilter.filter_categories = this.filters;
              } else {
                sessionFilters.push({
                  name: this.appliedFilter,
                  filter_categories: this.filters,
                  analysis_id: response.analysis_id,
                  sample_filter_value: response.sample_filter_value
                });
              }
            } else {
              sessionFilters = [{
                name: this.appliedFilter,
                filter_categories: this.filters,
                analysis_id: response.analysis_id,
                sample_filter_value: response.sample_filter_value
              }];
            }
            this.session.setItem('sessionFilters', JSON.stringify(sessionFilters));
            this.getAllSavedFilters(response.name);
            this.getHiddencount();
          }
        }
      });
    } else if (this.refiningFilter === 'No Filter') {
      this.variants_marked_for_hide = [];
      this.firstRecord = 0;
      this.boolEdit = false;
      this.customFilterSelected = false;
      this.boolSave = false;
      this.boolDisplay = false;
      this.boolPopOver = false;
      this.callback = this.getData;
      this.callback();
    } else if (this.refiningFilter === 'Default Filter') {
      this.firstRecord = 0;
      this.customFilterSelected = false;
      this.callback = this.getPostData;
      this.boolEdit = false;
      this.boolSave = false;
      this.boolDisplay = false;
      this.boolPopOver = false;
      this.defaultData = {
        priority: 'high'
      };
      this.callback();
    } else if (this.refiningFilter === 'All Variants Marked for Analysis') {
      this.setRefiningFlags();
      this.defaultData = {
        marked_for_analysis: true
      };
      this.reportData = {
        marked_for_analysis: true
      };
      this.callback();
    } else if (this.refiningFilter === 'All Variants Marked as Hidden') {
      this.setRefiningFlags();
      this.defaultData = {
        show_as_hidden: true
      };
      this.reportData = {
        show_as_hidden: true
      };
      this.callback();
    } else if (this.refiningFilter === 'All Variants Marked for Report') {
      this.setRefiningFlags();
      this.defaultData = {
        marked_for_report: true
      };
      this.reportData = {
        marked_for_report: true
      };
      this.callback();
    } else if (this.refiningFilter === 'All Variants Marked for Hold Report') {
      this.setRefiningFlags();
      this.defaultData = {
        hold_report: true
      };
      this.reportData = {
        hold_report: true
      };
      this.callback();
    } else if (this.refiningFilter === 'All Variants Marked for Sanger Required') {
      this.setRefiningFlags();
      this.defaultData = {
        sanger_required: true
      };
      this.reportData = {
        sanger_required: true
      };
      this.callback();
    } else if (this.refiningFilter === 'All Variants Marked for Sanger Confirmed') {
      this.setRefiningFlags();
      this.defaultData = {
        sanger_confirmed: true
      };
      this.reportData = {
        sanger_confirmed: true
      }
      this.callback();
    } else if (this.refiningFilter.includes('Sample_Filter_')) {
      this.variants_marked_for_hide = [];
      this.customFilterSelected = true;
      this.firstRecord = 0;
      this.callback = this.getFilteredData;
      this.boolEdit = true;
      this.boolSave = false;
      this.boolDisplay = false;
      this.boolPopOver = true;
      const filter = this.filterArray.find(x => x.name === this.refiningFilter);
      this.selectedFilterId = filter.id;
      if (filter) {
        this.selectedRefiningFilter = filter;
        this.filterName = filter.name;
        const filter_categories = filter.filter_categories;
        this.newFilterPayload = {
          'refining_filter': {
            name: filter.name,
            filter_categories: filter_categories
          }
        };
        this.tempPayload = {
          'refining_filter': {
            name: filter.name,
            filter_categories: filter_categories
          }
        };
        this.callback();
        this.getHiddencount();
      }
    } else {
      this.customFilterSelected = true;
      this.firstRecord = 0;
      this.callback = this.getFilteredData;
      this.boolEdit = true;
      this.boolSave = true;
      this.boolDisplay = false;
      this.boolPopOver = true;
      const filter = this.filterArray.find(x => x.name === this.refiningFilter);
      this.selectedFilterId = filter.id;
      if (filter) {
        this.selectedRefiningFilter = filter;
        this.filterName = filter.name;
        const filter_categories = filter.filter_categories;
        this.newFilterPayload = {
          'refining_filter': {
            name: filter.name,
            filter_categories: filter_categories
          }
        };
        this.tempPayload = {
          'refining_filter': {
            name: filter.name,
            filter_categories: filter_categories
          }
        };
        this.callback();
      }
    }
  }

  geteditedFilter() {
    this.filterArray = this.removeDupFilter(this.filterArray);
    let filter_categories;
    this.callback = this.getFilteredData;
    const filter = this.filterArray.find(x => x.name === this.refiningFilter);
    if (filter) {
      filter_categories = filter.filter_categories;
    }
    this.globalElement.sample_flag = filter.name.includes('Sample_Filter_') ? true : false;
    this.globalElement.isEdit = filter.name.includes('Sample_Filter_') ? false : true;
    this.globalElement.analysis_id = filter.name.includes('Sample_Filter_') ? this.analysis_id : 0;
    this.globalElement.analysis_id_for_count = this.analysis_id;
    const data = {
      filter_categories: filter.filter_categories,
      name: filter.name
    };
    const modalData = cloneDeep(this.globalElement);
    modalData.filter_categories = cloneDeep(data);
    modalData.isEdit = true;
    const disposable = this.dialogService.addDialog(ModalComponentComponent, modalData);
    disposable.subscribe((response: any) => {
      this.globalElement.sample_flag = false;
      this.globalElement.isEdit = false;
      if (response) {
        if (response.name === 'No Filter') {
          this.callback();
        } else if (response.name.includes('Sample_Filter_')) {
          this.boolEdit = true;
          this.boolSave = false;
          this.boolDisplay = false;
          this.boolPopOver = true;
          this.newFilterPayload = { 'refining_filter': response };
          this.tempPayload = { 'refining_filter': response };
          this.callback(response);
          this.filters = response.filter_categories;
          this.id = response.analysis_id;
          this.sample_boolean = response.sample_filter_value;
          this.appliedFilter = response.name;
          this.filterName = response.name;
          this.getAllSavedFilters(response.name);
          this.getHiddencount();
        } else {
          this.newFilterPayload = {
            'refining_filter': {
              name: response.name,
              filter_categories: response.filter_categories,
              analysis_id: response.analysis_id,
              sample_filter_value: response.sample_filter_value
            }
          };
          this.tempPayload = {
            'refining_filter': {
              name: response.name,
              filter_categories: response.filter_categories,
              analysis_id: response.analysis_id,
              sample_filter_value: response.sample_filter_value
            }
          };
          this.filters = response.filter_categories;
          this.id = response.analysis_id;
          this.sample_boolean = response.sample_filter_value;
          this.appliedFilter = response.name;
          this.callback(this.newFilterPayload);
          const filterArray = this.filterArray.find(x => x.name === this.appliedFilter);
          let sessionFilters = this.session.getItem('sessionFilters');
          if (sessionFilters) {
            sessionFilters = JSON.parse(sessionFilters);
            const currentFilter = sessionFilters.find(f => f.name === this.appliedFilter);
            if (currentFilter) {
              currentFilter.filter_categories = this.filters;
            } else {
              sessionFilters.push({
                name: this.appliedFilter,
                filter_categories: this.filters,
                analysis_id: response.analysis_id,
                sample_filter_value: response.sample_filter_value
              });
            }
          } else {
            sessionFilters = [{
              name: this.appliedFilter,
              filter_categories: this.filters,
              analysis_id: response.analysis_id,
              sample_filter_value: response.sample_filter_value
            }];
          }
          this.session.setItem('sessionFilters', JSON.stringify(sessionFilters));
          this.getAllSavedFilters(response.name);
        }
      }
    });
  }

  saveFilters() {
    this.filterSaveError = false;
    this.filterSaveSuccess = false;
    const isEdit = this.checkIfEditOrAdd();
    if (isEdit) {
      const filter = this.filterArray.find(x => x.name === this.filterName);
      if (filter) {
        const saveFilterPayload = {
          name: this.filterName,
          filter_categories: this.filters,
          analysis_id: this.id,
          sample_filter_value: this.sample_boolean
        };
        this.http.put(this.saveFilterUrl, saveFilterPayload).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.getAllSavedFilters();
          this.filterSaveSuccess = true;
          $('#saveFilterModal').modal('toggle');
          setTimeout(function () {
            $('#saveFilterModal').modal('hide');
          }, 4000);
        }, (err) => {
          this.filterSaveError = true;
          if (err.status === 400) {
            this.filterSaveErrorMessage = err.error.message;
          } else {
            this.filterSaveErrorMessage = 'Filter is already saved.';
          }
          $('#saveFilterModal').modal('toggle');
          setTimeout(function () {
            $('#saveFilterModal').modal('hide');
          }, 4000);
        });
      }
    } else {
      const filter = this.filterArray.find(x => x.name === this.filterName);
      if (filter) {
        const saveFilterPayload = {
          name: this.filterName,
          filter_categories: this.filters,
          analysis_id: this.id,
          sample_filter_value: this.sample_boolean
        };
        this.http.post(this.saveFilterUrl, saveFilterPayload).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.getAllSavedFilters();
          this.filterSaveSuccess = true;
          $('#saveFilterModal').modal('toggle');
          setTimeout(function () {
            $('#saveFilterModal').modal('hide');
          }, 4000);
        }, (err) => {
          this.filterSaveError = true;
          if (err.status === 400) {
            this.filterSaveErrorMessage = err.error.message;
          } else {
            this.filterSaveErrorMessage = 'Filter is already saved.';
          }
          $('#saveFilterModal').modal('toggle');
          setTimeout(function () {
            $('#saveFilterModal').modal('hide');
          }, 4000);
        });
      }
    }

  }

  getAllSavedFilters(name = null) {
    this.openanalysisService.getFilters(this.analysis_id).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      let filters = [];
      this.refiningFilterList = this.defaultFilterList;
      this.dashboardData = data.data;
      if (this.dashboardData.content.length !== 0) {
        this.filterArray = this.filterArray.concat(this.dashboardData.content);
        this.filterArray = this.removeDupFilter(this.filterArray);
        filters = this.dashboardData.content.map(c => c.name);
        this.refiningFilterList = this.refiningFilterList.concat(filters);
      }
      let sessionFilters = this.session.getItem('sessionFilters');
      if (sessionFilters) {
        const id = this.analysis_id;
        this.filterArray = this.filterArray.concat(JSON.parse(sessionFilters));
        this.filterArray = this.removeDupFilter(this.filterArray);
        sessionFilters = JSON.parse(this.session.getItem('sessionFilters'));
        for (let i = 0; i < sessionFilters.length; i++) {
          const sID = sessionFilters[i].analysis_id;
          if (sessionFilters[i].sample_filter_value) {
            if (sID !== id) {
              sessionFilters.splice(sessionFilters.indexOf(sessionFilters[i].name), 1);
              break;
            }
          }
        }
        const sessionFilterNames = sessionFilters.map(f => f.name);
        for (let i = 0; i < filters.length; i++) {
          const currentFilter = sessionFilters.find(f => f.name === filters[i]);
          if (currentFilter) {
            const index = sessionFilterNames.indexOf(currentFilter.name);
            if (index > -1) {
              sessionFilterNames.splice(index, 1);
            }
          }
        }
        this.refiningFilterList = this.refiningFilterList.concat(sessionFilterNames);
      }
      if (name) {
        this.refiningFilter = name;
      }
    });
  }

  getAcmgCalculation() {
    this.http.post(this.acmgUrl, this.ACMGOutput).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.selectedRow.clinical_report_data.acmg_calculator = response.data;
      this.selectedRow.clinical_report_data.acmg_selections = this.ACMGOutput;
    });
  }

  saveVariantDetails() {
    this.showSaveAlert = true;
    if (this.boolSanger) {
      this.boolSanger = false;
      $('#successSanger').modal('toggle');
      setTimeout(function () {
        $('#successMsg').modal('hide');
      }, 4000);
    }

    const data = {
      'variantId': this.selectedRow.id,
      'sanger_notes': this.selectedRow.sanger_notes
    };

    this.http.post('/api/updateVariant', data).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
    });
  }


  getPkiStatus() {
    this.selectedRow.clinical_report_data.pki_class =
      this.selectedRow.clinical_report_data.pki_class.toLowerCase() === 'Reset Classification'.toLowerCase() ? '' : this.selectedRow.clinical_report_data.pki_class;
    this.alert = true;
    this.selectedRow.clinical_report_data.pki_status = 'Edited';
    this.selectedRow.clinical_report_data.pki_modified = new Date().getTime();
    this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
    this.selectedrow = this.selectedRow;
  }

  getAlert() {
    this.alert = true;
    this.selectedRow.clinical_report_data.pki_modified = new Date().getTime();
    this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
    this.selectedrow = this.selectedRow;
  }

  onChange($event: any): void {
    if ((this.rowChangeCount > 0 && this.rowchangeNewFlag === false && this.saveFlag === false && this.alert === false) || this.alert) {
      this.selectedRow.clinical_report_data.pki_modified = new Date().getTime();
      this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
      if (this.alert) {
        this.selectedrow = this.selectedRow;
      }
      if (this.notesSectionClicked) {
        this.alert = true;
      }
    }
    this.rowChangeCount = 1;
    this.rowchangeNewFlag = false;
    this.saveFlag = false;
  }

  setClickedFlag($event: any): void {
    this.notesSectionClicked = true;
  }

  onChangeOfNotesTemplate(): void {
    if ((this.rowChangeCount > 0 && this.rowchangeNewFlag === false && this.saveFlag === false && this.alert === false) || this.alert) {
      const whatTime = new Date();
      this.selectedRow.clinical_report_data.pki_modified = whatTime.getTime();
      this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
      if (this.alert) {
        this.selectedrow = this.selectedRow;
      }
      if (this.notesSectionClicked) {
        this.alert = true;
      }
    }
    this.rowChangeCount = 1;
    this.rowchangeNewFlag = false;
    this.saveFlag = false;
  }

  fetchJbrowseLink() {
    this.selectedRowData.analysisId = this.analysis_id;
    this.selectedRowData.chrom = this.selectedRow.chrom;
    this.selectedRowData.genomic_start = this.selectedRow.genomic_start;
    this.selectedRowData.genomic_stop = this.selectedRow.genomic_stop;
    this.openanalysisService.getJbrowseLink(this.selectedRowData).subscribe((data: any) => {
      if (data) {
        const authToken = data.token;
        if (data.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        const url = window.location.href.split('/#/')[0] + data.data;
        this.jBrowseUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
      }
    });
  }

  deleteFilter() {
    if (this.refiningFilter.includes('Sample_Filter_')) {
      this.openanalysisService.deleteSampleFilter(this.analysis_id).subscribe((data: any) => {
        if (data) {
          const authToken = data.token;
          if (data.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          $('#deleteFilterModal').modal('hide');
          const json = JSON.parse(this.session.getItem('sessionFilters'));
          if (json) {
            for (let i = 0; i < json.length; i++) {
              if (json[i].name === this.refiningFilter) {
                json.splice(i, 1);
              }
            }
            this.session.setItem('sessionFilters', JSON.stringify(json));
            this.getAllSavedFilters();
            this.refiningFilter = 'No Filter';
            this.getFilterPopUp();
          } else {
            this.getAllSavedFilters();
            this.refiningFilter = 'No Filter';
            this.getFilterPopUp();
          }
        }
      }, (err) => {
        this.deleteFilterError = true;
      });
    } else {
      this.openanalysisService.deleteFilter(this.refiningFilter).subscribe((data: any) => {
        if (data) {
          const authToken = data.token;
          if (data.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          $('#deleteFilterModal').modal('hide');
          const json = JSON.parse(this.session.getItem('sessionFilters'));
          if (json) {
            for (let i = 0; i < json.length; i++) {
              if (json[i].name === this.refiningFilter) {
                json.splice(i, 1);
              }
            }
            this.session.setItem('sessionFilters', JSON.stringify(json));
            this.getAllSavedFilters();
            this.refiningFilter = 'No Filter';
            this.getFilterPopUp();
          } else {
            this.getAllSavedFilters();
            this.refiningFilter = 'No Filter';
            this.getFilterPopUp();
          }
        }
      }, (err) => {
        this.deleteFilterError = true;
      });
    }
  }

  clearFilterSaveBanners() {
    this.filterSaveError = false;
    this.filterSaveSuccess = false;
  }

  clearFilterDeleteBanners() {
    this.deleteFilterError = false;
  }

  lazyLoadData(event) {
    this.analysis_id = this.route.snapshot.paramMap.get('analysis_id');
    const payload = this.customFilterSelected ? this.newFilterPayload : this.refiningFilter === 'Default Filter' ? {
      priority: 'high'
    } : {};
    this.reportData = payload;
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.urlParams.offset = 0;
    this.firstRecord = event.first;
    this.columnId = event.sortField ? event.sortField : 'gene';
    this.sortdir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    const filters = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});
    if (key.length === 0) {
      this.nofilterData = null;
    } else {
      this.nofilterData = merge({}, filters);
    }
    const refineFilter = {
      'column_filter': filters
    };
    if (this.refiningFilter !== undefined) {
      if (this.refiningFilter === 'No Filter') {
        this.defaultData = filters;
        this.callback = this.getPostData;
        this.callback();
      }
      if (this.callback === this.getUrlForReporting) {
        if (key.length !== 0) {
          this.reportData = merge({}, this.defaultData);
          const payload = this.reportData;
          this.reportData = merge(payload, filters);
        } else {
          this.reportData = merge({}, this.defaultData);
        }
        this.urlParams.sortDir = this.sortdir;
        this.urlParams.sortBy = this.columnId;
        this.callback();
      } else if (this.callback === this.getFilteredData) {
        if (key.length !== 0) {
          delete this.tempPayload.column_filter;
          const temp = this.tempPayload;
          this.tempPayload = merge(temp, refineFilter)
        } else {
          this.tempPayload = merge({}, this.newFilterPayload);
        }
        this.reportData = this.tempPayload;
        this.callback();
      } else {
        if (this.refiningFilter !== 'No Filter') {
          this.customFilterSelected ? merge(this.newFilterPayload, refineFilter) : this.defaultData = merge(payload, filters);
          this.customFilterSelected ? '' : this.refiningFilter = 'Default Filter';
          this.customFilterSelected ? '' : this.callback = this.getPostData;
        }
        this.reportData = this.defaultData;
        this.callback();

      }
      this.getHiddencount();
    } else {
      this.openanalysisService.checkforSampleFilter(this.analysis_id).subscribe((Response: any) => {
        const authToken = Response.token;
        if (Response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.sample_boolean = Response.data;
        if (Response.data === true) {
          this.callback = this.getFilteredData;
          this.openanalysisService.getPayloadForSampleFilter(this.analysis_id).subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.boolEdit = true;
            this.boolSave = false;
            this.boolDisplay = false;
            this.boolPopOver = true;
            this.appliedFilter = response.data.name;
            this.filterName = response.data.name;
            this.refiningFilter = response.data.name;
            this.newFilterPayload = { 'refining_filter': response.data };
            this.tempPayload = { 'refining_filter': response.data };
            this.callback();
            this.getHiddencount();
          });
        } else {
          if (this.refiningFilter === 'No Filter') {
            this.defaultData = filters;
            this.callback = this.getPostData;
            this.callback();
            this.getHiddencount();
          }
          if (this.callback === this.getUrlForReporting) {
            if (key.length !== 0) {
              this.reportData = merge({}, this.defaultData);
              const payload = this.reportData;
              this.reportData = merge(payload, filters);
            } else {
              this.reportData = merge({}, this.defaultData);
            }
            this.urlParams.sortDir = this.sortdir;
            this.urlParams.sortBy = this.columnId;
            this.callback();
          } else if (this.callback === this.getFilteredData) {
            if (key.length !== 0) {
              delete this.tempPayload.column_filter;
              const temp = this.tempPayload;
              this.tempPayload = merge(temp, refineFilter)
            } else {
              this.tempPayload = merge({}, this.newFilterPayload);
            }
            this.reportData = this.tempPayload;
            this.callback();
          } else {

            this.customFilterSelected ? '' : this.refiningFilter = 'Default Filter';
            const payload_new = this.customFilterSelected ? this.newFilterPayload : this.refiningFilter === 'Default Filter' ? {
              priority: 'high'
            } : {};
            const temp_payload = Object.keys(payload).length === 0 ? payload_new : payload;
            this.customFilterSelected ? merge(this.newFilterPayload, refineFilter) : this.defaultData = merge(temp_payload, filters);

            this.customFilterSelected ? '' : this.callback = this.getPostData;
            this.reportData = this.defaultData;
            this.callback();
          }
          this.getHiddencount();
        }
      });
    }
  }


  paginate(event) {
    this.variants_marked_for_hide = [];
    this.boolOther = true;
    this.mark_for_hidden = false;
    this.firstRecord = event.first;
    this.urlParams.offset = event.first / event.rows;
    this.urlParams.limit = event.rows;
    if (this.callback === this.getFilteredData || this.callback === this.getUrlForReporting) {
      this.boolPaginate = true;
      this.callback();
    } else if (this.refiningFilter === 'No Filter') {
      if (this.nofilterData !== null) {
        this.callback = this.getPostData;
        this.callback();
      } else {
        this.callback = this.getData;
        this.callback();
      }
    } else {
      this.callback();
    }
    this.getHiddencount();
  }

  onRowClick(event) {
    for (let i = 0; i < this.filterList.length; i++) {
      if (this.selectedRow.sub_type === this.filterList[i].id) {
        this.filter = this.filterList[i].id;
        break;
      }
    }
    this.acmgFlag = true;
    if (this.alert && this.alertCount === 0) {
      this.rowChangeCount = 0;
      this.rowchangeNewFlag = true;
      this.success = true;
      if (this.success) {
        $('#AlertonPKIChange').modal('toggle');
      }
      this.alert = false;
      this.alertCount = 1;
    }
    else if (this.alert && this.alertCount > 0) {
      this.alert = false;
      this.alertCount = 0;
      this.rowChangeCount = 0;
      this.rowchangeNewFlag = true;
    }
    else {
      this.selectedRow = event.data;
      this.alert = false;
      this.acmgFlag = true;
      this.rowChangeCount = 0;
      this.rowchangeNewFlag = true;
      this.alertCount = 0;
    }
    this.saveFlag = false;
    this.notesSectionClicked = false;
  }

  getColor(element, dataitem, type) {
    switch (type) {

      case 'coverage_color':
        if (dataitem[type] === 'gray') {
          element.parentNode.parentNode.style.background = 'darkgrey';
        }
        break;
      case 'gnomad_high_freq_color':
        if (dataitem[type] === 'pink') {
          element.parentNode.parentNode.style.background = 'lightpink';
        }
        break;
    }
  }

  handleCheckboxClick(dataItem, type, checked) {
    this.hideClickFlag = true;
    dataItem[type] = checked;
    this.selectedRow = dataItem;
    this.dataPayload = this.callback === this.getData ? {} :
      this.callback === this.getFilteredData ? this.newFilterPayload : this.reportData;
    const hideURL = this.callback === this.getFilteredData ?
      '/api/hiddenVariantsDetailsRefiningFilter' : '/api/hiddenVariantsDetails';
    this.openanalysisService.getHiddenVariantCount(hideURL, this.analysis_id, this.gene_class, this.location, this.filter, this.urlParams.sortBy, this.sortdir, this.urlParams.offset, this.urlParams.limit, this.dataPayload)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.variants_marked_for_hide = this.variants_marked_for_hide.concat(response.data);
        this.variants_marked_for_hide = this.removeDupVariants(this.variants_marked_for_hide);
        this.hide_boolean = this.variants_marked_for_hide.length === 0 ? false : true;

        if (type === 'show_as_hidden' && checked) {
          this.hide_boolean = true;
          if (this.variants_marked_for_hide.indexOf(dataItem.chrom_start_stop_ref_alt) == -1) {
            this.variants_marked_for_hide = this.variants_marked_for_hide.concat(dataItem.chrom_start_stop_ref_alt);
          }

        } else if (type === 'show_as_hidden' && !checked) {
          const index = this.variants_marked_for_hide.indexOf(dataItem.chrom_start_stop_ref_alt);
          if (index !== -1) {
            this.variants_marked_for_hide.splice(index, 1);
          }
          this.hide_boolean = this.variants_marked_for_hide.length === 0 ? false : true;
          this.openanalysisService.deselectSingleVariant(this.analysis_id, dataItem.chrom_start_stop_ref_alt).subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
          });
        } else {
          const value = checked.toString();
          const data = {
            'variantId': dataItem.id,
            [type]: value
          };
          this.http.post('/api/updateVariant', data).subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
          });
        }
      });
  }

  rowStyleClass(data: any) {
    return data.row_color === 'gray' ? 'gray' :
      data.row_color === 'light_gray' ? 'lightgray' :
        data.row_color === 'green' ? 'green' :
          data.row_color === 'pink' ? 'pink' : 'white';
  }

  sendReportData() {
    this.reportTemplateService.checkForOnHold(this.analysis_id).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      if (data.data) {
        $('#onHoldErrorModal').modal('toggle');
        this.popupMsg = 'Variant(s) with hold report status has been selected for creating report';
        setTimeout(function () {
          $('#onHoldErrorModal').modal('hide');
        }, 4000);
      } else {
        this.getSections();
      }
    });
  }

  checkIfEditOrAdd() {
    let flag = false;
    for (let i = 0; i < this.dashboardData.content.length; i++) {
      if (this.dashboardData.content[i].name === this.filterName) {
        flag = true;
        break;
      }
    }
    return flag;
  }

  getGenePage(event) {
    this.dashboard.getSpecificMasterGeneBoard(event);
  }

  getVariantData(event) {
    this.dashboard.getSpecificMasterVariantBoard(event);
  }

  offset = 0;
  firstRecordForOtherGrid = 0;
  sortBy = 'name';
  sortDir = 'asc';

  otherAnalysisData(event) {
    if (this.selectedRow) {
      const sortOrderMapper = {
        '1': 'asc',
        '-1': 'desc'
      };

      this.offset = event.first / event.rows;
      this.firstRecordForOtherGrid = event.first;
      this.sortBy = event.sortField ? event.sortField : 'first_name';
      this.sortDir = sortOrderMapper[event.sortOrder];
      const key = Object.keys(event.filters);
      const filters = key.reduce((f, c) => {
        f[c] = event.filters[c].value;
        return f;
      }, {});
      const payload = { 'clientIds': this.client_ids };
      const filter = { 'searchReq': filters };
      this.filterPayload = filters ? merge(filter, payload) : payload;
      this.filterApplied = filters ? true : false;

    }
  }

  getOtherAnalysisData() {
    this.getClientIDs();
    this.filterPayload = this.filterApplied ? this.filterPayload : { 'clientIds': this.client_ids };
    const variant_id = this.selectedRow.chrom_start_stop_ref_alt;
    this.offset = this.boolOther === true ? 0 : this.offset;
    this.openanalysisService.getOtherAnalysesDetails(variant_id, this.offset, 10, this.sortBy, this.sortDir, this.filterPayload).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.lowerPanelContentLength = response.data.totalElements;
      this.lowerPanelContent = response.data.content;
      delete this.filterPayload.searchReq;
      this.boolOther = false;
    });
  }

  showAcmgCalculation() {
    this.alert = true;
    this.selectedrow = this.selectedRow;
    if (this.selectedRow.clinical_report_data.acmg_selections) {
      this.ACMGOutput = this.selectedRow.clinical_report_data.acmg_selections;
      this.acmgDetails.acmgData = this.ACMGOutput;
      const disposable = this.dialogService.addDialog(AcmgCalculatorComponent, this.acmgDetails);
      disposable.subscribe((response: any) => {
        if (response !== false) {
          this.http.post(this.acmgUrl, response).subscribe((data: any) => {
            const authToken = data.token;
            if (data.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.selectedRow.clinical_report_data.acmg_calculator = data.data;
            this.selectedRow.clinical_report_data.acmg_selections = response;
            this.selectedRow.clinical_report_data.pki_modified = new Date().getTime();
            this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
          });
        }
      });
    } else {
      this.dialogService.addDialog(AcmgCalculatorComponent, {})
        .subscribe((response: any) => {
          if (response !== false) {
            this.http.post(this.acmgUrl, response).subscribe((data: any) => {
              const authToken = data.token;
              if (data.token !== null) {
                sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
              } else { }
              this.selectedRow.clinical_report_data.acmg_calculator = data.data;
              this.selectedRow.clinical_report_data.acmg_selections = response;
              this.selectedRow.clinical_report_data.pki_modified = new Date().getTime();
              this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
            });
          }
        });
    }
  }

  setActive(event) {
    this.alert = true;
    this.selectedRow.clinical_report_data.frequent_artifact = event.target.checked;
    this.selectedRow.clinical_report_data.pki_modified = new Date().getTime();
    this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
    this.selectedrow = this.selectedRow;
  }

  saveClinicalData() {
    this.alert = false;
    this.alertCount = 0;
    this.saveFlag = true;
    this.notesSectionClicked = false;
    this.selectedRow.clinical_report_data.chrom_start_stop_ref_alt = this.selectedRow.chrom_start_stop_ref_alt;
    this.selectedRow.clinical_report_data.user_email = sessionStorage.getItem('email');
    const url = '/api/master/clinicalReportData';
    this.http.post(url, this.selectedRow.clinical_report_data).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.boolClinical = false;
      $('#successMsg').modal('toggle');
      if (this.callback === this.getFilteredData || this.callback === this.getUrlForReporting) {
        this.savevariant = true;
        this.callback();
      } else {
        this.callback();
      }
    });
  }

  handleAllHide(event) {
    let unselectedVariants = [];
    if (event.target.checked) {
      this.hide_boolean = true;
      this.apiResponse.content.forEach(m => { m.show_as_hidden = true });
      this.variants_marked_for_hide = this.apiResponse.content.map(id_list => {
        return id_list.chrom_start_stop_ref_alt;
      });
    } else {
      this.hide_boolean = false;
      this.apiResponse.content.forEach(m => {
        m.show_as_hidden = false;
        unselectedVariants.push(m.chrom_start_stop_ref_alt);
      });
      this.variants_marked_for_hide = [];
      this.openanalysisService.unselectHiddenVariants(this.analysis_id, unselectedVariants)
        .subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
        },
          (err) => {
            alert('unhide variants failed');
          });
    }
  }

  hideVariant() {
    if (this.hideClickFlag === false) {
      this.dataPayload = this.callback === this.getData ? {} :
        this.callback === this.getFilteredData ? this.newFilterPayload : this.reportData;
      const hideURL = this.callback === this.getFilteredData ?
        '/api/hiddenVariantsDetailsRefiningFilter' : '/api/hiddenVariantsDetails';
      this.openanalysisService.getHiddenVariantCount(hideURL, this.analysis_id, this.gene_class, this.location, this.filter, this.urlParams.sortBy, this.sortdir, this.urlParams.offset, this.urlParams.limit, this.dataPayload)
        .subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.variants_marked_for_hide = this.variants_marked_for_hide.concat(response.data);
          this.hide_boolean = this.variants_marked_for_hide.length === 0 ? false : true;
          this.hideVariantAPI();
        });
    }
    else {
      this.hideVariantAPI();
      this.hideClickFlag = false;
    }
  }

  hideVariantAPI() {
    this.variants_marked_for_hide = this.removeDupVariants(this.variants_marked_for_hide);
    this.openanalysisService.markVariantsAsHiddden(this.analysis_id, this.variants_marked_for_hide)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.hide_boolean = false;
        this.variants_marked_for_hide = [];
        if (this.callback === this.getFilteredData || this.callback === this.getUrlForReporting) {
          this.callback();
          this.getHiddenVariantCount();
          this.mark_for_hidden = false;
        } else {
          this.callback = this.refiningFilter === 'Default Filter' ? this.getPostData : this.getData;
          this.callback();
        }
      });
  }

  unhideVariant() {
    this.urlParams.offset = 0;
    this.firstRecord = 0;
    this.mark_for_hidden = false;
    this.hide_boolean = true;
    this.openanalysisService.markVariantsAsUnhide(this.analysis_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.variants_marked_for_hide = [];
      if (this.callback === this.getFilteredData || this.callback === this.getUrlForReporting) {
        this.callback();
      } else {
        this.callback = this.refiningFilter === 'Default Filter' ? this.getPostData : this.getData;
        this.callback();
      }
    });
  }

  getHiddencount() {
    this.dataPayload = this.callback === this.getData ? {} :
      this.callback === this.getFilteredData ? this.newFilterPayload : this.reportData;
    const hideURL = this.callback === this.getFilteredData ?
      '/api/hiddenVariantsDetailsRefiningFilter' : '/api/hiddenVariantsDetails';
    this.openanalysisService.getHiddenVariantCount(hideURL, this.analysis_id, this.gene_class, this.location, this.filter, this.urlParams.sortBy, this.sortdir, this.urlParams.offset, this.urlParams.limit, this.dataPayload)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.variants_marked_for_hide = this.variants_marked_for_hide.concat(response.data);
        this.hide_boolean = this.variants_marked_for_hide.length === 0 ? false : true;
      });
  }

  getSections() {
    this.reportService.checkReportType(this.analysis_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      if (response.data.toLowerCase() === 'normal') {
        this.reportService.checkTestId(this.analysis_id).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.checkTestMessage = response.data.message;
          if (response.data.test_code_present) { // check for test_ids
            this.openanalysisService.getVariantForReport(this.analysis_id).subscribe((variants: any) => {
              const authToken = variants.token;
              if (variants.token !== null) {
                sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
              } else { }
              if (variants.data.variants.totalElements !== 0) { // check for variants present
                this.reportService.checkAvailableSections(this.analysis_id).subscribe((response: any) => {
                  const authToken = response.token;
                  if (response.token !== null) {
                    sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
                  } else { }
                  if (response.data === true) { // check if sections are available
                    this.analysisData.analysis_id = this.analysis_id;
                    this.dialogService.addDialog(VariantsForSectionComponent, this.analysisData).subscribe((result: any) => {
                      if (result !== false) {
                        this.openanalysisService.changeMessage(result);
                        this.router.navigate(['app/report-template', this.analysis_id, 0, false]);
                      } else {
                        this.openanalysisService.changeMessage({});
                      }
                    });
                  } else {
                    this.openanalysisService.changeMessage({});
                    this.router.navigate(['app/report-template', this.analysis_id, 0, false]);
                  }
                });
              } else {
                this.openanalysisService.changeMessage({});
                this.router.navigate(['app/report-template', this.analysis_id, 0, false]);
              }
            });
          } else {
            $('#defaultModal').modal('toggle');
          }
        });
      } else {
        this.reportService.checkPurpleTestId(this.analysis_id).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.checkTestMessage = response.data.message;
          if (response.data.test_code_present) {
            this.openanalysisService.getVariantForReport(this.analysis_id).subscribe((variants: any) => {
              const authToken = variants.token;
              if (variants.token !== null) {
                sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
              } else { }
              if (variants.data.variants.totalElements !== 0) { // check for variants present
                this.reportService.checkAvailablePurpleSections(this.analysis_id).subscribe((response: any) => {
                  const authToken = response.token;
                  if (response.token !== null) {
                    sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
                  } else { }
                  if (response.data === true) { // check if sections are available
                    this.analysisData.analysis_id = this.analysis_id;
                    this.dialogService.addDialog(VariantsForSectionComponent, this.analysisData).subscribe((result: any) => {
                      if (result !== false) {
                        this.openanalysisService.changeMessage(result);
                        this.router.navigate(['app/purple-template', this.analysis_id, 0, false]);
                      } else {
                        this.openanalysisService.changeMessage({});
                      }
                    });
                  } else {
                    this.openanalysisService.changeMessage({});
                    this.router.navigate(['app/purple-template', this.analysis_id, 0, false]);
                  }
                });
              } else {
                this.openanalysisService.changeMessage({});
                this.router.navigate(['app/purple-template', this.analysis_id, 0, false]);
              }
            });
          } else {
            $('#defaultModal').modal('toggle');
          }
        });
      }
    });
  }


  //for default template
  getDefaultPage() {
    this.openanalysisService.getVariantForReport(this.analysis_id).subscribe((variants: any) => {
      const authToken = variants.token;
      if (variants.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      if (variants.data.variants.totalElements !== 0) { // check for variants present
        this.reportService.checkAvailableSections(this.analysis_id).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          if (response.data === true) { // check if sections are available
            this.analysisData.analysis_id = this.analysis_id;
            this.dialogService.addDialog(VariantsForSectionComponent, this.analysisData).subscribe((result: any) => {
              if (result !== false) {
                this.openanalysisService.changeMessage(result);
                this.router.navigate(['app/report-template', this.analysis_id, 0, false]);
              } else {
                this.openanalysisService.changeMessage({});
              }
            });
          } else {
            this.openanalysisService.changeMessage({});
            this.router.navigate(['app/report-template', this.analysis_id, 0, false]);
          }
        });
      } else {
        this.openanalysisService.changeMessage({});
        this.router.navigate(['app/report-template', this.analysis_id, 0, false]);
      }
    });
  }

  saveSampleNotes() {
    this.openanalysisService.updateSampleNotes(this.analysis_id, this.sampleNotes).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.popupMsg = "Sample Notes saved successfully";
      $('#onHoldErrorModal').modal('toggle');
    });
  }

  setReportNotes() {
    this.selectedRow.clinical_report_data.report_notes = this.report_notes;
    this.clinical_report_dialogue = "0: undefined";
  }

  getReportNotes(val) {
    this.report_notes = val;
    this.clinical_report = "0: undefined";
    this.clinical_report_dialogue = "0: undefined";
  }

  removeDupVariants(arrVariants) {
    let uniqueArr = [];
    for (let i = 0; i < arrVariants.length; i++) {
      if (uniqueArr.indexOf(arrVariants[i]) === -1) {
        uniqueArr.push(arrVariants[i]);
      }
    }
    return uniqueArr;
  }

  removeDupFilter(arr) {
    let uniqueArr = [];
    const a = Object.values(arr.reduce((acc, cur) => Object.assign(acc, { [cur.name]: cur }), {}))
    return a;
  }

  addVariantToTable() {
    this.filterData.analysis_id = this.analysis_id;
    this.filterData.filter = this.filter;
    this.filterData.gene_class = this.gene_class;
    this.filterData.location = this.location;
    this.dialogService.addDialog(AddVariantAnalysisComponent, this.filterData).subscribe((response: any) => {
      if (response === 'failed') {
        if (this.callback === this.getFilteredData || this.callback === this.getUrlForReporting) {
          this.boolPaginate = true;
          this.callback();
        } else if (this.refiningFilter === 'No Filter') {
          if (this.nofilterData !== null) {
            this.callback = this.getPostData;
            this.callback();
          } else {
            this.callback = this.getData;
            this.callback();
          }
        } else {
          this.callback();
        }
        this.getHiddencount();
      } else {
        if (this.callback === this.getFilteredData || this.callback === this.getUrlForReporting) {
          this.boolPaginate = true;
          this.callback();
        } else if (this.refiningFilter === 'No Filter') {
          if (this.nofilterData !== null) {
            this.callback = this.getPostData;
            this.callback();
          } else {
            this.callback = this.getData;
            this.callback();
          }
        } else {
          this.callback();
        }
        this.getHiddencount();
        this.popupMsg = 'Variant added to the analysis successfully';
        $('#onHoldErrorModal').modal('toggle');
      }
    });
  }
}
