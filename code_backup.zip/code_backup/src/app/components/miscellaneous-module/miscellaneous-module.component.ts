import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'miscellaneous-module',
  templateUrl: './miscellaneous-module.component.html',
  styleUrls: ['./miscellaneous-module.component.css']
})
export class MiscellaneousModuleComponent implements OnInit {
  isGeneListActive = true;
  isClinicalNotesActive = false;
  isAuditActive = false;
  isMediActive = false;
  audit_permission: boolean = false;
  constructor(private router: Router) { }

  ngOnInit() {
    const permissions = sessionStorage.getItem('permissions').split(',');
    this.audit_permission = permissions.includes('EXPORT_AUDIT_TRAIL') ? true : false;
    this.router.navigate(['app/miscellaneous/create-gene']);
    this.isGeneListActive = true;
    this.isClinicalNotesActive = false;
    this.isAuditActive = false;
    this.isMediActive = false;
  }

  getGenelistBoard() {
    this.router.navigate(['app/miscellaneous/create-gene']);
    this.isGeneListActive = true;
    this.isClinicalNotesActive = false;
    this.isAuditActive = false;
    this.isMediActive = false;
  }

  getClinicalNotesBoard() {
    this.router.navigate(['app/miscellaneous/create-clinical-notes']);
    this.isGeneListActive = false;
    this.isClinicalNotesActive = true;
    this.isAuditActive = false;
    this.isMediActive = false;
  }

  getAuditBoard() {
    this.router.navigate(['app/miscellaneous/audit-trail']);
    this.isAuditActive = true;
    this.isMediActive = false;
    this.isGeneListActive = false;
    this.isClinicalNotesActive = false;
  }

  getMediBoard() {
    this.router.navigate(['app/miscellaneous/medixcel']);
    this.isAuditActive = false;
    this.isMediActive = true;
    this.isGeneListActive = false;
    this.isClinicalNotesActive = false;
  }
  
}
