import { Component, OnInit } from '@angular/core';
import { ReportModuleService } from '../../common/services/report-module.service';
import { DialogService } from 'ng2-bootstrap-modal';
import { LogoBrowseComponent } from '../logo-list/logo-browse.component';
import { Router, ActivatedRoute } from '@angular/router';
declare var $: any;

interface LType {
  logo1_name?: any;
  logo2_name?: any;
  path?: any;
  id?: any;
  description?: any;
  logo1_path?: any;
  logo2_path?: any;
}

@Component({
  selector: 'new-purple-report',
  templateUrl: './new-purple-report.component.html',
  styleUrls: ['./new-purple-report.component.css']
})
export class NewPurpleReportComponent implements OnInit {

  reportData: any;
  reportSections: any;
  logoDetails: LType = {};
  logo1: any;
  logo2: string;
  readonlyFlag: boolean = false;
  createReportFlag: any;
  parentCheckedStatus: boolean;
  errorMessage: string;
  savedMessage: string;
  template_id: string;

  CkeditorConfigForTextbox = {
    allowedContent: true,
    height: 30,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };
  CkeditorConfig = {
    allowedContent: true,
    height: 100,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    fontSize_defaultLabel: '11',
    extraPlugins: "divarea",
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };

  VariantInterpretationCkeditorConfig = {
    allowedContent: true,
    height: 100,
    resize_enabled: false,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker,JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock'
  };
  CkeditorConfig_familial = {
    allowedContent: true,
    height: 500,
    resize_enabled: false,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };

  constructor(
    private service: ReportModuleService,
    private dialogService: DialogService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.template_id = this.route.snapshot.paramMap.get('template_id');
    setTimeout(() => { }, 10000);
    this.getData();
  }

  checkForDefault() {
    if (this.reportData.id.toLowerCase() === 'default') {
      this.errorMessage = "Report template with name 'DEFAULT' already exists and cannot be created.";
      $('#errorAlert').modal('toggle');
      return;
    }
  }

  ngAfterViewInit() {
    $(document).on("click", ".set-display", function (e) {
      e.stopPropagation();
    });

    $(document).click(function () {
      $('.set-display').removeClass('set-display');
    });
  }

  getData() {
    if (this.template_id !== 'null') {
      this.service.getEditedReportData(this.template_id).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.reportData = response.data;
        this.reportSections = response.data.label_list;
      });
    } else {
      this.getSections();
    }
  }



  goToTemplate() {
    this.router.navigate(['/app/clinical-report/purple-module']);
  }

  getSections() {
    this.service.getSections().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.reportData = response.data;
      this.reportSections = response.data.label_list;
    });
  }

  selectLogo(position) {
    this.dialogService.addDialog(LogoBrowseComponent, {})
      .subscribe((response: any) => {
        if (response) {
          if (position === 'left') {
            this.logoDetails = response;
            this.reportData.logo1_path = response.path;
            this.reportData.logo1_name = response.name;
            this.logo1 = response.name;
          } else {
            this.logoDetails = response;
            this.reportData.logo2_path = response.path;
            this.reportData.logo2_name = response.name;
            this.logo2 = response.name;
          }
        }
      });

  }

  removeLogo(position) {
    this.reportData.logo1_path = position === 'left' ? null : this.reportData.logo1_path;
    this.reportData.logo2_path = position === 'right' ? null : this.reportData.logo2_path;
  }

  selectAllCheckboxes(event) {
    for (var key in this.reportSections) {
      if (this.reportSections.hasOwnProperty(key)) {
        var val = this.reportSections[key];
        this.reportSections[key].flag = event.target.checked;
        this.reportData[this.reportSections[key].id] = event.target.checked;
      }
    }
  }

  setParentItem(event, sectionArr) {
    let newStr = event.target.value;
    this.reportData[newStr] = event.target.checked;
    let chekcedFlag = true;

    for (var i in sectionArr) {
      if (sectionArr[i].flag === false) {
        chekcedFlag = false;
      }
    }
    if (chekcedFlag) {
      $('#selectAllReportSection').prop("checked", true);
    } else {
      $('#selectAllReportSection').prop("checked", false);
    }
  }

  setParentFlag(event, id, sectionArr) {
    event.stopPropagation();
    this.reportData[id] = event.target.checked;
    this.readonlyFlag = this.readonlyFlag + id;
    if (event.target.checked) {
      $('.set-display').removeClass('set-display');
      $('.' + id).addClass('set-display');
    } else {
      $('#sec_' + id).attr('readonly', 'readonly');
      $('.set-display').removeClass('set-display');
    }
    if (event.target.checked) {
      this.parentCheckedStatus = true;
    } else {
      this.parentCheckedStatus = false;
    }

    let chekcedFlag = true;
    for (var i in sectionArr) {
      if (sectionArr[i].flag === false) {
        chekcedFlag = false;
      }
    }
    if (chekcedFlag) {
      $('#selectAllReportSection').prop("checked", true);
    } else {
      $('#selectAllReportSection').prop("checked", false);
    }
  }

  setParentFlagInput(event, id) {
    this.readonlyFlag = this.readonlyFlag + id;
    const parentStatus = $('#' + id).is(':checked');
    setTimeout(function () {
      if (parentStatus) {
        $('.' + id).addClass('set-display');
      }
    }, 0);
  }

  selectAllTreeviewCheckboxes(event, arrChild, label) {
    for (var key in arrChild) {
      arrChild[key].flag = event.target.checked;
      let childKey = arrChild[key].id;
      let str = arrChild[key].label;
      let newStr = str.replace(/\s/g, "_");
      let id = arrChild[key].id;
      let newLabel = label.slice(5);
      if (this.reportData) {
        this.reportData[newLabel][childKey] = event.target.checked;
      }
      if (this.reportData[newLabel]) {
        for (var i in this.reportData[newLabel]) {
          if (this.reportData[newLabel][i])
            this.reportData[label] = event.target.checked;
          break;
        }
      }
    }
  }

  setItem(event, label, child, childArr) {
    let newLabel = label.slice(5);
    if (this.reportData) {
      let val = event.target.value;
      this.reportData[newLabel][event.target.value] = event.target.checked;
      const id = this.reportSections.findIndex(x => x.id === label);
      const c_id = this.reportSections[id].children.findIndex(x => x.id === child);
      this.reportSections[id].children[c_id].flag = event.target.checked;
    }
    if (this.reportData[newLabel]) {
      for (var i in this.reportData[newLabel]) {
        if (this.reportData[newLabel][i])
          this.reportData[label] = true;
        break;
      }
    }

    let val: boolean = true;
    for (var key in childArr) {
      if (this.reportSections.hasOwnProperty(key)) {
        if (childArr[key].flag === false) {
          val = false;
        }
      }
    }
    if (val) {
      $('#selectall_' + label).prop("checked", true);
    } else {
      $('#selectall_' + label).prop("checked", false);
    }
  }

  saveReportData() {
    if (this.reportData.id === null || this.reportData.id === "") {
      this.errorMessage = 'Please Enter Template Name';
      $('#errorAlert').modal('toggle');
      return;
    }
    if (this.reportData.test_ids === null || this.reportData.test_ids.length === 0) {
      this.errorMessage = 'Please Enter Test Id';
      $('#errorAlert').modal('toggle');
      return;
    }
    if (this.template_id !== 'null') {
      this.reportData.modified_by = sessionStorage.getItem('user');
      this.service.saveEditedReportData(this.reportData).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.savedMessage = response.data;
        $('#saveAlert').modal('toggle');
      }, (err) => {
        this.errorMessage = err.error.data;
        $('#errorAlert').modal('toggle');
      });
    }
    else {
      this.reportData.created_by = sessionStorage.getItem('user');
      this.service.saveReportData(this.reportData).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.savedMessage = response.data;
        $('#saveAlert').modal('toggle');
      }, (err) => {
        this.errorMessage = err.error.data;
        $('#errorAlert').modal('toggle');
      });
    }
  }

  routePage() {
    this.router.navigate(['/app/clinical-report/purple-module']);
  }

}
