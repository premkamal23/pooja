import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../common/services';
import { CommonHttpInterceptor } from '../../common/common-http.intercepter';
import { DialogService } from 'ng2-bootstrap-modal';
import { ChangePasswordComponent } from '../change-password/change-password.component';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

    username: string;
    password: string;
    userDetails: string;
    user_id: number;
    msg: string;
    error: any = null;
    success: string;
    old_password: string;
    new_password: string;
    cpassword: string;
    client_list = [];
    errorList: Array<any>;

    new_user_details = {
        'user_id': this.user_id,
        'email': this.username
    };
    private intercept: CommonHttpInterceptor;
    constructor(private service: AuthenticationService,
        private router: Router,
        private dialogService: DialogService
    ) {
    }

    ngOnInit() {
        this.clearError();
    }

    clearError() {
        this.errorList = [];
    }

    login() {
        this.clearError();
        let mailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (!this.username || !mailRegex.test(this.username)) {
            this.errorList.push('Please enter valid email address');
        } if (!this.password) {
            this.errorList.push('Please enter password');
        } else {
            this.clearError();
            const logged_in_time = new Date().getTime();
            this.service.validateUserDetails(this.username, this.password, logged_in_time).subscribe((response: any) => {
                this.error = null;
                    if (response.status === 'require_password_change') {
                        const authToken = response.data.token;
                        this.user_id = response.data.user_id;
                        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
                        this.showConfirm();
                    } else {
                        const authToken = response.data.token;
                        const user_name = response.data.last_name !== null
                            ? response.data.first_name + ' ' + response.data.last_name
                            : response.data.first_name;
                            
                        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
                        sessionStorage.setItem('designation', response.data.designation);
                        sessionStorage.setItem('clients', JSON.stringify(response.data.clients));
                        sessionStorage.setItem('user', user_name);
                        sessionStorage.setItem('permissions', response.data.permissions);
                        sessionStorage.setItem('user_id', response.data.user_id);
                        sessionStorage.setItem('email', response.data.email);
                        sessionStorage.setItem('response_id', response.data.audit_id);
                        this.router.navigate(['app/process-analysis']);
                    }
            }, (rejection) => {
                this.errorList.push(rejection.error.data);
            });
        }
    }

    showConfirm() {
        this.new_user_details.user_id = this.user_id;
        this.new_user_details.email = this.username;
        this.dialogService.addDialog(ChangePasswordComponent, this.new_user_details)
            .subscribe((response: any) => {
                if (response !== false) {
                    this.success = response;
                }
            });
    }
}
