import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-population-frequencies',
  templateUrl: './population-frequencies.component.html',
  styleUrls: ['./population-frequencies.component.css']
})
export class PopulationFrequenciesComponent implements OnInit {

  @Input('popFrequencyData') popFrequencyData: any = {};
  @Output('filterChanged') filterChanged = new EventEmitter<any>();
  exAcAfPrefix = 'ex_ac_af';
  thGenomePrefix = 'thousand_genomes_af';
  gmePrefix = 'gme';
  gnomPrefix = 'gnom_ad';
  filterName: string;

  displayValues: any = {
    gte: 'Atleast',
    lt: 'less than',
    perc: '%',
    count: 'count',
    all: 'All',
    afr: 'African/African American (AFR)',
    amr: 'Latino (AMR)',
    asn: 'East Asian (EAS)',
    fin: 'Finnish (FIN)',
    nfe: 'Non Finnish European (NFE)',
    sas: 'South Asian (SAS)',
    popmax: 'PopMax',
    other: 'Other (OTH)',
    af: '%',
    ac: 'count'
  };

  
  ex_ac_values: any = {
    all: 'All',
    afr: 'African(AFR)',
    amr: 'Ad Mixed American(AMR)',
    asn: 'Asia(ASN)',
    eur: 'European(EUR)'
  };


  constructor() {
  }

  ngOnInit() {
    this.filterName = this.popFrequencyData.name;
    if (this.popFrequencyData.options.ex_ac_field) {
      const initialExac = this.popFrequencyData.options.ex_ac_field.replace(this.exAcAfPrefix, '');
      if (initialExac) {
        const i = initialExac.split('_');
        this.popFrequencyData.options.ex_ac_field1 = i[2];
        this.popFrequencyData.options.ex_ac_field2 = i[1];
      }
    }
    if (this.popFrequencyData.options.thousand_genomes_field) {
      const initialThGenome = this.popFrequencyData.options.thousand_genomes_field.replace(this.thGenomePrefix, '');
      if (initialThGenome) {
        const i = initialThGenome.split('_');
        this.popFrequencyData.options.genomeField = i[1];
      }
    }
    if (this.popFrequencyData.options.gnom_ad_field) {
      const initialGnom = this.popFrequencyData.options.gnom_ad_field.replace(this.gnomPrefix, '');
      if (initialGnom) {
        const i = initialGnom.split('_');
        this.popFrequencyData.options.gnom_ad_field2 = i[1];
        this.popFrequencyData.options.gnom_ad_field1 = i[2];
      }
    }
    if (this.popFrequencyData.options.gme_field) {
      const initialGme = this.popFrequencyData.options.gme_field.replace(this.gmePrefix, '');
      if (initialGme) {
        const i = initialGme.split('_');
        this.popFrequencyData.options.gme_field1 = i[1];
      }
    }
  }

  setData({ target }) {
    const { value, name, checked, type } = target;
    const val = type === 'checkbox' ? checked : value;
    this.popFrequencyData.options[name] = val;

    const dependentModulesAttr = target.getAttribute('attr.dependent-models');
    if (dependentModulesAttr) {
      const models = dependentModulesAttr.split(',').map(a => a.trim());
      models.forEach(m => {
        this._filterChanged(m, checked ? this.popFrequencyData.options[m] : null);
      });
    }

    this._filterChanged(name, val);
  }

  handleChange(field, ...rest) {
    this._filterChanged(field, rest.join('_'));
  }

  _filterChanged(filterName, value) {
    let data;
    if (!this.popFrequencyData.options.thousand_genomes && !this.popFrequencyData.options.ex_ac
      && !this.popFrequencyData.options.gnom_ad && !this.popFrequencyData.options.gme) {
      data = {
        name: this.filterName,
        options: null
      };
    } else {
      data = {
        name: this.filterName,
        options: {
          type: `com.pki.ngs.entities.PopFreqFilter`,
          keep_exclude: this.popFrequencyData.options.keep_exclude,
          zygosity: this.popFrequencyData.options.zygosity,
          any_all: this.popFrequencyData.options.any_all
        }
      };
      data.options[filterName] = value;
    }
    this.filterChanged.emit(data);
  }

  filterNameChanged() {
    let data;
    if (!this.popFrequencyData.options.thousand_genomes && !this.popFrequencyData.options.ex_ac
      && !this.popFrequencyData.options.gnom_ad && !this.popFrequencyData.options.gme) {
      data = {
        name: this.filterName,
        options: null
      };
    } else {
      data = {
        name: this.filterName,
        options: {
          type: `com.pki.ngs.entities.PopFreqFilter`,
          keep_exclude: this.popFrequencyData.options.keep_exclude,
          zygosity: this.popFrequencyData.options.zygosity,
          any_all: this.popFrequencyData.options.any_all
        }
      };
    }
    this.filterChanged.emit(data);
  }
}
