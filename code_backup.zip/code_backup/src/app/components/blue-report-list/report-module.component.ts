import { Component, OnInit, Output, EventEmitter, ElementRef, ViewChild } from '@angular/core';
import { ReportModuleService } from '../../common/services/report-module.service';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-report-module',
  templateUrl: './report-module.component.html',
  styleUrls: ['./report-module.component.css']
})
export class ReportModuleComponent implements OnInit {
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  @ViewChild('createNewTempId') newTemplate: ElementRef;
  @ViewChild('createNewTempId') listTemplate: ElementRef;

  bool_new_template = false;
  offset: number;
  firstRecord: number;
  limit = 10;
  filterPayload: any;
  sortBy = 'created_on';
  sortDir = 'desc';
  gridContent: any;
  totalRecords: any;
  report_id: any;
  editData: any;
  createReport: boolean = false;
  savedMessage: string;
  createTemplateStatus: boolean = false;
  constructor(
    private service: ReportModuleService
  ) { }

  ngOnInit() {
  }

  createNewTemplate() {
    this.editData = {};
    this.createTemplateStatus = true;
    this.createReport = true;
  }

  getFileData() {
    this.service.getAllReportData(this.sortBy, this.sortDir, this.offset, this.limit, this.filterPayload).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.gridContent = [...response.data.reportTemplateWrapperList];
      this.totalRecords = response.data.totalCount;
    });
  }

  lazyLoadData(event) {
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = event.first / event.rows;
    this.firstRecord = event.first;
    this.sortBy = event.sortField ? event.sortField : 'id';
    this.sortDir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    const filters = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});
    this.filterPayload = filters ? filters : {};
    this.getFileData();
  }

  onNotify(message: string): void {
    //this.hideTab();
    this.getFileData();
    this.createTemplateStatus = false;
  }

  editTemplate(value) {
    this.report_id = value.id;
    this.service.geteditReportSections(this.report_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.editData = response.data;
      this.createTemplateStatus = true;
      this.createReport = false;
    });
  }

  getEditReportSection() {
  }

  deleteTemplate() {
    this.service.deleteReportTemplate(this.report_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.savedMessage = response.data;
      $('#deleteAlert').modal('toggle');
      this.getFileData();
      this.report_id = null;
    }, (err) => {
      this.savedMessage = err.error.data;
      $('#deleteAlert').modal('toggle');
    });
  }

  deleteReportTemplate(dataItem) {
    this.report_id = dataItem.id
    $('#deleteTemplateModal').modal('toggle');
  }

}
