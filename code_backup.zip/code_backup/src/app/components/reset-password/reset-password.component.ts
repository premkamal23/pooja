import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { UserManagementService } from '../../common/services/user-management.service';

export interface passwordData {
  user: string;
  loc: string;
}

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent extends DialogComponent<passwordData, any> implements passwordData, OnInit {

  user: string;
  password: string;
  error_msg: string;
  confirm_password: string;
  loc: string;
  errorList: Array<any>;

  constructor(dialogService: DialogService,
    private userservice: UserManagementService) {
    super(dialogService);
  }

  ngOnInit() {
    this.clearError();
  }

  clearError() {
    this.errorList = [];
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  resetPassword() {
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
    this.clearError();
    if (!passwordRegex.test(this.password)) {
      this.errorList.push('Please enter valid password. The password should be atleast 8 characters long, alphanumeric and with one special character.');
    } else {
      this.userservice.resetPassword(this.user, this.password, this.confirm_password).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        if (this.loc === 'user_management') {
          this.result = 'Password has been reset successfully.'
        } else {
          this.result = 'Your password has been changed successfully. Login again to continue.';
        }
        this.close();
      },
        (error: any) => {
          this.clearError();
          console.error(error.error.data);
          this.errorList.push(error.error.data);
        });
    }
  }

}
