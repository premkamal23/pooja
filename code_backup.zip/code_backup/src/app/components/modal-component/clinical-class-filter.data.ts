const ClinicalClassFilter = {
    'name': 'Clinical Classification',
    'options': {
        'type': 'com.pki.ngs.entities.ClinicalClassFilter',
        'keep_exclude': 'keep',
        'zygosity': 'All',
        'any_all': 'any',
        'clinvar': false,
        'clinvar_all': false,
        'clinvar_options': [],
        'snpeff': false,
        'snpeff_all': false,
        'snpeff_options': [],
        'emv_class': false,
        'emv_class_options': [],
        'hgmd_class': false,
        'hgmd_class_options': [],
        'polyphen_hdiv': false,
        'polyphen_hdiv_options': [],
        'sift': false,
        'sift_options': [],
        'mutation_taster': false,
        'mutation_taster_options': [],
        'pki_class': false,
        'pki_class_options': []
    }
};

export {
    ClinicalClassFilter
};
