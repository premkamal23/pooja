const phenotypeFilter = {
    'name': 'Phenotype',
    'options': {
        'type': 'com.pki.ngs.entities.PhenotypeFilter',
        'keep_exclude': 'keep',
        'zygosity': 'All',
        'any_all': 'any',
        'omim': false,
        'omim_all': false,
        'omim_options': []
    }
};

export {
    phenotypeFilter
};
