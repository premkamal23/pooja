const PopFreqFilter = {
    'name': 'Population Frequency',
    'options': {
        'type': 'com.pki.ngs.entities.PopFreqFilter',
        'keep_exclude': <string>'keep',
        'zygosity': <string>'All',
        'any_all': <string>'any',
        'thousand_genomes': <boolean>false,
        'thousand_genomes_op': <string>'gte',
        'thousand_genomes_value': <number>3,
        'genomeField': <string>'all',
        'thousand_genomes_field': <string>'thousand_genomes_af_all',

        'ex_ac': <boolean>false,
        'ex_ac_op': <string>'gte',
        'ex_ac_value': <number>3,
        'ex_ac_field1': <string>'perc',
        'ex_ac_field1Value': <string>'perc',
        'ex_ac_field2': <string>'all',
        'ex_ac_field2Value': <string>'all',
        'ex_ac_field': <string>'ex_ac_af_all_perc',

        'gnom_ad': <boolean>false,
        'gnom_ad_value': <number>3,
        'gnom_ad_op': <string>'gte',
        'gnom_ad_field1': <string>'perc',
        'gnom_ad_field1Value': <string>'perc',
        'gnom_ad_field2': <string>'all',
        'gnom_ad_field2Value': <string>'all',
        'gnom_ad_field': <string>'gnom_ad_all_perc',

        'gme': <boolean>false,
        'gme_op': <string>'gte',
        'gme_value': <number>3,
        'gme_field1': <string>'af',
        'gme_field': <string>'gme_af'
    }
};

export {
    PopFreqFilter
};
