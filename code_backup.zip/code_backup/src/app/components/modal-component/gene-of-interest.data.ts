const geneOfInterestFilter = {
    'name': 'Genes of Interest',
    'options': {
        'type': 'com.pki.ngs.entities.GoiFilter',
        'keep_exclude': <string>'keep',
        'zygosity': <string>'All',
        'any_all': <string>'any',
        'goi': false,
        'goi_options': [],
        'chrom': false,
        'chrom_options': [],
        'varient_type': false,
        'varient_options': []
    }
};

export {
    geneOfInterestFilter
};
