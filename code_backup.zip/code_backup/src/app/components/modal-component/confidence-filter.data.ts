const ConfidenceFilter = {
    'name': 'Confidence',
    'options': {
        'type': 'com.pki.ngs.entities.ConfidenceFilter',
        'keep_exclude': 'keep',
        'any_all': 'any',
        'variant_filter': false,
        'variant_filter_op': 'eq',
        'variant_filter_value': 'PASS',
        'call_quality': false,
        'call_quality_op': 'gte',
        'call_quality_value': 30,
        'read_depth': false,
        'read_depth_op': 'gte',
        'read_depth_value': 30,
        'gq': false,
        'gq_op': 'gte',
        'gq_value': 30,
        'allele_fraction': false,
        'allele_fraction_op': 'gte',
        'allele_fraction_value': 30,
        'allele_fraction_higher_value': 50
    }
};

export {
    ConfidenceFilter
};
