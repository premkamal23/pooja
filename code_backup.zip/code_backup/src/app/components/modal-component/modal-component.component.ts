import { cloneDeep, mergeWith } from 'lodash';
import { OpenAnalysisService } from '../../common/services/open-analysis.service';
import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { get as GetAccordionDescriptor } from './accordion-descriptor.data';

interface IGlobalElement {
  analysis_id: number;
  gene_class: string;
  location: string;
  sub_type: string;
  filter_categories: any;
  isEdit: boolean;
  sample_flag: boolean;
}

@Component({
  selector: 'app-modal-component',
  templateUrl: './modal-component.component.html',
  styleUrls: ['./modal-component.component.css']
})
export class ModalComponentComponent extends DialogComponent<IGlobalElement, any> implements OnInit, IGlobalElement {
  gene_class: string;
  analysis_id: number;
  sample_flag: boolean;
  id: number = 0;
  location: string;
  sub_type: string;
  isEdit: boolean;
  filter_categories: any;
  filterType = 'Confidence';
  filterElement = 'app-confidence';
  filterChain: Array<any> = [];
  dashboardData: any;
  filterArray: any;
  rowData: any;
  data = {};
  modalform: any;
  mainFilterName = '';
  mainStatus = false;
  alertForName: boolean;
  sample_boolean: boolean;
  nameBoolean = false;
  name_value = '';
  openAccordionName = 'Confidence';
  accordionDescriptor: any[];
  currentAddIndex = 0;
  subscription: any;
  interval: any;
  groups: Array<any> = [];
  constructor(
    dialogService: DialogService,
    private openanalysisService: OpenAnalysisService
  ) {
    super(dialogService);
  }


  ngOnInit() {
    this.nameBoolean = this.sample_flag ? true : false;
    this.getAllFilterName();
    this.checkSampleFilter();
    if (this.isEdit) {
      this.mainStatus = true;
    } else {
      this.nameCheck();
    }
    this.accordionDescriptor = GetAccordionDescriptor();
    this.accordionDescriptor = this.accordionDescriptor.map(ad => {
      ad.outputs = {
        filterChanged: this.filterChanged.bind(this)
      };
      return ad;
    });
    if (this.filter_categories) {
      this.filter_categories.filter_categories.forEach(f => {
        const current = this.accordionDescriptor.find(ad => ad.filterId === f.options.type);
        const keyName = Object.keys(current.inputs).pop();
        current.inputs[keyName] = f;
      });
      this.filterChain = cloneDeep(this.filter_categories.filter_categories);
      this.mainFilterName = cloneDeep(this.filter_categories.name);
      this.adjustAccordions();
    } else {
      this.filterChain = [];
    }
    const self: any = this;
    if (self.isEdit) {
      this.openanalysisService.setIsEditFilter();
    } else {
      this.openanalysisService.unSetIsEditFilter();
    }
  }

  checkSampleFilter() {
    this.openanalysisService.checkforSampleFilter(this.analysis_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.sample_boolean = response.data;
    });
  }


  confirm() {
    this.result = true;
    this.close();
    this.confirm();
  }

  filterChanged(filter) {
    if (filter.options !== null) {
      const customMerge = (o, s, key) => {
        if (key.endsWith('_options')) {
          if (Array.isArray(s)) {
            return s;
          }
        }
      };
      let current = this.filterChain.find(f => f.options.type === filter.options.type);
      if (current) {
        current = mergeWith(current, filter, customMerge);
      } else {
        this.filterChain.push(filter);
      }
    } else {
      for (let i = 0; i < this.filterChain.length; i++) {
        if (this.filterChain[i].name === filter.name) {
          this.filterChain.splice(i, 1);
          break;
        }
      }
    }
  }

  accordionOpened(isOpen, title) {
    this.openAccordionName = isOpen ? title : '';
  }

  setRefiningFilter() {
    if (this.mainFilterName.includes('Sample_Filter_')) {
      this.result = {
        name: this.mainFilterName,
        sample_filter_value: this.nameBoolean,
        analysis_id: this.analysis_id,
        filter_categories: this.filterChain
      }
      if (this.sample_flag) {
        this.openanalysisService.editRefiningFilter(this.result).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.close();
        });
      } else {
        this.openanalysisService.saveRefiningFilter(this.result).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.close();
        });
      }
    } else {
      this.result = {
        name: this.mainFilterName,
        sample_filter_value: this.nameBoolean,
        analysis_id: this.id,
        filter_categories: this.filterChain
      };
      this.close();
    }
  }

  swapPositions(original, index, up) {
    const clone = cloneDeep(original);
    const newIndex = up ? index - 1 : index + 1;
    const fromElement = cloneDeep(clone[index]);
    const toElement = cloneDeep(clone[newIndex]);

    clone[newIndex] = fromElement;
    clone[index] = toElement;

    return clone;
  }

  adjustAccordions(): void {
    const availableFilterAccordions = this.filterChain.map(fc => this.accordionDescriptor.find(avd => avd.filterId === fc.options.type));
    const remainintAccordions = this.accordionDescriptor.filter(ad => {
      const index = availableFilterAccordions.findIndex(avd => avd.filterId === ad.filterId);
      return index === -1;
    });
    this.accordionDescriptor = availableFilterAccordions.concat(remainintAccordions);
    this.openAccordionName = this.accordionDescriptor[0].title;
  }

  adjustFilters(): void {
    const updatedFilterChain = [];
    this.accordionDescriptor.forEach(ad => {
      const currentFilterType: string = ad.filterId;
      const currentFilter = this.filterChain.find(fc => fc.options.type === currentFilterType);
      if (currentFilter) {
        updatedFilterChain.push(currentFilter);
      }
    });

    this.filterChain = updatedFilterChain;
  }

  shuffle({ component, filterId }, moveUp) {
    const componentIndex = this.accordionDescriptor.findIndex(ac => ac.component === component);
    const filterIndex = this.filterChain.findIndex(fc => fc.options.type === filterId);
    if (componentIndex === 0 && moveUp) {
      return;
    } else if (componentIndex === this.accordionDescriptor.length - 1 && !moveUp) {
      return;
    }

    this.accordionDescriptor = this.swapPositions(this.accordionDescriptor, componentIndex, moveUp);
    this.adjustFilters();
  }

  closeModal() {
    this.result = {
      name: 'No Filter'
    };
    this.close();
  }

  getAllFilterName() {
    this.filterArray = [];
    let sessionFilters;
    this.openanalysisService.getFilters(this.analysis_id)
      .subscribe((data: any) => {
        const authToken = data.token;
        if (data.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        let filters = [];
        this.dashboardData = data.data;
        if (this.dashboardData.content.length !== 0) {
          filters = this.dashboardData.content.map(c => c.name);
          this.filterArray = this.filterArray.concat(filters);
        }
        sessionFilters = sessionStorage.getItem('sessionFilters');
        if (sessionFilters) {
          sessionFilters = JSON.parse(sessionStorage.getItem('sessionFilters'));
          const sessionFilterNames = sessionFilters.map(f => f.name);
          this.filterArray = this.filterArray.concat(sessionFilterNames);
        }
      });
  }

  checkForSamplefilter(value) {
    this.nameBoolean = value === 'sample' ? true : false;
    this.mainFilterName = this.nameBoolean ? 'Sample_Filter_' + this.analysis_id : '';
    this.mainStatus = this.nameBoolean ? true : false;
    this.id = value === 'sample' ? this.analysis_id : 0;
  }

  nameCheck() {
    this.mainStatus = this.mainFilterName === '' ? false : true;
    for (let i = 0; i < this.filterArray.length; i++) {
      if (this.filterArray[i] === this.mainFilterName) {
        this.alertForName = true;
        this.mainStatus = false;
        break;
      } else if (this.mainFilterName === '') {
        this.alertForName = false;
        this.mainStatus = false;
      } else {
        this.alertForName = false;
        this.mainStatus = true;
      }
    }
  }

  mainFiltercheck() {
    this.alertForName = false;
  }

  checkIfEditOrAdd() {
    let flag = false;
    for (let i = 0; i < this.dashboardData.content.length; i++) {
      if (this.dashboardData.content[i].name === this.mainFilterName) {
        flag = true;
        break;
      }
    }
    return flag;
  }
}

