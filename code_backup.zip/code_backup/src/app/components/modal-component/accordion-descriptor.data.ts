import { ClinicalClassificationComponent } from '../clinical-classification/clinical-classification.component';
import { ConfidenceComponent } from '../confidence/confidence.component';
import { GenesOfInterestComponent } from '../genes-of-interest/genes-of-interest.component';
import { PhenotypesComponent } from '../phenotypes/phenotypes.component';
import { PopulationFrequenciesComponent } from '../population-frequencies/population-frequencies.component';

import { cloneDeep } from 'lodash';


import { ClinicalClassFilter } from './clinical-class-filter.data';
import { ConfidenceFilter } from './confidence-filter.data';
import { PopFreqFilter } from './pop-freq-filter.data';
import { phenotypeFilter } from './phenotype.data';
import { geneOfInterestFilter } from './gene-of-interest.data';

function get() {
    return [
        {
            title: 'Confidence',
            component: ConfidenceComponent,
            filterId: ConfidenceFilter.options.type,
            inputs: {
                confidenceData: cloneDeep(ConfidenceFilter)
            }
        },
        {
            title: 'Population Frequencies',
            component: PopulationFrequenciesComponent,
            filterId: PopFreqFilter.options.type,
            inputs: {
                popFrequencyData: cloneDeep(PopFreqFilter)
            }
        },
        {
            title: 'Clinical Classification',
            component: ClinicalClassificationComponent,
            filterId: ClinicalClassFilter.options.type,
            inputs: {
                clinClassData: cloneDeep(ClinicalClassFilter)
            }
        },
        {
            title: 'Phenotype',
            component: PhenotypesComponent,
            filterId: phenotypeFilter.options.type,
            inputs: {
                phenotypeData: cloneDeep(phenotypeFilter)
            }
        },
        {
            title: 'Genes of interest',
            component: GenesOfInterestComponent,
            filterId: geneOfInterestFilter.options.type,
            inputs: {
                geneOfInterestData: cloneDeep(geneOfInterestFilter)
            }
        }
    ];
}

export {
    get
};
