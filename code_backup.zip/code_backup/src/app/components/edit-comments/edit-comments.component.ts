import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';

export interface commentsData {
  comments: string;
}

@Component({
  selector: 'app-edit-comments',
  templateUrl: './edit-comments.component.html',
  styleUrls: ['./edit-comments.component.css']
})
export class EditCommentsComponent extends DialogComponent<commentsData, any> implements commentsData, OnInit {

  comments: string;

  constructor(
    dialogService: DialogService
  ) {
    super(dialogService);
  }

  ngOnInit() {
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  editComments() {
    this.result = {
      'comment': this.comments
    }
    this.close();
  }
}
