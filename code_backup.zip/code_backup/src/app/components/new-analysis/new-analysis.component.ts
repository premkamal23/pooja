import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProjectService } from '../../common/services/project.service';
import { HttpClient } from '@angular/common/http';
import { DialogService } from 'ng2-bootstrap-modal';
import { OdinfilesListComponent } from '../odinfiles-list/odinfiles-list.component';
declare var $: any;

interface IType {
  PROBAND?: any;
  MOTHER?: any;
  FATHER?: any;
  SIBLING_1?: any;
  SIBLING_2?: any;
}

@Component({
  selector: 'app-new-analysis',
  templateUrl: './new-analysis.component.html',
  styleUrls: ['./new-analysis.component.css']
})
export class NewAnalysisComponent implements OnInit {

  projectURL = '/api/createProject';
  projectList = ['Select Project ', 'Create New Project'];
  clientList: any;
  rowData = [];
  odinfiles = [];
  odinFilesTemp: IType = {};
  fileData = [];
  client: number;
  client_name: string;
  panel: string;
  project = 'Select';
  projectName: string;
  analysisName: string;
  comments = '-';
  totalRecords: number;
  clientResponse = false;
  projectResponse = false;
  probandValue = false;
  maternalValue = false;
  paternalValue = false;
  sibling1Value = false;
  sibling2Value = false;
  clientBoolean = false;
  projectBoolean = false;
  analysisBoolean = false;
  typeBoolean = false;
  getFilesDetails: any;
  exclude_non_coding: boolean = true;
  exclude_deep_intron: boolean = false;
  type: string;
  fileSelected = false;
  clientDetails = {
    client: this.client,
    vcf: this.fileSelected,
    type: this.type
  };

  constructor(
    private routes: Router,
    private projectService: ProjectService,
    private http: HttpClient,
    private dialogService: DialogService
  ) {
  }

  ngOnInit() {
    this.getClient();
  }

  openProgressDashboard() {
    this.routes.navigate(['app/process-analysis']);
  }

  getOdinFiles() {
    this.clientDetails.client = this.client;
    this.clientDetails.vcf = this.fileSelected;
    this.dialogService.addDialog(OdinfilesListComponent, this.clientDetails)
      .subscribe((response: any) => {
        if (response !== false) {
          if (response.type === 'PROBAND') {
            this.probandValue = true;
          }
          this.odinFilesTemp[response.type] = response;
        }
      });
  }

  getClient() {
    const user_id = sessionStorage.getItem('user_id');
    this.http.get('/api/client/user/' + user_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.clientList = response.data;
      this.client = this.clientList[0].id;
      this.getProjectData();
    });
  }

  getProjectData() {
    this.projectService.getfileName().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      for (let i = 0; i < response.data.length; i++) {
        this.projectList = this.projectList
          .concat(response.data[i])
          .filter((key, index, array) => {
            return array.indexOf(key) === index;
          });
      }
    });
  }

  selectProject() {
    this.projectResponse = this.project === 'Create New Project';
    this.projectName = this.projectResponse ? this.projectName : undefined;
    this.projectBoolean = true;
  }

  loadData() {
    for (let i = 0; i < this.clientList.length; i++) {
      if (Number(this.client) === this.clientList[i].id) {
        this.client_name = this.clientList[i].name;
        break;
      }
    }
    this.createNewAnalysis(this[this.projectResponse ? 'projectName' : 'project'], this.client_name);
  }

  checkForDuplication() {
    this.odinfiles = Object.keys(this.odinFilesTemp).map(key => {
      return this.odinFilesTemp[key];
    });
    for (var i = 0; i < this.odinfiles.length; i++) {
      for (var j = 0; j < this.odinfiles.length; j++) {
        if (i != j && this.odinfiles[i].name === this.odinfiles[j].name) {
          return true;
        }
      }
    }
    return false;
  }

  createNewAnalysis(createdProject, createdClient) {
    const bool = this.checkForDuplication();
    if (bool) {
      $('#duplicateValue').modal('toggle');
    } else {
      const data = {
        'owner': sessionStorage.getItem('user'),
        'proj_name': createdProject,
        'proj_owner': sessionStorage.getItem('user'),
        'client_id': this.client,
        'client_name': createdClient,
        'name': this.analysisName,
        'email': sessionStorage.getItem('email'),
        'analysis_type': this.panel,
        'comments': this.comments,
        'nodes': this.odinfiles,
        'exclude_non_coding': this.exclude_non_coding,
        'exclude_deep_intron': this.exclude_deep_intron
      };
      this.projectService.createNewAnalysis(this.fileSelected, data).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        if (response) {
          this.rowData = response;
          this.openProgressDashboard();
        }
      });
    }
  }

  valueCheck(event) {
    this.clientDetails.type = event.target.value;
    this.getOdinFiles();
  }

  handleValueCheck() {
    this.analysisBoolean = this.analysisName === '' ? false : true;
  }

  setFileType(event) {
    this.odinFilesTemp = {};
    this.fileSelected = event;
  }

  removeFromArray(nodeName) {
    nodeName === 'PROBAND' ? this.probandValue = false : true;
    nodeName === 'PROBAND' ? delete this.odinFilesTemp.PROBAND :
      nodeName === 'MOTHER' ? delete this.odinFilesTemp.MOTHER :
        nodeName === 'FATHER' ? delete this.odinFilesTemp.FATHER :
          nodeName === 'SIBLING_1' ? delete this.odinFilesTemp.SIBLING_1 : delete this.odinFilesTemp.SIBLING_2
  }

}
