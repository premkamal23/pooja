import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { ProjectService } from '../../common/services/project.service';
import { data } from './variant-data'

export interface filterData {
  analysis_id: string;
  gene_class: string;
  location: string;
  filter: any;
}

@Component({
  selector: 'add-variant-analysis',
  templateUrl: './add-variant-analysis.component.html',
  styleUrls: ['./add-variant-analysis.component.css']
})
export class AddVariantAnalysisComponent extends DialogComponent<filterData, any> implements filterData, OnInit {

  analysis_id: string;
  gene_class: string;
  location: string;
  filter: any;
  chromosome: string = '';
  startPos: number
  endPos: number;
  ref: string;
  alt: string;
  errorMsg: string;
  errorList = [];
  variantObj: data = {};
  load = false;
  constructor(
    dialogService: DialogService,
    private service: ProjectService
  ) {
    super(dialogService);
    //document.getElementById("overlay").style.display = "none";
  }

  ngOnInit() {
   // document.getElementById("overlay").style.display = "none";
    this.load = false;
    this.variantObj.analysis_id = this.analysis_id;
    this.variantObj.gene_class = this.gene_class;
    this.variantObj.location = this.location;
    this.variantObj.sub_type = this.filter;
    this.variantObj.priority = 'high'
  }

  addVariant() {
    this.clearError();
    if (this.variantObj.chrom === '' || this.variantObj.chrom === undefined) {
      this.errorList.push('Please enter Chromosome value');
    }
    if (this.variantObj.genomic_start === null || this.variantObj.genomic_start === undefined) {
      this.errorList.push('Please enter Start position value');
    }
    if (this.variantObj.genomic_stop === null || this.variantObj.genomic_stop === undefined) {
      this.errorList.push('Please enter End position value');
    }
    if (this.variantObj.ref === '' || this.variantObj.ref === undefined) {
      this.errorList.push('Please enter Ref value');
    } if (this.variantObj.alt === '' || this.variantObj.alt === undefined) {
      this.errorList.push('Please enter Alt value');
    } if (this.errorList.length > 0) {

    } else {
      //document.getElementById("overlay").style.display = "block";
      this.load = true;
      this.service.addVariant(this.variantObj).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.result = 'success';
        this.close();
        //document.getElementById("overlay").style.display = "none";
        this.load = false;
      }, (err) => {
        this.errorMsg = err.error.data;
        this.load = false;
        //document.getElementById("overlay").style.display = "none";
      });
    }
  }

  closeModal() {
    this.result = 'failed';
    this.close();
  }

  // o4n() {
  //   document.getElementById("overlay").style.display = "";
  // }

  clearError() {
    this.errorList = [];
  }

}
