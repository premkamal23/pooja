export interface data {
    analysis_id?: string,
    gene_class?: string,
    location?: string
    sub_type?: number,
    priority?: string,
    chrom?: string,
    genomic_start?: number,
    genomic_stop?: number,
    ref?: string,
    alt?: string
}