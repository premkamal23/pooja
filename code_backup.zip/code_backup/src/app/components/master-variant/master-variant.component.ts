import { Component, OnInit, ViewChild } from '@angular/core';
import { MasterTablesService } from '../../common/services/master-tables.service';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DialogService } from 'ng2-bootstrap-modal';
import { AcmgCalculatorComponent } from '../acmg-calculator/acmg-calculator.component';
import { AddVariantMasterComponent } from '../add-variant-master/add-variant-master.component';
import { ClinicalNotesService } from '../../common/services/clinical-notes.service';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { merge } from 'lodash';
import { ProjectService } from '../../common/services/project.service';
declare var $: any;

@Component({
  selector: 'app-master-variant',
  templateUrl: './master-variant.component.html',
  styleUrls: ['./master-variant.component.css']
})
export class MasterVariantComponent implements OnInit {
  selectedrow: any;
  acmgUrl = '/api/acmgResult';
  Gridcontent: any;
  apiResponse: any;
  totalRecords: number;
  selectedRow: any;
  firstRecord = 0;
  column_name = 'chrom';
  client_list: any;
  client_ids = [];
  filterPayload: any;
  filters: any;
  sort = 'asc';
  offset = 0;
  limit = 15;
  alert = false;
  showSaveAlert = false;
  variant_name: string;
  clinical_notes_list: any;
  clinical_report: any;
  clinical_report_dialogue: string;
  variant_boolean = false;
  boolpaginate = false;
  sub: any;
  filterApplied = false;
  lowerPanelContentLength: number;
  lowerPanelContent: any;
  whatTime: any;
  ACMGOutput: any;
  saveSelectedRow: any;
  report_notes = '';
  success = false;
  addVariantPermissions = false;
  disableVariantCreation = false;
  analysisRunningURL = '/api/analysis/isRunning';
  acmgDetails: any = {
    'acmgData': this.ACMGOutput
  };
  pki_class_list: any;
  rowChangeCount: any = 1;
  saveFlag: boolean = false;
  rowchangeNewFlag: boolean = false;
  alertCount: any = 0;
  notesSectionClicked: boolean = false;

  @ViewChild("ckeditor") ckeditor: any;
  CkeditorConfig = {
    allowedContent: true,
    height: 100,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    // autoParagraph: false,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '12',
    // enterMode: 2,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };

  edit_clinical_report: boolean = false;
  NotesCkeditorConfig = {
    allowedContent: true,
    height: 510,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    // autoParagraph: false,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    // enterMode: 2,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker,JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock'
  };
  constructor(
    private service: MasterTablesService,
    private route: Router,
    private routes: ActivatedRoute,
    private dialogService: DialogService,
    private http: HttpClient,
    private dashboard: DashboardComponent,
    private projService: ProjectService,
    private notesService: ClinicalNotesService
  ) { }

  ngOnInit() {
    this.sub = this.routes
      .queryParams
      .subscribe(params => {
        this.variant_name = params.gene;
      });
    this.getPkiClass();
    const permissions = sessionStorage.getItem('permissions').split(',');
    this.edit_clinical_report = permissions.includes('EDIT_CLINICAL_REPORT_DATA') ? true : false;
    this.addVariantPermissions = permissions.includes('ADD_NEW_VARIANT') ? true : false;
    this.getAnalysisStatus();
  }

  getAnalysisStatus() {
    this.http.get(this.analysisRunningURL).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.disableVariantCreation = response.data;
    });
  }

  getPkiClass() {
    this.projService.getPKIClass().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.pki_class_list = response.data.content;
      this.getClinicalNotes();
    });
  }

  getReportNotes(val) {
    this.report_notes = val;
  }

  setReportNotes() {
    this.selectedRow.clinical_report_data.report_notes = this.report_notes;
  }

  getClinicalNotes() {
    this.notesService.getClinicalNotes().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.clinical_notes_list = response.data;
    });
  }

  getClinicalReports() {
    if (this.selectedRow.clinical_report_data.report_notes !== '') {
      this.selectedRow.clinical_report_data.report_notes = this.selectedRow.clinical_report_data.report_notes + this.clinical_report
    } else {
      this.selectedRow.clinical_report_data.report_notes = this.clinical_report;
    }
    this.alert = true;
  }

  getClinicalReportsOnNotesDialogue(report_notes) {
    if (this.report_notes !== '') {
      this.report_notes = this.report_notes + this.clinical_report_dialogue;
    } else {
      this.report_notes = this.clinical_report_dialogue;
    }
  }

  getAlert() {
    this.alert = true;
    this.whatTime = new Date();
    this.selectedRow.clinical_report_data.pki_modified = this.whatTime.getTime();
    this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
    this.selectedrow = this.selectedRow;
  }

  setClickedFlag($event: any): void {
    this.notesSectionClicked = true;
  }

  onChange($event: any): void {
    if ((this.rowChangeCount > 0 && this.rowchangeNewFlag === false && this.saveFlag === false && this.alert === false) || this.alert) {
      this.whatTime = new Date();
      this.selectedRow.clinical_report_data.pki_modified = this.whatTime.getTime();
      this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
      if (this.alert) {
        this.selectedrow = this.selectedRow;
      }
      if (this.notesSectionClicked) {
        this.alert = true;
      }
      //this.alert = true;
    }
    this.rowChangeCount = 1;
    this.rowchangeNewFlag = false;
    this.saveFlag = false;
  }

  getAllVariants() {
    this.getClientIDs();
    this.service.getVariantData(this.column_name, this.sort, this.offset, this.limit).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.variant_boolean = false;
      this.saveSelectedRow = this.selectedRow;
      this.apiResponse = response.data.content;
      this.totalRecords = response.data.totalElements;
      this.Gridcontent = [...this.apiResponse];
      if (this.selectedRow) {
        for (let i = 0; i < this.apiResponse.length; i++) {
          if (this.saveSelectedRow.chrom_start_stop_ref_alt === this.apiResponse[i].chrom_start_stop_ref_alt) {
            this.selectedRow = this.apiResponse[i];
            break;
          } else {
            this.selectedRow = response.data.content[0];
          }
        }
      } else {
        this.selectedRow = response.data.content[0];
      }
      this.getOtherAnalysisData();
    });
  }

  getVariantbyGene() {
    this.service.getVariantfromGene(this.variant_name).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.variant_boolean = true;
      this.selectedRow = response.data;
      let responseArray = [];
      responseArray = responseArray.concat(response.data);
      this.totalRecords = responseArray.length;
      this.Gridcontent = responseArray;
      this.getOtherAnalysisData();
    });
  }

  closeAlert() {
    this.success = false;
    this.selectedRow = this.selectedrow;
  }

  onRowClick(event) {
    const variant_id = event.data.chrom_start_stop_ref_alt;
    this.getOtherAnalysisData();
    if (this.alert && this.alertCount === 0) {
      this.rowChangeCount = 0;
      this.rowchangeNewFlag = true;
      this.success = true;
      if (this.success) {
        $('#AlertonPKIChange').modal('toggle');
      }
      this.alert = false;
      this.alertCount = 1;
    }
    else if (this.alert && this.alertCount > 0) {
      this.alert = false;
      this.alertCount = 0;
      this.rowChangeCount = 0;
      this.rowchangeNewFlag = true;
    }
    else {
      this.selectedRow = event.data;
      this.alert = false;
      this.rowChangeCount = 0;
      this.rowchangeNewFlag = true;
      this.alertCount = 0;
    }
    this.saveFlag = false;
  }

  paginate(event) {
    this.boolpaginate = true;
    this.firstRecord = event.first;
    this.offset = event.first / event.rows;
    this.limit = event.rows;
    if (this.filters) {
      this.service.getFilteredData(this.column_name, this.sort, this.offset, this.limit, this.filters)
        .subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.variant_boolean = false;
          this.selectedRow = response.data.content[0];
          this.apiResponse = response.data.content;
          this.totalRecords = response.data.totalElements;
          this.Gridcontent = [...this.apiResponse];
          this.getOtherAnalysisData();
        });
    } else {
      this.getAllVariants();
    }

  }

  lazyLoadData(event) {
    this.sub = this.routes
      .queryParams
      .subscribe(params => {
        this.variant_name = params.variant;
      });
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = 0;
    this.firstRecord = event.first;
    this.column_name = event.sortField ? event.sortField : 'chrom';
    this.sort = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    this.filters = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});
    if (this.variant_name) {
      this.getVariantbyGene();
    } else {
      if (key.length !== 0) {
        this.service.getFilteredData(this.column_name, this.sort, this.offset, this.limit, this.filters)
          .subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.getClientIDs();
            this.variant_boolean = false;
            this.selectedRow = response.data.content[0];
            this.apiResponse = response.data.content;
            this.totalRecords = response.data.totalElements;
            this.Gridcontent = [...this.apiResponse];
            this.getOtherAnalysisData();
          });
      } else {
        this.getAllVariants();
      }
    }
  }

  getGenePage() {
    const gene = this.selectedRow.gene;
    this.dashboard.getSpecificMasterGeneBoard(gene);
  }

  refresh() {
    this.route.navigate(['app/master-variant']);
    this.getAllVariants();
  }

  getColor(element, dataitem, type) {
    switch (type) {

      case 'coverage_color':
        if (dataitem[type] === 'gray') {
          element.parentNode.parentNode.style.background = 'darkgrey';
        }
        break;
      case 'gnomad_high_freq_color':
        if (dataitem[type] === 'pink') {
          element.parentNode.parentNode.style.background = 'lightpink';
        }
        break;
    }
  }

  getPkiStatus() {
    this.alert = true;
    this.selectedRow.clinical_report_data.pki_class =
      this.selectedRow.clinical_report_data.pki_class.toLowerCase() === 'Reset Classification'.toLowerCase() ? '' : this.selectedRow.clinical_report_data.pki_class;

    this.selectedRow.clinical_report_data.pki_status = 'Edited';
    this.whatTime = new Date();
    this.selectedRow.clinical_report_data.pki_modified = this.whatTime.getTime();
    this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
    this.selectedrow = this.selectedRow;
  }

  onStatusChanged() {
    this.alert = true;
    this.whatTime = new Date();
    this.selectedRow.clinical_report_data.pki_modified = this.whatTime.getTime();
    this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
    this.selectedrow = this.selectedRow;
  }

  changeAcmgCalc() {
    this.alert = true;
    if (this.selectedRow.acmg_selections) {
      this.ACMGOutput = this.selectedRow.acmg_selections;
      this.acmgDetails.acmgData = this.ACMGOutput;
      const disposable = this.dialogService.addDialog(AcmgCalculatorComponent, this.acmgDetails);
      disposable.subscribe((Response: any) => {
        if (Response !== false) {
          this.http.post(this.acmgUrl, Response).subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.selectedRow.clinical_report_data.acmg_calculator = response.data;
            this.selectedRow.acmg_selections = Response;
            this.whatTime = new Date();
            this.selectedRow.clinical_report_data.pki_modified = this.whatTime.getTime();
            this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
          });
        }
      });
    } else {
      this.dialogService.addDialog(AcmgCalculatorComponent, {})
        .subscribe((Response: any) => {
          if (Response !== false) {
            this.http.post(this.acmgUrl, Response).subscribe((response: any) => {
              const authToken = response.token;
              if (response.token !== null) {
                sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
              } else { }
              this.selectedRow.clinical_report_data.acmg_calculator = response.data;
              this.selectedRow.acmg_selections = Response;
              this.whatTime = new Date();
              this.selectedRow.clinical_report_data.pki_modified = this.whatTime.getTime();
              this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
            });
          }
        });
    }
  }

  getClientIDs() {
    const user_id = sessionStorage.getItem('user_id');
    this.http.get('/api/client/user/' + user_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.client_ids = [];
      this.client_list = response.data;
      for (let i = 0; i < this.client_list.length; i++) {
        this.client_ids = this.client_ids.concat(this.client_list[i].id);
      }
    });
  }

  start = 0;
  firstRecordForOtherGrid = 0;
  sortBy = 'name';
  sortDir = 'asc';

  otherAnalysisData(event) {
    if (this.selectedRow) {
      const sortOrderMapper = {
        '1': 'asc',
        '-1': 'desc'
      };
      this.start = event.first / event.rows;
      this.firstRecordForOtherGrid = event.first;
      this.sortBy = event.sortField ? event.sortField : 'first_name';
      this.sortDir = sortOrderMapper[event.sortOrder];
      const key = Object.keys(event.filters);
      const filters = key.reduce((f, c) => {
        f[c] = event.filters[c].value;
        return f;
      }, {});
      const payload = { 'clientIds': this.client_ids };
      const filter = { 'searchReq': filters };
      this.filterPayload = filters ? merge(filter, payload) : payload;
      this.filterApplied = filters ? true : false;
      this.getClientIDs();
      this.getOtherAnalysisData();
    }
  }

  getOtherAnalysisData() {
    this.getClientIDs();
    if (this.selectedRow) {
      this.filterPayload = this.filterApplied ? this.filterPayload : { 'clientIds': this.client_ids };
      const variant_id = this.selectedRow.chrom_start_stop_ref_alt;
      this.start = this.boolpaginate ? 0 : this.start;
      this.service.getOtherAnalysesDetails(variant_id, this.sortBy, this.sortDir, this.start, 10, this.filterPayload).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.lowerPanelContentLength = response.data.totalElements;
        this.lowerPanelContent = response.data.content;
        this.boolpaginate = false;
      });
    }
  }

  setActive(event) {
    this.alert = true;
    this.whatTime = new Date();
    this.selectedRow.clinical_report_data.frequent_artifact = event.target.checked;
    this.selectedRow.clinical_report_data.pki_modified = this.whatTime.getTime();
    this.selectedRow.clinical_report_data.modified_by = sessionStorage.getItem('user');
  }

  saveVariantDetails() {
    const url = '/api/master/clinicalReportData';
    this.alert = false;
    this.alertCount = 0;
    this.saveFlag = true;
    this.selectedRow.clinical_report_data.chrom_start_stop_ref_alt = this.selectedRow.chrom_start_stop_ref_alt;
    $('#successMsg').modal('toggle');
    setTimeout(function () {
      $('#successMsg').modal('hide');
    }, 4000);
    this.http.post(url, this.selectedRow.clinical_report_data).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      if (response) {
        if (this.variant_name) {
          this.getVariantbyGene();
        } else {
          if (this.filters) {
            this.service.getFilteredData(this.column_name, this.sort, this.offset, this.limit, this.filters)
              .subscribe((response: any) => {
                const authToken = response.token;
                if (response.token !== null) {
                  sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
                } else { }
                this.variant_boolean = false;
                this.selectedRow = response.data.content[0];
                this.apiResponse = response.data.content;
                this.totalRecords = response.data.totalElements;
                this.Gridcontent = [...this.apiResponse];
                this.getOtherAnalysisData();
              });
          } else {
            this.getAllVariants();
          }
        }
      }
    });
  }

  addVariant() {
    this.dialogService.addDialog(AddVariantMasterComponent, this.acmgDetails).subscribe((response: any) => {
      if (response === 'success') {
        this.getAllVariants();
        $('#addVariant').modal('toggle');
        setTimeout(function () {
          $('#addVariant').modal('hide');
        }, 4000);
      }
    });
  }
}
