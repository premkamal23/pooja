import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { ReportModuleService } from '../../common/services/report-module.service';
import { OpenAnalysisService } from '../../common/services';

export interface analysisData {
  analysis_id: any;
}

@Component({
  selector: 'variants-for-section',
  templateUrl: './variants-for-section.component.html',
  styleUrls: ['./variants-for-section.component.css']
})
export class VariantsForSectionComponent extends DialogComponent<ClientData, any> implements analysisData, OnInit {

  analysis_id: any;
  variant_list: any;
  sections_list: any;

  constructor(
    dialogService: DialogService,
    private service: ReportModuleService,
    private analysis_service: OpenAnalysisService) {
    super(dialogService);
  }

  ngOnInit() {
    this.getVariants();
  }

  getsectionsForReport() {
    this.service.getSectionForReport(this.analysis_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.sections_list = response.data;
      const selectedSection = response.data[0].id;
      for (let i = 0; i < this.variant_list.length; i++) {
        const section = selectedSection;
        const variant = this.variant_list[i].id.toString();
        this.result[variant] = section;
      }
    });
  }

  getVariants() {
    this.result = {};
    this.analysis_service.getVariantForReport(this.analysis_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.variant_list = response.data.variants.content;
      this.getsectionsForReport();
    });
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  getselectedSection() {
    this.close();
  }
}
