import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as FileSaver from 'file-saver';
import { ProjectService } from '../../common/services/project.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { TreeNode } from 'primeng/primeng';
import { merge } from 'lodash';
import { DialogService } from 'ng2-bootstrap-modal';
import { ChangeOfCustodyComponent } from '../change-of-custody/change-of-custody.component';
import { EditCommentsComponent } from '../edit-comments/edit-comments.component';
import { EditClassificationComponent } from '../edit-classification/edit-classification.component';
import { DeleteAnalysisComponent } from '../delete-analysis/delete-analysis.component';
import { ReportTemplateService } from '../../common/services/report-template.service';
import { ReportModuleService } from '../../common/services/report-module.service';
import { FilterComponentComponent } from '../../components/filter-component/filter-component.component';
import { EditStatusComponent } from '../../components/edit-status/edit-status.component';

declare var $: any;

interface IType {
  name?: any;
  proj_name?: any;
  client_name?: any;
  status?: any;
  type?: any;
  analysis_type?: any;
  comments?: any;
  owner?: any;
  created?: any;
  modified?: any;
  pki_class_status_value?: any;
  fromCreatedDate?: any;
  toCreatedDate?: any;
  fromModifiedDate?: any;
  toModifiedDate?: any;
}

interface IAnalysis {
  allClients?: any;
  pki_class_status_values?: any;
  statusList?: any;
  types?: any;
  owners?: any;
}

@Component({
  selector: 'app-process-analysis',
  templateUrl: './process-analysis.component.html',
  styleUrls: ['./process-analysis.component.css']
})
export class ProcessAnalysisComponent implements OnInit {
  analysisCount: number;
  rowData: TreeNode[];
  selectedRow: any = {};
  analysis: IType = {};
  filter: IAnalysis = {};
  analysis_id = 1;
  view_analysis_boolean: boolean = false;
  edit_analysis: boolean = false;
  delete_analysis: boolean = false;
  delete_report: boolean = false;
  auto_report: boolean = false;
  boolFilter: boolean = false;
  clientDropDownList: Array<any>;
  clientNameList = [];
  projectEnable = false;
  selectedAnalysisName = '';
  analysis_for_report = 0;
  analysis_for_hold: any;
  analysis_for_variants: any;
  analysis_noTemplate: any;
  analysis_notestId: any;
  analysis_duplicate: any;
  bulkReportHoldMessage = '';
  bulkReportVariantMessage = '';
  bulkReportSuccessMessage = '';
  bulkNoTestCodeMessage = '';
  bulkNoTemplateMessage = '';
  bulkduplicateMessage = '';
  client_list: any;
  client_ids = [];
  totalRecords: any;
  firstRecord = 0;
  count = 0;
  offset = 0;
  limit = 15;
  sortBy = 'created';
  sortDir = 'desc';
  searchObj: any;
  filterObj: any;
  client_id: any;
  client_name: string;
  analysis_name: string;
  owner: string;
  comments: string;
  status: string;
  initial_class: string;
  selectedFile: any;
  selectedClientList: any;
  selectedOwnerList: any;
  selectedFlagList: any;
  selectedstatusList: any;
  selectedTypeList: any;
  fromCreatedDate?: any;
  toCreatedDate?: any;
  fromModifiedDate?: any;
  toModifiedDate?: any;
  analysis_ids: any = [];
  mark_for_report = false;
  analysisData = {
    client_id: this.client_id,
    owner: this.client_name
  }

  idData = {
    analysis_id: this.analysis_id,
    analysis_name: this.analysis_name
  }

  commentsData = {
    comments: this.comments
  }

  statusData = {
    status: this.status
  }

  classData = {
    initial_class: this.initial_class
  }

  analysisFilterData = {
    allClients: this.selectedClientList,
    pki_class_status_values: this.selectedFlagList,
    statusList: this.selectedstatusList,
    types: this.selectedTypeList,
    owners: this.selectedOwnerList,
    fromCDate: this.fromCreatedDate,
    toCDate: this.toCreatedDate,
    fromMDate: this.fromModifiedDate,
    toMDate: this.toModifiedDate
  }

  url: any;

  deleteURL = '';


  isCreateAnalysisAllowed = false;

  constructor(
    private router: Router,
    private projectService: ProjectService,
    private http: HttpClient,
    private dialogService: DialogService,
    private reportTemplateService: ReportTemplateService,
    private service: ReportModuleService
  ) {
  }

  ngOnInit() {
    const permissions = sessionStorage.getItem('permissions').split(',');
    this.view_analysis_boolean = permissions.includes('VIEW_ANALYSIS') ? true : false;
    this.edit_analysis = permissions.includes('EDIT_ANALYSIS') ? true : false;
    this.delete_analysis = permissions.includes('DELETE_ANALYSIS') ? true : false;
    this.delete_report = permissions.includes('DELETE_REPORT') ? true : false;
    this.auto_report = permissions.includes('AUTO_REPORT') ? true : false;

    const user_id = sessionStorage.getItem('user_id');
    this.owner = sessionStorage.getItem('user');

    window.onbeforeunload = function (event) {
      sessionStorage.removeItem('analysisFilters');
      sessionStorage.removeItem('report_filters');
    }
    if (sessionStorage.getItem('analysisFilters')) {
      const sessionAnalysesData = sessionStorage.getItem('analysisFilters');
      this.analysis = JSON.parse(sessionAnalysesData);
      const tempObj = this.createObject(this.analysis);
      this.searchObj = merge({}, tempObj);
      this.analysisFilterData.fromCDate = this.analysis.fromCreatedDate ? this.analysis.fromCreatedDate : undefined;
      this.analysisFilterData.toCDate = this.analysis.toCreatedDate ? this.analysis.toCreatedDate : undefined;
      this.analysisFilterData.fromMDate = this.analysis.fromModifiedDate ? this.analysis.fromModifiedDate : undefined;
      this.analysisFilterData.toMDate = this.analysis.toModifiedDate ? this.analysis.toModifiedDate : undefined;
    }

    if (sessionStorage.getItem('report_filters')) {
      const sessionAnalysesData = sessionStorage.getItem('report_filters');
      this.filter = JSON.parse(sessionAnalysesData);
      const fObj = this.createFilterObject(this.filter);
      this.filterObj = merge({}, fObj);
    }

    this.http.get('/api/client/user/' + user_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.client_list = response.data;
      for (let i = 0; i < this.client_list.length; i++) {
        this.client_ids = this.client_ids.concat(this.client_list[i].id);
      }
      this.getanalysisFilter();
    });
    if (sessionStorage.getItem('permissions')) {
      const permissions = sessionStorage.getItem('permissions').split(',');
      if (permissions.includes('CREATE_ANALYSIS')) {
        this.isCreateAnalysisAllowed = true;
      }
    }
  }
  openAnalysisModal() {
    this.router.navigate(['app/open-analysis', this.analysis_id]);
  }

  openNewAnalysisModal() {
    this.router.navigate(['app/new-analysis']);
  }

  prepareReportTemplatePage(row) {
    const data = row.node.data;
    const analysis_id = row.node.parent.data.id;
    this.service.checkReportType(analysis_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      if (response.data.toLowerCase() === 'normal') {
        this.router.navigate(['/app/report-template', analysis_id, data.id, true]);
      } else {
        this.router.navigate(['app/purple-template', analysis_id, data.id, true]);
      }
    });
  }

  // checkForRunningAnalysis() {
  //   this.projectService.checkForInProgressAnalysis().subscribe((response: any) => {
  //     const authToken = response.token;
  //     if (response.token !== null) {
  //       sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
  //     } else { }
  //     this.getanalysisFilter();
  //     setInterval(() => {
  //       this.checkForRunningAnalysis();
  //     }, 200000);
  //   });
  // }

  createObject(objAnalysis) {
    return Object.keys(objAnalysis).reduce((f, c) => {
      if (objAnalysis[c] != '') {
        f[c] = this.analysis[c];
      }
      return f;
    }, {});
  }

  createFilterObject(objAnalysis) {
    return Object.keys(objAnalysis).reduce((f, c) => {
      if (objAnalysis[c] != '') {
        f[c] = this.analysis[c];
      }
      return f;
    }, {});
  }

  getFilter(value) {
    this.analysis_ids = [];
    this.count = 0;
    this.analysis_for_report = 0;
    sessionStorage.setItem('analysisFilters', JSON.stringify(this.analysis));
    const tempObj = this.createObject(this.analysis);
    this.searchObj = merge({}, tempObj);
    this.offset = 0;
    this.firstRecord = 0;
    this.getanalysisFilter();
  }

  loadAnalysis(event) {
    const data = event.node.data;
    const name = data.name.split('.');
    if ((this.view_analysis_boolean || this.edit_analysis) && (data.proj_name && (data.status !== 'Running' && data.status !== 'Queued' && data.status !== 'Failed' && data.status !== 'Delete in progress' && data.status !== 'Creating report'))) {
      sessionStorage.setItem('analysis_client', data.client_id);
      this.analysis_id = data.id;
      this.openAnalysisModal();
    } else if ((this.edit_analysis) && (data.status && (data.status.toLowerCase() === 'approved' || data.status.toLowerCase() === 'draft'))) {
      sessionStorage.setItem('analysis_client', event.node.parent.data.client_id);
      this.prepareReportTemplatePage(event);
    } else if (data.status && data.status.toLowerCase() === 'released') {
      this.reportTemplateService.downloadPdf(name[0]).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        const url: any = response.data;
        window.open(url, '_blank');
      });
    }
  }

  paginate(event) {
    this.count = 0;
    this.firstRecord = event.first;
    this.offset = event.first / event.rows;
    this.limit = event.rows;
    this.getanalysisFilter();
  }

  changeCustody(value) {
    const event = value.node.data;
    this.analysisData.client_id = event.client_id;
    this.analysisData.owner = event.owner;
    const disposable = this.dialogService.addDialog(ChangeOfCustodyComponent, this.analysisData);
    disposable.subscribe((response: any) => {
      if (response !== false) {
        this.projectService.updateAnalysis(event.id, response.ownerName, response.email).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.getanalysisFilter();
        });
      }
    });
  }

  editComments(value) {
    const event = value.node.data;
    const analysis_id = event.id;
    this.commentsData.comments = event.comments;
    if (!this.edit_analysis) {
      this.selectedAnalysisName = 'User with Edit Analysis permission can perform this action.';
      $('#deleteAnalysisContainer').modal('toggle');
      setTimeout(function () {
        $('#deleteAnalysisContainer').modal('hide');
      }, 4000);
    } else {
      const disposable = this.dialogService.addDialog(EditCommentsComponent, this.commentsData);
      disposable.subscribe((Response: any) => {
        if (Response !== false) {
          this.projectService.editComments(analysis_id, Response).subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.getanalysisFilter();
          });
        }
      });
    }
  }

  editClassification(event) {
    this.classData.initial_class = event.node.data.pki_class_status_value;
    if (!this.edit_analysis) {
      this.selectedAnalysisName = 'User with Edit Analysis permission can perform this action.';
      $('#deleteAnalysisContainer').modal('toggle');
      setTimeout(function () {
        $('#deleteAnalysisContainer').modal('hide');
      }, 4000);
    } else {
      this.dialogService.addDialog(EditClassificationComponent, this.classData).subscribe((response: any) => {
        if (response !== false) {
          const data = {
            value: response
          };
          this.projectService.updateAnalysisFlag(event.node.data.id, data).subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.getanalysisFilter();
          });
        }
      });
    }
  }

  deleteAnalysis(value) {
    const event = value.node;
    this.deleteURL = '';
    this.idData.analysis_id = event.data.id;
    this.idData.analysis_name = event.data.name;
    if (event.data.name.endsWith('tmp') || event.data.name.endsWith('pdf')) {
      const analysis_id = event.parent.data.id;
      const report_id = event.data.id;
      this.deleteURL = '/api/deleteClinicalReport/' + analysis_id + '/' + report_id + '/report?report_name=' + event.data.name;
      if (event.parent.data.owner !== this.owner) {
        if (!this.delete_report) {
          this.selectedAnalysisName = 'The user must be the owner of analysis or possess Delete Report permission to continue with this action.';
          $('#deleteAnalysisContainer').modal('toggle');
          setTimeout(function () {
            $('#deleteAnalysisContainer').modal('hide');
          }, 4000);
        } else {
          this.deleteFunction();
        }
      } else {
        this.deleteFunction();
      }
    } else {
      this.deleteURL = '/api/analysis/' + event.data.id;
      if (event.data.owner !== this.owner) {
        if (!this.delete_analysis) {
          this.selectedAnalysisName = 'The user must be the owner of analysis or possess Delete Analysis permission to continue with this action.';
          $('#deleteAnalysisContainer').modal('toggle');
          setTimeout(function () {
            $('#deleteAnalysisContainer').modal('hide');
          }, 4000);
        } else {
          this.deleteFunction();
        }
      } else {
        this.deleteFunction();
      }
    }
  }

  deleteFunction() {
    const disposable = this.dialogService.addDialog(DeleteAnalysisComponent, this.idData);
    disposable.subscribe((response: any) => {
      if (response !== false) {
        this.on();
        this.projectService.deleteAnalysis(this.deleteURL).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.selectedAnalysisName = response.data;
          $('#deleteAnalysisContainer').modal('toggle');
          setTimeout(function () {
            $('#deleteAnalysisContainer').modal('hide');
          }, 4000);
          this.getanalysisFilter();
          this.off();
        },
          (err) => {
            this.selectedAnalysisName = err.error.data;
            $('#deleteAnalysisContainer').modal('toggle');
            setTimeout(function () {
              $('#deleteAnalysisContainer').modal('hide');
            }, 4000);
            this.off();
          });
      }
    });
  }

  on() {
    document.getElementById("overlay").style.display = "block";
  }

  off() {
    document.getElementById("overlay").style.display = "none";
  }

  sorting(column, direction) {
    this.sortBy = column;
    this.sortDir = direction;
    this.getanalysisFilter();
  }

  exportJson(event) {
    const id = event.node.data.id;
    const name = event.node.data.name;
    const analysis_id = event.parent.data.id;
    this.on();
    this.projectService.exportToJsonPurple(id, name).subscribe((response: any) => {
      const authToken = response.token;
      if (authToken !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      const name = response.data.report_name;
      const data = response.data;
      const json = JSON.stringify(data);
      var blob = new Blob([json], { type: "application/json" });
      const filename = name.split('.');
      const nameOfFile = filename[0] + '.json';
      FileSaver.saveAs(blob, nameOfFile);
      this.off();
    });
  }

  removeDupVariants(arrVariants) {
    let uniqueArr = [];
    for (let i = 0; i < arrVariants.length; i++) {
      if (uniqueArr.indexOf(arrVariants[i]) === -1) {
        uniqueArr.push(arrVariants[i]);
      }
    }
    return uniqueArr;
  }

  removeUndefinedIDs(analysisArray) {
    let arr = [];
    for (let i = 0; i < analysisArray.length; i++) {
      if (analysisArray[i] !== undefined) {
        arr.push(analysisArray[i]);
      }
    }
    return arr;
  }

  removeFromArray(array) {
    let index = -1;
    for (let i = 0; i < array.length; i++) {
      index = this.analysis_ids.indexOf(array[i]);
      if (index !== -1) {
        this.analysis_ids.splice(index, 1);
      }
    }
  }

  handleSingleClick(column_value, node) {
    let analysis_ids = [];
    if (node) {
      this.analysis_ids = this.analysis_ids.concat(column_value.id);
      this.analysis_ids = this.removeDupVariants(this.analysis_ids);
      this.analysis_ids = this.removeUndefinedIDs(this.analysis_ids);
      this.analysis_for_report = this.analysis_ids.length;
      this.count++;
    } else {
      analysis_ids.push(column_value.id);
      this.removeFromArray(analysis_ids);
      this.analysis_for_report = this.analysis_ids.length;
      this.count--;
    }
    this.mark_for_report = this.count === this.limit ? true : false;
    (this.analysis_ids);
  }

  handleAllHide(event) {
    let analysis_ids = [];
    if (event.target.checked) {
      this.rowData = this.rowData.map(id_list => {
        if (id_list.data.status !== 'Running' && id_list.data.status !== 'Queued' && id_list.data.status !== 'Failed' && id_list.data.status !== 'Annotating' && id_list.data.status !== 'Delete in progress' && id_list.data.status !== 'Creating report') {
          id_list.data.mark_for_report = true;
          this.count++;
        } else {
          id_list.data.mark_for_report = false;
        }
        return id_list;
      });

      analysis_ids = this.rowData.map(id_list => {
        if (id_list.data.status !== 'Running' && id_list.data.status !== 'Queued' && id_list.data.status !== 'Failed' && id_list.data.status !== 'Annotating' && id_list.data.status !== 'Delete in progress' && id_list.data.status !== 'Creating report') {
          return id_list.data.id;
        }
      });

      this.analysis_ids = this.analysis_ids.concat(analysis_ids);
      this.analysis_ids = this.removeDupVariants(this.analysis_ids);
      this.analysis_ids = this.removeUndefinedIDs(this.analysis_ids);
      this.analysis_for_report = this.analysis_ids.length;
    } else {
      this.rowData = this.rowData.map(id_list => {
        if (id_list.data.status !== 'Running' && id_list.data.status !== 'Queued' && id_list.data.status !== 'Failed' && id_list.data.status !== 'Annotating' && id_list.data.status !== 'Delete in progress' && id_list.data.status !== 'Creating report') {
          id_list.data.mark_for_report = false;
          this.count--;
        } else {
          id_list.data.mark_for_report = false;
          this.count--;
        }
        return id_list;
      });
      analysis_ids = this.rowData.map(id_list => {
        if (id_list.data.status !== 'Running' && id_list.data.status !== 'Queued' && id_list.data.status !== 'Failed' && id_list.data.status !== 'Annotating' && id_list.data.status !== 'Delete in progress' && id_list.data.status !== 'Creating report') {
          return id_list.data.id;
        }
      });
      this.removeFromArray(analysis_ids);
    }
    this.analysis_for_report = this.analysis_ids.length;
  }

  validateAnalysisForReport() {
    this.bulkReportSuccessMessage = '';
    this.bulkReportHoldMessage = '';
    this.bulkReportVariantMessage = '';
    this.bulkNoTestCodeMessage = '';
    this.bulkNoTemplateMessage = '';
    this.bulkduplicateMessage = '';
    let approver = {
      'name': sessionStorage.getItem('user'),
      'designation': sessionStorage.getItem('designation'),
      'email': sessionStorage.getItem('email')
    };
    if (this.analysis_ids.length === 0) {
      this.bulkReportSuccessMessage = 'Please select analysis to generate report.';
      $('#bulkReport').modal('toggle');
    } else {
      this.on();
      this.projectService.validateBeforeReport(this.offset, this.limit, this.sortBy, this.sortDir, this.client_ids, this.analysis_ids, approver)
        .subscribe((response: any) => {
          const authToken = response.token;
          if (authToken !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.off();
          if (response.data.analysisWithHold.length > 0 || response.data.analysisWithVariants.length > 0 || response.data.analysisWithNoTemplateMapped.length > 0 || response.data.analysisWithNoTestCode.length > 0 || response.data.duplicateAnalysisNames.length > 0) {
            if (response.data.analysisWithHold.length > 0) {
              this.bulkReportHoldMessage = 'Following analysis have at least one variant in hold report condition:';
              this.analysis_for_hold = response.data.analysisWithHold;
            } if (response.data.analysisWithVariants.length > 0) {
              this.bulkReportVariantMessage = 'Following analysis have at least one variant selected for report generation:';
              this.analysis_for_variants = response.data.analysisWithVariants;
            } if (response.data.analysisWithNoTemplateMapped.length > 0) {
              this.bulkNoTemplateMessage = 'Test ID for following analysis does not match with any available report templates:';
              this.analysis_noTemplate = response.data.analysisWithNoTemplateMapped;
            } if (response.data.analysisWithNoTestCode.length > 0) {
              this.bulkNoTestCodeMessage = 'Test ID for following analysis is not available:';
              this.analysis_notestId = response.data.analysisWithNoTestCode;
            } if (response.data.duplicateAnalysisNames.length > 0) {
              this.bulkduplicateMessage = 'One or more analyses with same name as below have been selected for report generation:';
              this.analysis_duplicate = response.data.duplicateAnalysisNames;
            }
            $('#bulkReport').modal('toggle');
          } else {
            this.bulkReportSuccessMessage = 'Auto report generation for the selected analyses has been initiated successfully.';
            $('#bulkReport').modal('toggle');
            this.getanalysisFilter();
            this.count = 0;
            this.analysis_for_report = 0;
            this.mark_for_report = false;
            this.analysis_ids = [];
            const ids = response.data.analysisForAutoReport;
            this.projectService.generateBulkReport(this.client_ids, ids, approver)
              .subscribe((response: any) => {
                const authToken = response.token;
                if (authToken !== null) {
                  sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
                } else { }
                this.getanalysisFilter();
              });
          }
        }, err => {
          this.bulkReportSuccessMessage = err.error.data;
          $('#bulkReport').modal('toggle');
        });
    }
  }

  getFilterPopup() {
    if ((sessionStorage.getItem('report_filters') !== null && sessionStorage.getItem('report_filters') !== '{}')) {
      const sessionAnalysesData = sessionStorage.getItem('report_filters');
      const sessionfilters = JSON.parse(sessionStorage.getItem('analysisFilters'));
      this.filter = JSON.parse(sessionAnalysesData);
      this.analysisFilterData.fromCDate = sessionfilters.fromCreatedDate ? sessionfilters.fromCreatedDate : undefined;
      this.analysisFilterData.toCDate = sessionfilters.toCreatedDate ? sessionfilters.toCreatedDate : undefined;
      this.analysisFilterData.fromMDate = sessionfilters.fromModifiedDate ? sessionfilters.fromModifiedDate : undefined;
      this.analysisFilterData.toMDate = sessionfilters.toModifiedDate ? sessionfilters.toModifiedDate : undefined;

      this.analysisFilterData.allClients = this.filter.allClients;
      this.analysisFilterData.owners = this.filter.owners;
      this.analysisFilterData.pki_class_status_values = this.filter.pki_class_status_values;
      this.analysisFilterData.statusList = this.filter.statusList;
      this.analysisFilterData.types = this.filter.types;
    } else {
      this.analysisFilterData.allClients = undefined;
      this.analysisFilterData.owners = undefined;
      this.analysisFilterData.pki_class_status_values = undefined;
      this.analysisFilterData.statusList = undefined;
      this.analysisFilterData.types = undefined;
      this.analysisFilterData.fromCDate = undefined;
      this.analysisFilterData.toCDate = undefined;
      this.analysisFilterData.fromMDate = undefined;
      this.analysisFilterData.toMDate = undefined;
    }
    this.dialogService.addDialog(FilterComponentComponent, this.analysisFilterData).subscribe((response: any) => {
      if (typeof response === 'object') {
        this.filter.allClients = response.allClients;
        this.filter.owners = response.owners;
        this.filter.pki_class_status_values = response.pki_class_status_values
        this.filter.statusList = response.statusList;
        this.filter.types = response.types;
        this.analysis.fromCreatedDate = response.fromCreatedDate;
        this.analysis.toCreatedDate = response.toCreatedDate;
        this.analysis.fromModifiedDate = response.fromModifiedDate;
        this.analysis.toModifiedDate = response.toModifiedDate;
        sessionStorage.setItem('analysisFilters', JSON.stringify(this.analysis));
        const tempObj = this.createObject(this.analysis);
        this.searchObj = merge({}, tempObj);

        const fObj = this.createFilterObject(this.filter);
        this.filterObj = merge({}, fObj);
        this.offset = 0;
        this.firstRecord = 0;
        this.getanalysisFilter();
        if (this.filter !== {} && this.filter !== undefined) {
          sessionStorage.setItem('report_filters', JSON.stringify(this.filter));
        }
      } else if (response === 'clear') {
        this.filter = {};
        delete this.analysis['fromCreatedDate'];
        delete this.analysis['toCreatedDate'];
        delete this.analysis['fromModifiedDate'];
        delete this.analysis['toModifiedDate'];
        sessionStorage.setItem('analysisFilters', JSON.stringify(this.analysis));
        const tempObj = this.createObject(this.analysis);
        this.searchObj = merge({}, tempObj);
        this.offset = 0;
        this.firstRecord = 0;
        sessionStorage.removeItem('report_filters');
        this.getanalysisFilter();
      } else {
        sessionStorage.setItem('analysisFilters', JSON.stringify(this.analysis));
        const tempObj = this.createObject(this.analysis);
        this.searchObj = merge({}, tempObj);

        const fObj = this.createFilterObject(this.filter);
        this.filterObj = merge({}, fObj);
        this.offset = 0;
        this.firstRecord = 0;
        this.getanalysisFilter();
      }
    });
  }

  getanalysisFilter() {
    //this.boolFilter = (this.filter)
    let column_filter = Object.values(this.filter).length === 0 ? false : true;
    let analysis_filter = (this.searchObj === {} || this.searchObj === undefined || Object.values(this.searchObj).length === 0) ? false : true;
    this.boolFilter = (column_filter || analysis_filter) ? true : false;
    this.projectService.applyAnalysisFilter(this.sortBy, this.sortDir, this.offset, this.limit, this.client_ids, this.searchObj, this.filter)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (authToken !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        for (let i = 0; i < response.data.data.length; i++) {
          response.data.data[i].data.excluded_fields = [];
          response.data.data[i].data.exclude_deep = response.data.data[i].data.exclude_deep_intron
            ? response.data.data[i].data.excluded_fields.push('Deep Intron')
            : '';
          response.data.data[i].data.exclude_non = response.data.data[i].data.exclude_non_coding
            ? response.data.data[i].data.excluded_fields.push('Non coding')
            : '';
        }
        this.rowData = response.data.data;
        this.analysisCount = response.data.totalAnalyses;
        this.totalRecords = response.data.totalAnalyses;
        this.projectEnable = false;
        if (this.analysis_ids.length > 0) {
          let index = -1;
          for (let i = 0; i < this.rowData.length; i++) {
            index = this.analysis_ids.indexOf(this.rowData[i].data.id);
            if (index !== -1) {
              this.rowData[i].data.mark_for_report = true;
              this.count++;
            }
          }
        } else {
          this.rowData = this.rowData.map(response => {
            response.data.mark_for_report = false;
            return response;
          });
        }
        this.mark_for_report = this.count === this.limit ? true : false;
      });
  }

  exportTableData(boolValue) {
    let data = {};
    if (boolValue) {
      data = {
        client_ids: this.client_ids
      };
    } else {
      data = {
        client_ids: this.client_ids,
        searchReq: this.searchObj,
        analysisFilterData: {
          allClients: this.filter.allClients,
          pki_class_status_values: this.filter.pki_class_status_values,
          statusList: this.filter.statusList,
          types: this.filter.types,
          owners: this.filter.owners
        }
      };
    }
    const e_date = new Date();
    const end_date = e_date.getMonth() + 1 + '/' + e_date.getDate() + '/' + e_date.getFullYear();
    this.projectService.getTableContent(this.sortBy, this.sortDir, this.offset, this.limit, boolValue, data).subscribe((response: any) => {
      const authToken = response.token;
      if (authToken !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      if (typeof response.data === 'string') {
        this.selectedAnalysisName = response.data;
        $('#deleteAnalysisContainer').modal('toggle');
        setTimeout(function () {
          $('#deleteAnalysisContainer').modal('hide');
        }, 4000);
      } else {
        response.data = response.data.map(response => {
          const date_created = new Date(response.created)
          const date_modified = new Date(response.modified)
          response.created = [date_created.getMonth() + 1, date_created.getDate(), date_created.getFullYear()].join('/') + ' ' +
            [date_created.getHours(), date_created.getMinutes(), date_created.getSeconds()].join(':');
          response.modified = [date_modified.getMonth() + 1, date_modified.getDate(), date_modified.getFullYear()].join('/') + ' ' +
            [date_modified.getHours(), date_modified.getMinutes(), date_modified.getSeconds()].join(':');
          return response;
        });
        var arrData = typeof response.data != 'object' ? JSON.parse(response.data) : response.data;
        var CSV = 'sep=,' + '\r\n\n';
        var row = "";
        for (var index in arrData[0]) {
          row += index + ',';
        }
        row = row.slice(0, -1);
        CSV += row + '\r\n';
        for (var i = 0; i < arrData.length; i++) {
          var row = "";
          for (var index in arrData[i]) {
            if (index === 'comments') {
              arrData[i][index] = arrData[i][index].replace(/"/g, '""');
            }
            row += '"' + arrData[i][index] + '",';
          }
          row.slice(0, row.length - 1);
          CSV += row + '\r\n';
        }
        var blob = new Blob([CSV], { type: "data:text/csv;charset=utf-8" });
        FileSaver.saveAs(blob, 'ExportDashboardData(' + end_date + ').csv');
      }
    });
  }

  editStatus(rowData, status) {
    this.statusData.status = status
    this.dialogService.addDialog(EditStatusComponent, this.statusData).subscribe((response: any) => {
      if (response !== false) {
        this.projectService.updateStatus(rowData.id, response.status).subscribe((response: any) => {
          const authToken = response.token;
          if (authToken !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.selectedAnalysisName = response.data;
          $('#deleteAnalysisContainer').modal('toggle');
          setTimeout(function () {
            $('#deleteAnalysisContainer').modal('hide');
          }, 4000);
          this.getanalysisFilter();
        });
      } else {
        this.getanalysisFilter();
      }
    });
  }
}

