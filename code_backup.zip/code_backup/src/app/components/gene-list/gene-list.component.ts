import { Component, OnInit } from '@angular/core';
import { DialogService } from 'ng2-bootstrap-modal';
import { GenelistDialogComponent } from '../genelist-dialog/genelist-dialog.component';
import { HttpClient } from '@angular/common/http';
declare var $: any;
@Component({
  selector: 'app-gene-list',
  templateUrl: './gene-list.component.html',
  styleUrls: ['./gene-list.component.css']
})
export class GeneListComponent implements OnInit {

  rowData = [];
  rowSelection;
  genelistData: any;
  geneData = {};
  totalRecords: number;
  disableRemove = false;
  addGeneListURL = '/api/geneFile';
  geneListURL = '/api/geneFiles';
  description: string;
  formData: FormData;
  file_name: Array<any>;
  selectedRow: any;
  file: File;
  addGenePermission = false;
  removeGenePermission = false;

  constructor(
    private dialogService: DialogService,
    private http: HttpClient) {
  }

  ngOnInit() {
    this.getGeneListData();
    const permissions = sessionStorage.getItem('permissions').split(',');
    this.addGenePermission = permissions.includes('ADD_NEW_GENE_LIST') ? true : false;
    this.removeGenePermission = permissions.includes('REMOVE_GENE_LIST') ? true : false;
  }

  onRemoveSelected() {
    const url = this.addGeneListURL + '/' + this.selectedRow.file_name + '/';
    this.http.delete(url).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.getGeneListData();
      this.selectedRow = null;
    });
  }

  getGeneListData() {
    this.http.get(this.geneListURL).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.rowData = response.data.content;
      this.totalRecords = response.data.totalElements;
    });
  }

  getFileStatus(event) {
    this.selectedRow = event;
    if (event._used) {
      $('#removeUsedGene').modal('toggle');
    } else {
      $('#removeGene').modal('toggle');
    }
  }

  handleClick(event) {
    this.genelistData = event;
    $('#genedetails').modal('toggle');
  }

  openAddGeneModal() {
    const disposable = this.dialogService.addDialog(GenelistDialogComponent, this.geneData);
    disposable.subscribe((response: any) => {
      if (response !== false) {
        this.getGeneListData();
      }
    });
  }



}
