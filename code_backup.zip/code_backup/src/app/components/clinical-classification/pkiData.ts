import { IDropdownList } from './dropdown-list.interface';

export const pkiList: Array<IDropdownList> = [
    { item_id: 1, item_text: 'Benign' },
    { item_id: 2, item_text: 'Likely benign' },
    { item_id: 3, item_text: 'Pathogenic' },
    { item_id: 4, item_text: 'Likely pathogenic' },
    { item_id: 5, item_text: 'Uncertain significance' },
    { item_id: 6, item_text: 'Pseudodeficiency allele' },
    { item_id: 7, item_text: 'Other' }
];
