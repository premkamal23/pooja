import { IClinClassData } from './value.interface';

export const EmvClassData: IClinClassData = {
    key: 'emv_class',
    value: [
        {
            type: 'Artifact',
            check: false
        },
        {
            type: 'Benign',
            check: false
        },
        {
            type: 'Likely benign',
            check: false
        },
        {
            type: 'Likely pathogenic',
            check: false
        },
        {
            type: 'Other reportable',
            check: false
        },
        {
            type: 'Pathogenic',
            check: false
        },
        {
            type: 'VOUS',
            check: false
        }
    ]
};
