import { IDropdownList } from './dropdown-list.interface';

export const ClinvarList: Array<IDropdownList> = [
    { item_id: 1, item_text: 'Affects' },
    { item_id: 2, item_text: 'Pathogenic' },
    { item_id: 3, item_text: 'Likely pathogenic' },
    { item_id: 4, item_text: 'drug response' },
    { item_id: 5, item_text: 'confers sensitivity' },
    { item_id: 6, item_text: 'risk factor' },
    { item_id: 7, item_text: 'other' },
    { item_id: 8, item_text: 'association' },
    { item_id: 9, item_text: 'VOUS' },
    { item_id: 10, item_text: 'Likely benign' },
    { item_id: 11, item_text: 'association not found' },
    { item_id: 12, item_text: 'Benign' },
    { item_id: 13, item_text: 'protective' },
    { item_id: 14, item_text: 'not provided' },
    { item_id: 15, item_text: 'conflicting data from submitters' }
];
