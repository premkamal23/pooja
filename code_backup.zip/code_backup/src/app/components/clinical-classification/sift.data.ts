import { IClinClassData } from './value.interface';

export const SiftData: IClinClassData = {
    key: 'sift',
    value: [
        {
            type: 'D',
            check: false
        },
        {
            type: 'T',
            check: false
        }
    ]
};
