import { IClinClassData } from './value.interface';

export const PolyPhinData: IClinClassData = {
    key: 'polyphen_hdiv',
    value: [
        {
            type: 'D',
            check: false,
            title: ''
        },
        {
            type: 'P',
            check: false,
            title: ''
        },
        {
            type: 'B',
            check: false,
            title: ''
        }
    ]
};
