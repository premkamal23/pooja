import { IClinClassData } from './value.interface';

export const hgmdData: IClinClassData = {
    key: 'hgmd_class',
    value: [
        {
            type: 'DM',
            check: false,
            title: 'Disease-causing mutations'
        },
        {
            type: 'DM?',
            check: false,
            title: 'probable/possible pathological mutation'
        },
        {
            type: 'DP',
            check: false,
            title: 'Disease-associated polymorphisms'
        },
        {
            type: 'DFP',
            check: false,
            title: 'Disease-associated polymorphisms with supporting functional evidence'
        },
        {
            type: 'FP',
            check: false,
            title: 'Functional polymorphisms'
        },
        {
            type: 'FTV',
            check: false,
            title: 'frameshift or truncating variants'
        }
    ]
};
