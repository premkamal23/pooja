import { IClinClassData } from './value.interface';

export const MutationTasterData: IClinClassData = {
    key: 'mutation_taster',
    value: [
        {
            type: 'A',
            check: false
        },
        {
            type: 'D',
            check: false
        },
        {
            type: 'N',
            check: false
        },
        {
            type: 'P',
            check: false
        }
    ]
};
