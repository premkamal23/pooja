import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { IClinClassData } from './value.interface';

import { ClinvarList } from './clinvar-list.data';
import { SnpEffList } from './snpeff-list.data';
import { pkiList } from './pkiData';
import { hgmdData } from './hgmd.data';
import { EmvClassData } from './emv-class.data';
import { PolyPhinData } from './poly-phen.data';
import { SiftData } from './sift.data';
import { MutationTasterData } from './mutation-taster.data';
import { ClinvarClassData } from './clinvar-class.data';

@Component({
    selector: 'app-clinical-classification',
    templateUrl: './clinical-classification.component.html',
    styleUrls: ['./clinical-classification.component.css']
})
export class ClinicalClassificationComponent implements OnInit {
    @Input('clinClassData') clinClassData: any = {};
    @Output('filterChanged') filterChanged = new EventEmitter<any>();
    clinvarData = [];
    snpEffData = [];
    selectedItems = [];
    selectedSnpEffItems = [];
    selectedPkiList = [];
    dropdownSettings = {};
    clinvarList = ClinvarList;
    snpEffList = SnpEffList;
    pkiList = pkiList;
    emvClassData: IClinClassData = EmvClassData;
    hgmdClassData: IClinClassData = hgmdData;
    polyPhenData: IClinClassData = PolyPhinData;
    siftdata: IClinClassData = SiftData;
    mutationTasterData: IClinClassData = MutationTasterData;
    clinvarClassData: IClinClassData = ClinvarClassData;
    filterName: string;

    modelMapping: any = {
        emv_class: 'emv_class_options',
        clinvar: 'clinvar_options',
        snpeff: 'snpeff_options',
        hgmd_class: 'hgmd_class_options',
        polyphen_hdiv: 'polyphen_hdiv_options',
        sift: 'sift_options',
        mutation_taster: 'mutation_taster_options',
        pki_class: 'pki_class_options'
    };

    constructor(private http: HttpClient) { }

    ngOnInit() {
        this.filterName = this.clinClassData.name;
        this.dropdownSettings = {
            singleSelection: false,
            idField: 'item_id',
            textField: 'item_text',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 3,
            allowSearchFilter: true
        };

        const opts = this.clinClassData.options;
        const okeys = Object.keys(opts);
        okeys.forEach(o => {
            if (o.endsWith('_options')) {
                opts[o] = Array.isArray(opts[o]) ? opts[o] : [];
            }
        });

        if (this.clinClassData.options.clinvar) {
            if (this.selectedItems) {
                this.selectedItems = this.clinvarList.
                    filter(cvl => this.clinClassData.options.clinvar_options.find(co => co === cvl.item_text));
            }
        }
        if (this.clinClassData.options.snpeff) {
            if (this.selectedSnpEffItems) {
                this.selectedSnpEffItems = this.snpEffList.
                    filter(sel => this.clinClassData.options.snpeff_options.find(co => co === sel.item_text));
            }
        }
        if (this.clinClassData.options.pki_class) {
            if (this.selectedPkiList) {
                this.selectedPkiList = this.pkiList.
                    filter(pki => this.clinClassData.options.pki_class_options.find(co => co === pki.item_text));
            }
        }

        this.emvClassData.value = this.setSelectedModels('emvClassData', 'emv_class_options');
        this.hgmdClassData.value = this.setSelectedModels('hgmdClassData', 'hgmd_class_options');
        this.polyPhenData.value = this.setSelectedModels('polyPhenData', 'polyphen_hdiv_options');
        this.siftdata.value = this.setSelectedModels('siftdata', 'sift_options');
        this.mutationTasterData.value = this.setSelectedModels('mutationTasterData', 'mutation_taster_options');
    }

    setSelectedModels(model, incomingData) {
        return this[model].value.map(v => {
            if (this.clinClassData.options && this.clinClassData.options[incomingData]
                && this.clinClassData.options[incomingData].includes(v.type)) {
                v.check = true;
            }
            return v;
        });
    }

    dataTemplate() {
        return {
            name: this.filterName,
            options: {
                type: `com.pki.ngs.entities.ClinicalClassFilter`,
                keep_exclude: this.clinClassData.options.keep_exclude,
                zygosity: this.clinClassData.options.zygosity,
                any_all: this.clinClassData.options.any_all
            }
        };
    }

    _filterChanged({ target }, fieldName) {
        const { name, checked } = target;
        const mappedModel = this.modelMapping[name];
        const data = this.dataTemplate();

        data.options[name] = checked;
        if (checked) {
            const field = this[fieldName].value;
            const selected = field.filter(f => f.check).map(f => f.type);
            data.options[mappedModel] = selected;
        } else {
            data.options[mappedModel] = [];
        }
        let result = {};
        if (!this.clinClassData.options.clinvar && !this.clinClassData.options.snpeff
            && !this.clinClassData.options.emv_class && !this.clinClassData.options.hgmd_class
            && !this.clinClassData.options.polyphen_hdiv && !this.clinClassData.options.sift
            && !this.clinClassData.options.mutation_taster && !this.clinClassData.options.pki_class) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    _dropDownOptionsChanged(item, modelName, fieldName) {
        const data = this.dataTemplate();
        data.options[modelName] = this[fieldName].map(o => o.item_text);
        let result = {};
        if (!this.clinClassData.options.clinvar && !this.clinClassData.options.snpeff
            && !this.clinClassData.options.emv_class && !this.clinClassData.options.hgmd_class
            && !this.clinClassData.options.polyphen_hdiv && !this.clinClassData.options.sift
            && !this.clinClassData.options.mutation_taster && !this.clinClassData.options.pki_class) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    _optionsFilterChanged(modelName, fieldName) {
        const data = this.dataTemplate();
        const field = this[fieldName].value;

        const selected = field.filter(f => f.check).map(f => f.type);
        data.options[modelName] = selected;
        let result = {};
        if (!this.clinClassData.options.clinvar && !this.clinClassData.options.snpeff
            && !this.clinClassData.options.emv_class && !this.clinClassData.options.hgmd_class
            && !this.clinClassData.options.polyphen_hdiv && !this.clinClassData.options.sift
            && !this.clinClassData.options.mutation_taster && !this.clinClassData.options.pki_class) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    filterChangedOptions(filterName, value) {
        const data = this.dataTemplate();
        data.options[filterName] = value;
        let result = {};
        if (!this.clinClassData.options.clinvar && !this.clinClassData.options.snpeff
            && !this.clinClassData.options.emv_class && !this.clinClassData.options.hgmd_class
            && !this.clinClassData.options.polyphen_hdiv && !this.clinClassData.options.sift
            && !this.clinClassData.options.mutation_taster && !this.clinClassData.options.pki_class) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    filterNameChanged() {
        const data = this.dataTemplate();
        let result = {};
        if (!this.clinClassData.options.clinvar && !this.clinClassData.options.snpeff
            && !this.clinClassData.options.emv_class && !this.clinClassData.options.hgmd_class
            && !this.clinClassData.options.polyphen_hdiv && !this.clinClassData.options.sift
            && !this.clinClassData.options.mutation_taster && !this.clinClassData.options.pki_class) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }
    
}
