import { IClinClassData } from './value.interface';


export const ClinvarClassData: IClinClassData = {
    key: 'clinvar',
    value: [
        {
            type: 'emv_class',
            check: [
                {
                    type: 'Artifact',
                    check: false
                },
                {
                    type: 'Benign',
                    check: false
                },
                {
                    type: 'Likely benign',
                    check: false
                },
                {
                    type: 'Likely pathogenic',
                    check: false
                },
                {
                    type: 'Other reportable',
                    check: false
                },
                {
                    type: 'Pathogenic',
                    check: false
                },
                {
                    type: 'VOUS',
                    check: false
                }
            ]
        },
        {
            type: 'hgmd_class',
            check: [
                {
                    type: 'DM',
                    check: false,
                    title: 'Disease-causing mutations'
                },
                {
                    type: 'DM?',
                    check: false,
                    title: 'probable/possible pathological mutation'
                },
                {
                    type: 'DP',
                    check: false,
                    title: 'Disease-associated polymorphisms'
                },
                {
                    type: 'DFP',
                    check: false,
                    title: 'Disease-associated polymorphisms with supporting functional evidence'
                },
                {
                    type: 'FP',
                    check: false,
                    title: 'Functional polymorphisms'
                },
                {
                    type: 'FTV',
                    check: false,
                    title: 'frameshift or truncating variants'
                }
            ]
        },
        {
            type: 'polyphen_hdiv',
            check: [
                {
                    type: 'D',
                    check: false,
                    title: ''
                },
                {
                    type: 'P',
                    check: false,
                    title: ''
                },
                {
                    type: 'B',
                    check: false,
                    title: ''
                }
            ]
        },
        {
            type: 'sift',
            check: [
                {
                    type: 'D',
                    check: false
                },
                {
                    type: 'T',
                    check: false
                }
            ]
        },
        {
            type: 'mutation_taster',
            check: [
        {
            type: 'A',
            check: false
        },
        {
            type: 'D',
            check: false
        },
        {
            type: 'N',
            check: false
        },
        {
            type: 'P',
            check: false
        }
    ]
        }
    ]
};
