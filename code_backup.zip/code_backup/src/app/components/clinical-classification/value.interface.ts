interface IValue {
    type: string;
    check: any;
    title?: string;
}

export interface IClinClassData {
    key: string;
    value: Array<IValue>;
}
