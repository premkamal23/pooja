import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { ProjectService } from '../../common/services/project.service';

export interface classData {
  initial_class: string;
}

@Component({
  selector: 'edit-classification',
  templateUrl: './edit-classification.component.html',
  styleUrls: ['./edit-classification.component.css']
})
export class EditClassificationComponent extends DialogComponent<classData, any> implements classData, OnInit {

  initial_class: string;
  current_class: string;
  classification_array: any;

  constructor(
    dialogService: DialogService,
    private service: ProjectService
  ) {
    super(dialogService);
  }

  ngOnInit() {
    if (this.initial_class === '') {
      this.initial_class = 'NA';
    }
    this.getallClassification();
  }

  getallClassification() {
    this.service.getAnalysisClassification().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.classification_array = response.data;
    });
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  editClass() {
    this.result = this.current_class;
    this.close();
  }


}
