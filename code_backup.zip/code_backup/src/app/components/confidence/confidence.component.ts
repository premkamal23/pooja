import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-confidence',
  templateUrl: './confidence.component.html',
  styleUrls: ['./confidence.component.css']
})
export class ConfidenceComponent implements OnInit {

  @Input('confidenceData')
  confidenceData: any = {};

  @Output('filterChanged')
  filterChanged: EventEmitter<any> = new EventEmitter<any>();

  displayValues: any = {
    eq: 'is',
    ne: 'is not',
    gte: 'At least',
    lt: 'less than'
  };
  filterName: string;
  constructor() { }

  ngOnInit() {
    this.filterName = this.confidenceData.name;
  }

  setData({ target }) {
    const { value, name, checked, type } = target;
    const val = type === 'checkbox' ? checked : value;
    this.confidenceData.options[name] = val;

    const dependentModulesAttr = target.getAttribute('attr.dependent-models');
    if (dependentModulesAttr) {
      const models = dependentModulesAttr.split(',').map(a => a.trim());
      models.forEach(m => {
        this._filterChanged(m, checked ? this.confidenceData.options[m] : null);
      });
    }

    this._filterChanged(name, val);
  }

  filterNameChanged({ target }) {
    let data;
    if (!this.confidenceData.options.variant_filter && !this.confidenceData.options.call_quality
      && !this.confidenceData.options.read_depth && !this.confidenceData.options.gq
      && !this.confidenceData.options.allele_fraction) {
      data = {
        name: this.filterName,
        options: null
      };
    } else {
      data = {
        name: this.filterName,
        options: {
          type: `com.pki.ngs.entities.ConfidenceFilter`,
          keep_exclude: this.confidenceData.options.keep_exclude,
          any_all: this.confidenceData.options.any_all
        }
      };
    }
    this.filterChanged.emit(data);
  }

  _filterChanged(filterName, value) {
    let data;
    if (!this.confidenceData.options.variant_filter && !this.confidenceData.options.call_quality
      && !this.confidenceData.options.read_depth && !this.confidenceData.options.gq
      && !this.confidenceData.options.allele_fraction) {
      data = {
        name: this.filterName,
        options: null
      };
    } else {
      data = {
        name: this.filterName,
        options: {
          type: `com.pki.ngs.entities.ConfidenceFilter`,
          keep_exclude: this.confidenceData.options.keep_exclude,
          any_all: this.confidenceData.options.any_all
        }
      };
      data.options[filterName] = value;
    }
    this.filterChanged.emit(data);
  }

}
