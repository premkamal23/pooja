import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { HttpClient } from '@angular/common/http';

export interface geneData {

}
@Component({
  selector: 'app-genelist-dialog',
  templateUrl: './genelist-dialog.component.html',
  styleUrls: ['./genelist-dialog.component.css']
})
export class GenelistDialogComponent extends DialogComponent<geneData, any> implements geneData, OnInit {

  addGeneListURL = '/api/geneFile';
  formData: FormData;
  file: File;
  description = '';
  errorMsg = null;
  errorBoolean = false;
  constructor(
    dialogService: DialogService,
    private http: HttpClient) {
    super(dialogService);
  }

  ngOnInit() {
  }

  onChange(event) {
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      this.file = fileList[0];
      this.formData = new FormData();
      this.formData.append('geneFile', this.file);
    }
  }

  addNewGene() {
    this.formData.append('description', this.description);
    const payload = this.formData;
    this.http.post(this.addGeneListURL, payload).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.result = response.data.status;
      this.close();
    }, (error: any) => {
      this.errorBoolean = true;
      console.error(error.error.data);
      this.errorMsg = error.error.data;
    });
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  replaceGene() {
    this.formData.append('overwrite', 'true');
    const payload = this.formData;
    this.http.post(this.addGeneListURL, payload).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.result = response.data.status;
      this.close();
    }, (error: any) => {
      console.error(error.error.data);
      this.errorMsg = error.error.data;
    });
  }

}
