import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { ProjectService } from '../../common/services/project.service';

export interface ClientDetails {
  client: number;
  vcf: boolean;
  type: string;
}

@Component({
  selector: 'app-logo-browse',
  templateUrl: './logo-browse.component.html',
  styleUrls: ['./logo-browse.component.css']
})
export class LogoBrowseComponent extends DialogComponent<ClientDetails, any> implements ClientDetails, OnInit {

  client: number;
  vcf: boolean;
  type: string;
  offset: number;
  firstRecord: number;
  limit = 10;
  filterPayload: any;
  sortBy = 'name';
  sortDir = 'asc';
  totalRecords: number;
  gridContent: any;
  fileSelected: any;
  data: any;

  constructor(
    dialogService: DialogService,
    private projectService: ProjectService
  ) {
    super(dialogService);
  }

  ngOnInit() {
  }

  closeModal() {
    this.close();
  }

  setSelectedFile() {
    this.result = {
      name: this.fileSelected.name,
      path: this.fileSelected.path
    };
    this.close();
  }

  lazyLoadData(event) {
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = event.first / event.rows;
    this.firstRecord = event.first;
    this.sortBy = event.sortField ? event.sortField : 'name';
    this.sortDir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    const filters = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});
    this.filterPayload = filters ? filters : {};
    this.getLogoDetails(this.offset, this.limit);
  }

  getLogoDetails(offset, limit) {
    this.projectService.getLogoDetails(offset, limit)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.data = response.data.logos;
        this.totalRecords = response.data.totalCount;
      });
  }

  filesSelected(event) {
    this.fileSelected = event.data;
  }

}
