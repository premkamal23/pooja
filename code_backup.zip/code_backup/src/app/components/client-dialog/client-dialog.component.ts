import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { UserManagementService } from '../../common/services/user-management.service';

export interface ClientDetails {
  name: string;
  folderNames: Array<any>;
  isEdit: boolean;
  active: boolean;
}
@Component({
  selector: 'app-client-dialog',
  templateUrl: './client-dialog.component.html',
  styleUrls: ['./client-dialog.component.css']
})
export class ClientDialogComponent extends DialogComponent<ClientDetails, any> implements ClientDetails, OnInit {

  name: string;
  folder_list = [];
  folderNames = [];
  errorList: Array<any>;
  isEdit: boolean;
  active: boolean;
  clientFolderBoolean = false;
  constructor(
    dialogService: DialogService,
    private service: UserManagementService
  ) {
    super(dialogService);
  }

  ngOnInit() {
    this.clearError();
    this.getAllFolders();
    if (this.folderNames) {
      this.service.getAllFolders().subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.folder_list = response.data;
        for (let i = 0; i < this.folderNames.length; i++) {
          if (this.folder_list.includes(this.folderNames[i])) {
          } else {
            this.folder_list = this.folder_list.concat(this.folderNames);
          }
        }
      });
    }
  }

  getAllFolders() {
    this.service.getAllFolders().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.folder_list = response.data; this.folder_list = response.data;
      this.clientFolderBoolean = this.folder_list.length === 0 ? true : false;
    });
  }

  closeModal() {
    this.result = false;
    this.isEdit = false;
    this.close();
  }
  
  setData(event) {
    if (this.folderNames === null) {
      this.folderNames = [];
    }
    if (event.target.checked) {
      this.folderNames.push(event.target.value);
    } else {
      for (let i = 0; i < this.folderNames.length; i++) {
        if (this.folderNames[i] === event.target.value) {
          this.folderNames.splice(i, 1);
          break;
        }
      }
    }
  }

  getClientDetails() {
    this.clearError();
    if (!this.name) {
      this.errorList.push('Please enter valid Client Name');
    }
    if (!this.folderNames || this.folderNames.length === 0) {
      this.errorList.push('Please assign at-least one folder');
    }
    if (this.errorList.length === 0) {
      this.result = {
        name: this.name,
        folders: this.folderNames,
        active: this.active
      };
      this.close();
    }

  }

  clearError() {
    this.errorList = [];
  }

  setActive(event) {
    this.active = event.target.checked;
  }

}
