import { Component, OnInit } from '@angular/core';
import { MedixcelService } from '../../common/services/medixcel.service';

@Component({
  selector: 'medixcel',
  templateUrl: './medixcel.component.html',
  styleUrls: ['./medixcel.component.css']
})
export class MedixcelComponent implements OnInit {
  from_date: any = null;
  to_date: any = null;
  date = new Date();
  totalRecords = 0;
  offset = 0;
  limit = 10;
  sortBy = 'release_date';
  sortDir = 'desc';
  firstRecord: number;
  filterPayload: any = {};
  externalfilter: any = {};
  mediStatus: string = 'all';
  apiResponse: any;
  Gridcontent: any;
  constructor(
    private service: MedixcelService
  ) { }

  ngOnInit() {
  }

  getAllReports() {
    this.service.getAllMediReports(this.sortBy, this.sortDir, this.offset, this.limit, this.filterPayload)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.apiResponse = response.data.content;
        this.totalRecords = response.data.totalElements;
        this.Gridcontent = [...this.apiResponse];
      });
  }

  showDate(type) {

    if (type === 'from_date') {
      this.externalfilter[type] = this.from_date.getTime();
      this.to_date = new Date();
      this.externalfilter['to_date'] = this.to_date.getTime();
    } else {
      this.externalfilter[type] = this.to_date.getTime();
    }
    if (this.filterPayload !== null) {
      this.filterPayload = Object.assign({}, this.filterPayload, this.externalfilter)
    }
    this.service.getAllMediReports(this.sortBy, this.sortDir, this.offset, this.limit, this.externalfilter)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.apiResponse = response.data.content;
        this.totalRecords = response.data.totalElements;
        this.Gridcontent = [...this.apiResponse];
      });
  }

  changestatus(type) {
    if (this.mediStatus === 'all') {
      delete this.externalfilter.send_to_medixcel;
      delete this.filterPayload.send_to_medixcel;
    } else {
      this.externalfilter[type] = this.mediStatus;
    }
    if (this.filterPayload !== null) {
      this.filterPayload = Object.assign({}, this.filterPayload, this.externalfilter)
    }
    this.service.getAllMediReports(this.sortBy, this.sortDir, this.offset, this.limit, this.filterPayload)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.apiResponse = response.data.content;
        this.totalRecords = response.data.totalElements;
        this.Gridcontent = [...this.apiResponse];
      });
  }

  lazyLoadData(event) {
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = event.first / event.rows;
    this.firstRecord = event.first;
    this.sortBy = event.sortField ? event.sortField : 'release_date';
    this.sortDir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    const filters: any = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});

    if (this.from_date !== null) {
      this.filterPayload = filters ? Object.assign({}, filters, this.externalfilter) : this.externalfilter;
    } else if (this.mediStatus !== 'all') {
      this.filterPayload = filters ? Object.assign({}, filters, this.externalfilter) : this.externalfilter;
    } else {
      this.filterPayload = filters ? filters : {};
    }

    this.getAllReports();
  }

  clearAllFilters() {
    this.from_date = null;
    this.to_date = null;
    this.mediStatus = 'all';
    this.filterPayload = {};
    this.externalfilter = {};
    this.getAllReports();
  }

}
