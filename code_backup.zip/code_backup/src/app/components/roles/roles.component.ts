import { Component, OnInit } from '@angular/core';
import { DialogService } from 'ng2-bootstrap-modal';
import { RoleDialogComponent } from '../role-dialog/role-dialog.component';
import { UserManagementService } from '../../common/services/user-management.service';
declare var $: any;

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {

  client_list: any;
  Gridcontent: any;
  apiResponse: any;
  totalRecords: number;
  role_id: number;
  permission_list = [];
  role_name: string;
  alertMessage: string;
  grid_permissions: any;
  offset = 0;
  limit = 10;
  sortBy = 'name';
  sortDir = 'asc';
  firstRecord: number;
  notes_edit = false;
  invalid_notes = false;
  roleDetails = {
    'name': this.role_name,
    'permission_ids': this.permission_list
  };

  constructor(private dialogService: DialogService,
    private userService: UserManagementService) { }

  ngOnInit() {
  }

  addRole() {
    if (!this.notes_edit) {
      let newobj: any = {};
      this.roleDetails = newobj;
    } else {
      this.roleDetails.name = this.role_name;
      this.roleDetails.permission_ids = this.permission_list;
    }
    const disposable = this.dialogService.addDialog(RoleDialogComponent, this.roleDetails);
    disposable.subscribe((Response: any) => {
      if (Response !== false) {
        this.role_name = Response.name;
        this.permission_list = Response.permission_list;
        this.userService.createRole(Response.name, Response.permission_list).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.notes_edit = false;
          this.invalid_notes = false;
          this.getRolesForClient();
          this.alertMessage = response.data;
          $('#alert').modal('toggle');
        }, (err) => {
          this.invalid_notes = true;
          this.alertMessage = err.error.data;
          $('#alert').modal('toggle');
        });
      } else {
        this.notes_edit = false;
        this.invalid_notes = false;
        this.getRolesForClient();
      }
    });
  }

  getRolesForClient() {
    this.userService.getAllRolesForClient(this.offset, this.limit, this.sortBy, this.sortDir).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.userService.getAllpermissions().subscribe((data: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        const pids = {};
        data.data.forEach(pid => {
          pids[pid.id] = pid.description;
        });
        this.apiResponse = response.data.content.map(res => {
          res.permission_id = res.permission_ids.map(pid => {
            return pids[pid];
          });
          return res;
        });
        this.totalRecords = response.data.totalElements;
        this.Gridcontent = [...this.apiResponse];
      });
    });
  }

  deleteRole(event) {
    this.role_id = event.id;
    $('#removeRole').modal('toggle');
  }

  deleteSelectedRole() {
    this.userService.deleteRole(this.role_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.getRolesForClient();
    });
  }

  editRole(event) {
    this.roleDetails.name = event.name;
    this.roleDetails.permission_ids = event.permission_ids;
    this.role_id = event.id;
    this.dialogService.addDialog(RoleDialogComponent, this.roleDetails)
      .subscribe((Response: any) => {
        if (Response !== false) {
          this.role_name = Response.name;
          this.permission_list = Response.permission_list;
          this.userService.updateRole(this.role_id, this.role_name, this.permission_list)
            .subscribe((response: any) => {
              const authToken = response.token;
              if (response.token !== null) {
                sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
              } else { }
              this.getRolesForClient();
            });
        } else {
          this.getRolesForClient();
        }
      });
  }

  lazyLoadData(event) {
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = event.first / event.rows;
    this.firstRecord = event.first;
    this.sortBy = event.sortField ? event.sortField : 'name';
    this.sortDir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    if (key.length !== 0) {
      this.userService.
        getAllRolesForClientSearch(this.offset, this.limit, this.sortBy, this.sortDir, key, event.filters.name.value)
        .subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.userService.getAllpermissions().subscribe((data: any) => {
            const authToken = data.token;
            if (data.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            const pids = {};
            data.data.forEach(pid => {
              pids[pid.id] = pid.description;
            });
            this.apiResponse = response.data.content.map(res => {
              res.permission_id = res.permission_ids.map(pid => {
                return pids[pid];
              });
              return res;
            });
            this.totalRecords = response.data.totalElements;
            this.Gridcontent = [...this.apiResponse];
          });
        });
    } else {
      this.getRolesForClient();
    }
  }
}
