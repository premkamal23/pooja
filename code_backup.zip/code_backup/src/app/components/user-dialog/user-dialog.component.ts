import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { UserManagementService } from '../../common/services/user-management.service';
export interface ClientData {
  first_name: string;
  last_name: string;
  email: string;
  role: number;
  password: string;
  cpassword: string;
  isEdit: boolean;
  user: number;
  active: boolean;
  client_ids: Array<any>;
}
@Component({
  selector: 'app-user-dialog',
  templateUrl: './user-dialog.component.html',
  styleUrls: ['./user-dialog.component.css']
})
export class UserDialogComponent extends DialogComponent<ClientData, any> implements ClientData, OnInit {

  role: number;
  client_ids = [];
  active: boolean;
  roles_list: any;
  first_name: string;
  last_name: string;
  email: string;
  designation: string;
  password: string;
  cpassword: string;
  errorList: Array<any>;
  isEdit = false;
  changeFilled = false;
  user: number;
  dropdownSettings = {};
  client_list = [];
  selectedClients = [];
  selectedClientList = [];
  constructor(dialogService: DialogService,
    private userService: UserManagementService) {
    super(dialogService);
  }

  ngOnInit() {
    this.selectedClientList = this.client_ids;
    this.clearError();
    this.userService.getAllActivatedClients().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      for (let i = 0; i < response.data.length; i++) {
        this.client_list = this.client_list.concat({ item_id: response.data[i].id, item_text: response.data[i].name });
      }
      if (this.selectedClientList) {
        this.selectedClients = this.client_list
          .filter(cvl => this.selectedClientList.find(co => co === cvl.item_id));
      }
    });
    this.getAllRoles();
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }

  confirm() {
    this.result = true;
    this.close();
  }

  closeModal() {
    this.result = false;
    this.isEdit = false;
    this.close();
  }

  getAllRoles() {
    this.userService.getAllRoles().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.roles_list = response.data.content;
    });
  }

  addUSer() {
    this.clearError();
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
    let mailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (!this.first_name) {
      this.errorList.push('Please enter first name');
    }
    if (!this.email || !mailRegex.test(this.email)) {
      this.errorList.push('Please enter valid email address');
    }
    if (!this.role) {
      this.errorList.push('Please select role');
    }
    if (!this.designation) {
      this.errorList.push('Please enter designation');
    }
    if (this.selectedClients.length === 0) {
      if ((!this.selectedClientList || this.selectedClientList.length === 0)) {
        this.errorList.push('Please select minimum one client from the list');
      }
    }
    if (!passwordRegex.test(this.password) && !this.isEdit) {
      this.errorList.push('Please enter valid password. The password should be atleast 8 characters long, alphanumeric and with one special character.');
    }
    if (!this.cpassword && !this.isEdit) {
      this.errorList.push('Please re-enter password in Confirm password');
    }
    if ((this.password && this.cpassword) && (this.password !== this.cpassword) && !this.isEdit) {
      this.errorList.push('Password & confirmed password do not match');
    }

    if (this.errorList.length > 0) {

    } else {
      this.result = {
        first_name: this.first_name,
        last_name: this.last_name,
        email: this.email,
        role: this.role,
        user: this.user,
        designation: this.designation,
        password: this.password,
        confirmPassword: this.cpassword,
        active: this.active,
        client_ids: this.selectedClientList
      };
      this.close();
    }

  }

  clearError() {
    this.errorList = [];
  }

  _dropDownOptionsChanged(item, modelName, fieldName) {
    this.selectedClientList = this[fieldName].map(o => o.item_id);
  }

  _SelectAlldropDownOptionsChanged(item, modelName, fieldName) {
    if (item) {
      this.selectedClientList = [];
      for (let i = 0; i < item.length; i++) {
        this.selectedClientList[i] = item[i].item_id;
      }
    }
  }

  _DeselectAlldropDownOptionsChanged(item, modelName, fieldName) {
    this.selectedClientList = [];
  }

  setActive(event) {
    this.active = event.target.checked;
  }
}
