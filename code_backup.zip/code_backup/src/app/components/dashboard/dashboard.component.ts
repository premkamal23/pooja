import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DialogService } from 'ng2-bootstrap-modal';
import { AuthenticationService } from '../../common/services/authentication.service';
import { ChangePasswordComponent } from '../change-password/change-password.component';
declare var $: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {
  userName: string;
  isAnalysisActive = true;
  isGeneActive = false;
  isUserActive = false;
  isMasterVariantActive = false;
  isMasterGeneActive = false;
  isReportActive = false;
  userManagementAllowed = false;
  masterVariantAllowed = false;
  masterGeneAllowed = false;
  clinicalReportAllowed = false;
  user_id: number;
  email: string;
  passwordMsg: string;
  resetPasswordData: any = {
    'user_id': this.user_id,
    'email': this.email,
    'loc': 'user'
  };
  constructor(
    private router: Router,
    private service: AuthenticationService,
    private dialogService: DialogService) {
  }

  ngOnInit() {
    this.user_id = Number(sessionStorage.getItem('user_id'));
    this.email = sessionStorage.getItem('email');
    const permissions = sessionStorage.getItem('permissions').split(',');
    if (permissions) {
      this.userManagementAllowed = permissions.includes('USER_MANAGEMENT') ? true : false;
      this.masterVariantAllowed = permissions.includes('VIEW_MASTER_VARIANT_TABLE') ? true : false;
      this.masterGeneAllowed = permissions.includes('VIEW_MASTER_GENE_TABLE') ? true : false;
      this.clinicalReportAllowed = permissions.includes('CLINICAL_REPORT_MANAGEMENT') ? true : false;
    }
    this.userName = sessionStorage.getItem('user');
    if (document.location.href.indexOf('miscellaneous') !== -1) {
      this.isGeneActive = true;
      this.isAnalysisActive = false;
      this.isUserActive = false;
      this.isMasterVariantActive = false;
      this.isMasterGeneActive = false;
      this.isReportActive = false;
    } else if (document.location.href.indexOf('user') !== -1) {
      this.isUserActive = true;
      this.isAnalysisActive = false;
      this.isGeneActive = false;
      this.isMasterVariantActive = false;
      this.isMasterGeneActive = false;
      this.isReportActive = false;
    } else if (document.location.href.indexOf('master-variant') !== -1) {
      this.isMasterVariantActive = true;
      this.isUserActive = false;
      this.isAnalysisActive = false;
      this.isGeneActive = false;
      this.isMasterGeneActive = false;
      this.isReportActive = false;
    } else if (document.location.href.indexOf('report') !== -1) {
      this.isReportActive = false;
      this.isMasterVariantActive = false;
      this.isUserActive = false;
      this.isAnalysisActive = false;
      this.isGeneActive = false;
      this.isMasterGeneActive = false;
    } else if (document.location.href.indexOf('master-gene') !== -1) {
      this.isMasterGeneActive = true;
      this.isUserActive = false;
      this.isAnalysisActive = false;
      this.isGeneActive = false;
      this.isMasterVariantActive = false;
      this.isReportActive = false;
    } else if (document.location.href.indexOf('report-module') !== -1) {
      this.isMasterGeneActive = false;
      this.isUserActive = false;
      this.isAnalysisActive = false;
      this.isGeneActive = false;
      this.isMasterVariantActive = false;
      this.isReportActive = true;
    } else {
      this.isAnalysisActive = true;
      this.isGeneActive = false;
      this.isUserActive = false;
      this.isMasterVariantActive = false;
      this.isMasterGeneActive = false;
      this.isReportActive = false;
    }
  }

  logout() {
    this.service.logout().subscribe((response: any) => {
      sessionStorage.removeItem('Authorization');
      sessionStorage.removeItem('user');
      sessionStorage.removeItem('user_id');
      sessionStorage.removeItem('designation');
      sessionStorage.removeItem('sessionFilters');
      sessionStorage.removeItem('permissions');
      sessionStorage.removeItem('clients');
      sessionStorage.removeItem('anaysisFilters');
      sessionStorage.removeItem('response_id');
      this.router.navigate(['/login']);
    });
  }

  changePassword() {
    this.resetPasswordData.user_id = this.user_id;
    this.resetPasswordData.email = this.email;
    const disposable = this.dialogService.addDialog(ChangePasswordComponent, this.resetPasswordData);
    disposable.subscribe((response: any) => {
      if (response !== false) {
        this.passwordMsg = response;
        $('#resetPassword1').modal('toggle');
        setTimeout(function () {
          $('#resetPassword1').modal('hide');
        }, 4000);
      }
    });
  }

  login() {
    this.router.navigate(['/login']);
  }

  getProgressDashboard() {
    this.isAnalysisActive = true;
    this.isGeneActive = false;
    this.isUserActive = false;
    this.isMasterVariantActive = false;
    this.isMasterGeneActive = false;
    this.isReportActive = false;
    this.router.navigate(['app/process-analysis']);
    sessionStorage.removeItem('analysis_name');
  }

  getGeneBoard() {
    this.isGeneActive = true;
    this.isAnalysisActive = false;
    this.isUserActive = false;
    this.isMasterVariantActive = false;
    this.isMasterGeneActive = false;
    this.isReportActive = false;
    this.router.navigate(['app/miscellaneous/create-gene']);
  }

  getUserBoard() {
    this.isUserActive = true;
    this.isAnalysisActive = false;
    this.isGeneActive = false;
    this.isMasterVariantActive = false;
    this.isMasterGeneActive = false;
    this.isReportActive = false;
    this.router.navigate(['app/user-management']);
  }

  getReportBoard() {
    this.isReportActive = true;
    this.isUserActive = false;
    this.isAnalysisActive = false;
    this.isGeneActive = false;
    this.isMasterVariantActive = false;
    this.isMasterGeneActive = false;
    this.router.navigate(['app/clinical-report/report-module']);
  }

  getMasterGeneBoard() {
    this.isMasterGeneActive = true;
    this.isUserActive = false;
    this.isAnalysisActive = false;
    this.isGeneActive = false;
    this.isMasterVariantActive = false;
    this.isReportActive = false;
    this.router.navigate(['app/master-gene']);
  }

  getMasterVariantBoard() {
    this.isMasterVariantActive = true;
    this.isMasterGeneActive = false;
    this.isUserActive = false;
    this.isAnalysisActive = false;
    this.isGeneActive = false;
    this.isReportActive = false;
    this.router.navigate(['app/master-variant']);
  }

  getSpecificMasterGeneBoard(geneRouted) {
    const gene = geneRouted;
    this.isMasterGeneActive = true;
    this.isUserActive = false;
    this.isAnalysisActive = false;
    this.isGeneActive = false;
    this.isMasterVariantActive = false;
    this.isReportActive = false;
    this.router.navigate(['app/master-gene'], { queryParams: { gene: gene } });
  }

  getSpecificMasterVariantBoard(routedVariant) {
    this.isMasterVariantActive = true;
    this.isMasterGeneActive = false;
    this.isUserActive = false;
    this.isAnalysisActive = false;
    this.isGeneActive = false;
    this.isReportActive = false;
    this.router.navigate(['app/master-variant'], { queryParams: { variant: routedVariant } });
  }

}
