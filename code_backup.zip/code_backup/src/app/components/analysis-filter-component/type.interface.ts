export interface ITypeList {
    item_id: number;
    item_text: string;
}
