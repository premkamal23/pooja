import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { ProjectService } from '../../common/services/project.service';
import { typeList } from './type';

export interface analysisFilterData {
  allClients: any,
  pki_class_status_values: any,
  statusList: any,
  types: any,
  owners: any,
  fromCDate: any;
  toCDate: any;
  fromMDate: any;
  toMDate: any;
}

@Component({
  selector: 'filter-component',
  templateUrl: './filter-component.component.html',
  styleUrls: ['./filter-component.component.css']
})
export class FilterComponentComponent extends DialogComponent<analysisFilterData, any> implements analysisFilterData, OnInit {

  allClients: any;
  pki_class_status_values: any;
  statusList: any;
  types: any;
  owners: any
  filterData: any;
  typeList = typeList;
  fromCDate: any;
  toCDate: any;
  fromMDate: any;
  toMDate: any;

  client_list = [];
  owner_list = [];
  flag_list = [];
  status_list = [];
  type_list = [];

  dropdownSettings = {};

  selectedClients = [];
  selectedClientList = [];

  selectedOwners = [];
  selectedOwnerList = [];

  selectedFlag = [];
  selectedFlagList = [];

  selectedstatus = [];
  selectedstatusList = [];

  selectedType = [];
  selectedTypeList = [];

  fromCreatedDate: any;
  fCDate: any;
  toCreatedDate: any;
  tCDate: any;
  fromModifiedDate: any;
  fMDate: any;
  toModifiedDate: any;
  tMDate: any;
  date = new Date();

  constructor(dialogService: DialogService,
    private service: ProjectService) {
    super(dialogService);
  }

  ngOnInit() {
    this.getData();
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }

  addFilters() {
    this.result = {
      allClients: this.selectedClientList,
      pki_class_status_values: this.selectedFlagList,
      statusList: this.selectedstatusList,
      types: this.selectedTypeList,
      owners: this.selectedOwnerList,
      fromCreatedDate: this.fCDate,
      toCreatedDate: this.tCDate,
      fromModifiedDate: this.fMDate,
      toModifiedDate: this.tMDate
    }
    this.close();
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  ClearFilter() {
    this.result = 'clear';
    this.close();
  }

  getData() {
    this.fromCreatedDate = this.fromCDate ? new Date(this.fromCDate) : undefined;
    this.fCDate = this.fromCDate ? this.fromCDate : undefined;
    this.toCreatedDate = this.toCDate ? new Date(this.toCDate) : undefined;
    this.tCDate = this.toCDate ? this.toCDate : undefined;
    this.fromModifiedDate = this.fromMDate ? new Date(this.fromMDate) : undefined;
    this.fMDate = this.fromMDate ? this.fromMDate : undefined;
    this.toModifiedDate = this.toMDate ? new Date(this.toMDate) : undefined;
    this.tMDate = this.toMDate ? this.toMDate : undefined;

    this.service.getFilterData().subscribe((response: any) => {
      const authToken = response.token;
      if (authToken !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.filterData = response.data;

      this.client_list = response.data.allClients;
      if (this.allClients) {
        this.selectedClients = this.allClients;
        this.selectedClientList = this.allClients;
      }
      this.owner_list = response.data.owners;
      if (this.owners) {
        this.selectedOwners = this.owners;
        this.selectedOwnerList = this.owners;
      }
      //status value
      for (let i = 0; i < response.data.statusList.length; i++) {
        this.status_list = this.status_list
          .concat({ item_id: i, item_text: response.data.statusList[i] });
      }
      if (this.statusList) {
        this.selectedstatus = this.status_list
          .filter(cvl => this.statusList.find(co => co === cvl.item_text));
        this.selectedstatusList = this['selectedstatus'].map(o => o.item_text);
      }

      //typelist
      for (let i = 0; i < this.typeList.length; i++) {
        this.type_list = this.type_list
          .concat({ item_id: this.typeList[i].item_id, item_text: this.typeList[i].item_text });
      }
      if (this.types) {
        this.selectedType = this.type_list
          .filter(cvl => this.types.find(co => co === cvl.item_text));
        this.selectedTypeList = this['selectedType'].map(o => o.item_text);
      }

      //flag
      for (let i = 0; i < response.data.pki_class_status_values.length; i++) {
        this.flag_list = this.flag_list
          .concat({ item_id: i, item_text: response.data.pki_class_status_values[i] });
      }
      if (this.pki_class_status_values) {
        this.selectedFlag = this.flag_list
          .filter(cvl => this.pki_class_status_values.find(co => co === cvl.item_text));
        this.selectedFlagList = this['selectedFlag'].map(o => o.item_text);
      }
    });
  }

  addClientOptions(item, modelName, fieldName) {
    this.selectedClientList = this.selectedClientList.concat(item);
  }

  deleteClientOptions(item, modelName, fieldName) {
    for (let i = 0; i < this.selectedClientList.length; i++) {
      if (this.selectedClientList[i].item_id === item.item_id) {
        this.selectedClientList.splice(i, 1);
        break;
      }
    }
  }

  allCientdropDownOptionsChanged(item, modelName, fieldName) {
    if (item) {
      this.selectedClientList = [];
      this.selectedClientList = this.selectedClientList.concat(item);
    }
  }

  deselectAllClientdropDownOptionsChanged(item, modelName, fieldName) {
    this.selectedClientList = [];
  }

  addOwnerOptions(item, modelName, fieldName) {
    let owner = item.item_text.split(' ');
    this.selectedOwnerList = this.selectedOwnerList.concat(item);
  }

  deleteOwnerOptions(item, modelName, fieldName) {
    for (let i = 0; i < this.selectedOwnerList.length; i++) {
      if (this.selectedOwnerList[i].item_id === item.item_id) {
        this.selectedOwnerList.splice(i, 1);
        break;
      }
    }
  }

  allOwnerdropDownOptionsChanged(item, modelName, fieldName) {
    if (item) {
      this.selectedOwnerList = [];
      this.selectedOwnerList = this.selectedOwnerList.concat(item);
    }
  }

  deselectAllOwnerdropDownOptionsChanged(item, modelName, fieldName) {
    this.selectedOwnerList = [];
  }

  statusOptionsChanged(item, modelName, fieldName) {
    this.selectedstatusList = this[fieldName].map(o => o.item_text);
  }

  allstatusdropDownOptionsChanged(item, modelName, fieldName) {
    if (item) {
      this.selectedstatusList = [];
      for (let i = 0; i < item.length; i++) {
        this.selectedstatusList[i] = item[i].item_text;
      }
    }
  }

  deselectAllStatusdropDownOptionsChanged(item, modelName, fieldName) {
    this.selectedstatusList = [];
  }

  flagOptionsChanged(item, modelName, fieldName) {
    this.selectedFlagList = this[fieldName].map(o => o.item_text);
  }

  allFlagdropDownOptionsChanged(item, modelName, fieldName) {
    if (item) {
      this.selectedFlagList = [];
      for (let i = 0; i < item.length; i++) {
        this.selectedFlagList[i] = item[i].item_text;
      }
    }
  }

  deselectAllFlagdropDownOptionsChanged(item, modelName, fieldName) {
    this.selectedFlagList = [];
  }

  typeOptionsChanged(item, modelName, fieldName) {
    this.selectedTypeList = this[fieldName].map(o => o.item_text);
  }

  allTypedropDownOptionsChanged(item, modelName, fieldName) {
    if (item) {
      this.selectedTypeList = [];
      for (let i = 0; i < item.length; i++) {
        this.selectedTypeList[i] = item[i].item_text;
      }
    }
  }

  deselectAllTypedropDownOptionsChanged(item, modelName, fieldName) {
    this.selectedTypeList = [];
  }

  showDate(value) {
    if (value === 'fromCreatedDate') {
      this.fCDate = this.fromCreatedDate.setHours(0, 0, 0);
    } else if (value === 'toCreatedDate') {
      this.tCDate = this.toCreatedDate.setHours(23, 59, 59);
    } else if (value === 'fromModifiedDate') {
      this.fMDate = this.fromModifiedDate.setHours(0, 0, 0);
    } else {
      this.tMDate = this.toModifiedDate.setHours(23, 59, 59);
    }

  }
}
