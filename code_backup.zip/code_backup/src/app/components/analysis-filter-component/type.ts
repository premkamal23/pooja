import { ITypeList } from './type.interface';

export const typeList: Array<ITypeList> = [
    {
        "item_text": "Focused Exome",
        "item_id": 1
    },
    {
        "item_text": "Panel",
        "item_id": 2
    },
    {
        "item_text": "Single Gene",
        "item_id": 3
    },
    {
        "item_text": "Whole Exome",
        "item_id": 4
    },
    {
        "item_text": "Whole Genome",
        "item_id": 5
    }
]