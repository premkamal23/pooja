import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { OpenAnalysisService } from '../../common/services/open-analysis.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ReportTemplateService } from '../../common/services/report-template.service';
declare var $: any;
@Component({
  selector: 'app-report-template',
  templateUrl: './report-template.html',
  styleUrls: ['./report-template.css'],
  encapsulation: ViewEncapsulation.Emulated
})
export class ReportTemplateComponent implements OnInit {
  analysis_id: any;
  report_id: any;
  reportMsg: any;
  selectedVariant: any;
  selectedVariantData: any;
  selectedReportName;
  disableRelease = true;
  disableApprove = false;
  selectedReportID: any = '';
  template = '';
  reportTemplateModel: any;
  editorContent;
  approvers_list: any;
  approvers: any;
  reportTemplateModelreportDisplayName;
  pdfUrl: any = '';
  approvePermissions = false;
  releasePermissions = false;
  leftlogo: any;
  rightlogo: any;
  variants_sections: any;
  YearRange: any = '';
  CkeditorConfig = {
    allowedContent: true,
    height: 100,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    //autoParagraph: false,
    // enterMode: CKEDITOR.ENTER_BR,  //tslint:disable-line
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    //enterMode: 2,
    //forcePasteAsPlainText : true,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };
  CkeditorConfigForTextbox = {
    allowedContent: true,
    height: 30,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    //autoParagraph: false,
    // enterMode: CKEDITOR.ENTER_BR,  //tslint:disable-line
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    //enterMode: 2,
    //forcePasteAsPlainText : true,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };

  NotesCkeditorConfig = {
    allowedContent: true,
    height: 510,
    resize_enabled: false,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    //autoParagraph: false,
    //enterMode: 2,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker,JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock'
  };
  approver_id: any;
  approver_email: any;
  addSignature: boolean = false;
  show_dropdown: boolean = false;
  constructor(
    private openanalysisService: OpenAnalysisService,
    private router: Router,
    private reportTemplateService: ReportTemplateService,
    private route: ActivatedRoute,
  ) {

  }

  ngOnInit() {

    this.analysis_id = this.route.snapshot.paramMap.get('analysis_id');
    this.report_id = this.route.snapshot.paramMap.get('report_id');
    const flag = this.route.snapshot.paramMap.get('draft');
    this.getAllapprovers();
    this.selectedVariantData = [];
    const permissions = sessionStorage.getItem('permissions').split(',');
    this.approvePermissions = permissions.includes('APPROVE_CLINICAL_REPORT') ? true : false;
    this.releasePermissions = permissions.includes('RELEASE_CLINICAL_REPORT') ? true : false;
    this.addSignature = permissions.includes('ADD_SIGNATURES') ? true : false;

    if (flag === 'true') {
      this.reportTemplateService.getDraftData(this.report_id).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.reportTemplateModel = response.data;
        if (response.data.specimen_details && response.data.specimen_details.receive_date) {
          response.data.specimen_details.receive_date = this.convertToDateFormat(response.data.specimen_details.receive_date);
        }
        if (response.data.specimen_details && response.data.specimen_details.report_date) {
          response.data.specimen_details.report_date = this.convertToDateFormat(response.data.specimen_details.report_date);
        }
        if (response.data.specimen_details && response.data.specimen_details.collection_date) {
          response.data.specimen_details.collection_date = this.convertToDateFormat(response.data.specimen_details.collection_date);
        }
        if (response.data.patient_details && response.data.patient_details.patient_dob) {
          response.data.patient_details.patient_dob = this.convertToDateFormat(response.data.patient_details.patient_dob);
        }
        this.leftlogo = this.reportTemplateModel.logo1;
        this.rightlogo = this.reportTemplateModel.logo2;
        if (this.reportTemplateModel.approvals && this.reportTemplateModel.approvals.length > 0) {
          this.disableRelease = false;
        } else {
          this.disableRelease = true;
        }
      });
    } else {
      setTimeout(() => { }, 10000);
      this.openanalysisService.currentMessage.subscribe(message => this.variants_sections = message);
      this.reportTemplateService.getDataBasedOnTemplate(this.analysis_id, this.variants_sections).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        if (response.data.specimen_details && response.data.specimen_details.receive_date) {
          response.data.specimen_details.receive_date = this.convertToDateFormat(response.data.specimen_details.receive_date);
        }
        if (response.data.specimen_details && response.data.specimen_details.report_date) {
          response.data.specimen_details.report_date = this.convertToDateFormat(response.data.specimen_details.report_date);
        }
        if (response.data.specimen_details && response.data.specimen_details.collection_date) {
          response.data.specimen_details.collection_date = this.convertToDateFormat(response.data.specimen_details.collection_date);
        }
        if (response.data.patient_details && response.data.patient_details.patient_dob) {
          response.data.patient_details.patient_dob = this.convertToDateFormat(response.data.patient_details.patient_dob);
        }
        this.reportTemplateModel = response.data;
        this.leftlogo = this.reportTemplateModel.logo1;
        this.rightlogo = this.reportTemplateModel.logo2;
       
      });

    }

    this.YearRange = '1928:' + (new Date().getFullYear());

  }

  goToAnalysis() {
    this.router.navigate(['/app/open-analysis', this.analysis_id]);
  }

  convertToDateFormat(rdate) {
    var d = new Date(rdate);
    return d;
  }

  goToDashboard() {
    this.router.navigate(['/app/process-analysis']);
    sessionStorage.removeItem('analysis_name');
  }

  checkDraft() {
    this.disableApprove = false;
    if (this.reportTemplateModel.status !== null &&
      (this.reportTemplateModel.status.toLowerCase() === 'approved' || this.reportTemplateModel.status.toLowerCase() === 'released')) {
      $('#draftModal').modal('toggle');
    } else {
      this.saveAsDraft();
    }
  }

  setApproveDisableFlag() {
    this.disableApprove = true;
  }

  saveAsDraft() {
    this.reportTemplateModel.status = 'Draft';
    this.reportTemplateService.saveAsDraft(this.reportTemplateModel).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.reportMsg = "Clinical Report saved as draft";
      $('#messageModal').modal('toggle');
      setTimeout(function () {
        $('#messageModal').modal('hide');
      }, 4000);
      this.report_id = response.data.id;
      if (response.data.specimen_details && response.data.specimen_details.receive_date) {
        response.data.specimen_details.receive_date = this.convertToDateFormat(response.data.specimen_details.receive_date);
      }
      if (response.data.specimen_details && response.data.specimen_details.report_date) {
        response.data.specimen_details.report_date = this.convertToDateFormat(response.data.specimen_details.report_date);
      }
      if (response.data.specimen_details && response.data.specimen_details.collection_date) {
        response.data.specimen_details.collection_date = this.convertToDateFormat(response.data.specimen_details.collection_date);
      }
      if (response.data.patient_details && response.data.patient_details.patient_dob) {
        response.data.patient_details.patient_dob = this.convertToDateFormat(response.data.patient_details.patient_dob);
      }
      this.reportTemplateModel = response.data;
      this.disableRelease = this.reportTemplateModel.approvals.length === 0 ? true : false;
    });

  }

  approveReport() {
    if (!this.reportTemplateModel.approvals || this.reportTemplateModel.approvals.length === 0) {
      this.reportTemplateModel.approvals = [{
        'name': sessionStorage.getItem('user'),
        'designation': sessionStorage.getItem('designation'),
        'email': sessionStorage.getItem('email')
      }];
    } else {

      this.reportTemplateModel.approvals.push({
        'name': sessionStorage.getItem('user'),
        'designation': sessionStorage.getItem('designation'),
        'email': sessionStorage.getItem('email'),
      });
    }
    this.reportTemplateModel.status = 'Approved';
    this.reportTemplateService.saveAsDraft(this.reportTemplateModel).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.reportMsg = 'Clinical Report approved';
      $('#messageModal').modal('toggle');
      setTimeout(function () {
        $('#messageModal').modal('hide');
      }, 4000);
      this.report_id = response.data.id;
      if (response.data.specimen_details && response.data.specimen_details.receive_date) {
        response.data.specimen_details.receive_date = this.convertToDateFormat(response.data.specimen_details.receive_date);
      }
      if (response.data.specimen_details && response.data.specimen_details.report_date) {
        response.data.specimen_details.report_date = this.convertToDateFormat(response.data.specimen_details.report_date);
      }
      if (response.data.specimen_details && response.data.specimen_details.collection_date) {
        response.data.specimen_details.collection_date = this.convertToDateFormat(response.data.specimen_details.collection_date);
      }
      if (response.data.patient_details && response.data.patient_details.patient_dob) {
        response.data.patient_details.patient_dob = this.convertToDateFormat(response.data.patient_details.patient_dob);
      }
      this.reportTemplateModel = response.data;
      this.disableApprove = true;
      this.disableRelease = false;
    });

    this.approvers = "0: undefined";
  }

  releaseReport() {
    this.reportTemplateModel.status = 'Released';
    this.reportTemplateModel.id = null;
    this.reportTemplateService.saveAsDraft(this.reportTemplateModel).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.reportTemplateService.generatePDF(response.data.id).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        const url: any = response.data;
        window.open(url, '_blank');
      });
    });
  }

  addRow() {
    if (!this.reportTemplateModel.unrelated_phenotype.pharmaco_vars) {
      this.reportTemplateModel.unrelated_phenotype.pharmaco_vars = [];
    }
    this.reportTemplateModel.unrelated_phenotype.pharmaco_vars.push
      ({ 'gene': '', 'allele_haplotype': '', 'drugs': '', 'enzyme_activity': '', 'metabolizer_status': '' });
  }

  addCNV() {
    if (!this.reportTemplateModel.diagnostic_findings_phenotype.cnvs_list) {
      this.reportTemplateModel.diagnostic_findings_phenotype.cnvs_list = [];
    }
    this.reportTemplateModel.diagnostic_findings_phenotype.cnvs_list.push
      ({ 'cytoband': '', 'event': '', 'genomic_location': '', 'size_bp': '', 'classification': '' });
  }

  previewReport() {
    if (this.reportTemplateModel.id === null) {
      this.reportTemplateModel.status = 'Draft';
      this.reportTemplateService.saveAsDraft(this.reportTemplateModel).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        if (response.data.specimen_details && response.data.specimen_details.receive_date) {
          response.data.specimen_details.receive_date = this.convertToDateFormat(response.data.specimen_details.receive_date);
        }
        if (response.data.specimen_details && response.data.specimen_details.report_date) {
          response.data.specimen_details.report_date = this.convertToDateFormat(response.data.specimen_details.report_date);
        }
        if (response.data.specimen_details && response.data.specimen_details.collection_date) {
          response.data.specimen_details.collection_date = this.convertToDateFormat(response.data.specimen_details.collection_date);
        }
        if (response.data.patient_details && response.data.patient_details.patient_dob) {
          response.data.patient_details.patient_dob = this.convertToDateFormat(response.data.patient_details.patient_dob);
        }
        const content = response.data;
        this.reportTemplateModel = response.data;
        this.reportTemplateService.generatePDF(content.id).subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.pdfUrl = response.data;
          const Drafturl: any = response.data;
          window.open(Drafturl);
        });
      });
    } else {
      this.reportTemplateService.previewNewReport(this.reportTemplateModel).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.pdfUrl = response.data;
        const Tempurl: any = response.data;
        window.open(Tempurl);
      });
    }
  }

  editVariantInterpretationContent(variant) {
    this.selectedVariant = variant;
  }

  removeTags() {
    let newStr = this.selectedVariant.notes.replace(/<\s*p[^>]*>/i, '');
    //let last = newStr.lastIndexOf('</p>');
    newStr = newStr.replace(/<\/p>/i, '');
    this.selectedVariant.notes = newStr;
  }

  getAllapprovers() {
    const client: any = sessionStorage.getItem('analysis_client');
    this.reportTemplateService.getApproversList(client).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.approvers_list = response.data;
    });
  }

  updateApprovers() {
    let nameExistFlag = false;
    var i = this.reportTemplateModel.approvals.indexOf(this.approvers.userName);
    let uniqueArr = [];
    for (let i = 0; i < this.reportTemplateModel.approvals.length; i++) {
      if (this.reportTemplateModel.approvals[i].name === this.approvers.userName) {
        nameExistFlag = true;
      }
    }

    if (nameExistFlag === false) {
      this.reportTemplateModel.approvals.push({
        'name': this.approvers.userName,
        'designation': this.approvers.designation,
        'email': this.approvers.email,
        'id': this.approvers.id
      });
      this.reportTemplateService.saveApproverList(this.report_id, this.approvers).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.reportTemplateModel.approvals = response.data;
        this.approvers = "0: undefined";
        this.show_dropdown = false;
      });
    }
  }

  deleteApprover(approver) {
    this.approver_id = approver.id;
    this.approver_email = approver.email;
    $('#deleteApproverModal').modal('toggle');
  }

  deleteApproverFromList() {
    let loggedinUserEmail = sessionStorage.getItem('email');
    if (this.report_id !== "undefined" || this.approver_id !== "undefined") {
      this.reportTemplateService.deleteApproverFromList(this.report_id, this.approver_id).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.reportTemplateModel.approvals = response.data;

        if (this.approver_email === loggedinUserEmail) {
          this.disableApprove = false;
        }
        if (this.reportTemplateModel.approvals.length === 0) {
          this.disableApprove = false;
        }

        this.approvers = "0: undefined";
        this.disableRelease = this.reportTemplateModel.approvals.length === 0 ? true : false;
      });
    }
  }

  updateMediexcelStatus() {
    if (this.reportTemplateModel.id === null) {

    } else {
      this.reportTemplateService.updateMedStatus(this.report_id, this.reportTemplateModel.send_to_medixcel).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
      });
    }
  }

}
