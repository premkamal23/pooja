export interface IPhenotypeList {
    item_id: number;
    item_text: string;
}
