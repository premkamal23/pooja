import { IPhenotypeList } from './phenotype-list.interface';

export const omimList: Array<IPhenotypeList> = [
    {
        "item_text": "Esophageal squamous cell carcinoma",
        "item_id": 1
      },
      {
        "item_text": "Febrile seizures, familial, 2",
        "item_id": 2
      },
      {
        "item_text": "Febrile seizures, familial, 5",
        "item_id": 3
      },
      {
        "item_text": "Febrile seizures, familial, 6",
        "item_id": 4
      },
      {
        "item_text": "Febrile seizures, familial, 7",
        "item_id": 5
      },
      {
        "item_text": "Febrile seizures, familial, 9",
        "item_id": 6
      },
      {
        "item_text": "Amyotrophy, hereditary neuralgic",
        "item_id": 7
      },
      {
        "item_text": "Leukemia, acute myeloitem_id, therapy-related",
        "item_id": 8
      },
      {
        "item_text": "Ovarian carcinoma",
        "item_id": 9
      },
      {
        "item_text": "Febrile seizures, familial, 10",
        "item_id": 10
      },
      {
        "item_text": "Spermatogenic failure 10",
        "item_id": 11
      },
      {
        "item_text": "Alpha-2-macroglobulin deficiency",
        "item_id": 12
      },
      {
        "item_text": "{Alzheimer disease, susceptibility to}",
        "item_id": 13
      },
      {
        "item_text": "[Blood group, P1Pk system, P(2) phenotype]",
        "item_id": 14
      },
      {
        "item_text": "[Blood group, P1Pk system, p phenotype]",
        "item_id": 15
      },
      {
        "item_text": "NOR polyagglutination syndrome",
        "item_id": 16
      },
      {
        "item_text": "Alopecia areata 1",
        "item_id": 17
      },
      {
        "item_text": "Alopecia areata 2",
        "item_id": 18
      },
      {
        "item_text": "Aortic aneurysm, familial abdominal 1",
        "item_id": 19
      },
      {
        "item_text": "Aortic aneurysm, familial abdominal 2",
        "item_id": 20
      },
      {
        "item_text": "{Aneurysm, familial abdominal 3}",
        "item_id": 21
      },
      {
        "item_text": "Aortic aneurysm, familial abdominal, 4",
        "item_id": 22
      },
      {
        "item_text": "Achalasia-addisonianism-alacrimia syndrome",
        "item_id": 23
      },
      {
        "item_text": "Keratoderma, palmoplantar, punctate type IA",
        "item_id": 24
      },
      {
        "item_text": "Charcot-Marie-Tooth disease, axonal, type 2N",
        "item_id": 25
      },
      {
        "item_text": "Epileptic encephalopathy, early infantile, 29",
        "item_id": 26
      },
      {
        "item_text": "Combined oxitem_idative phosphorylation deficiency 8",
        "item_id": 27
      },
      {
        "item_text": "Leukoencephalopathy, progressive, with ovarian failure",
        "item_id": 28
      },
      {
        "item_text": "Hyperlysinemia",
        "item_id": 29
      },
      {
        "item_text": "Saccharopinuria",
        "item_id": 30
      },
      {
        "item_text": "Aortic aneurysm, familial thoracic 1",
        "item_id": 31
      },
      {
        "item_text": "Aortic aneurysm, familial thoracic 2",
        "item_id": 32
      },
      {
        "item_text": "GABA-transaminase deficiency",
        "item_id": 33
      },
      {
        "item_text": "{Coronary artery disease in familial hypercholesterolemia, protection against}",
        "item_id": 34
      },
      {
        "item_text": "HDL deficiency, type 2",
        "item_id": 35
      },
      {
        "item_text": "Tangier disease",
        "item_id": 36
      },
      {
        "item_text": "Ichthyosis, congenital, autosomal recessive 4A",
        "item_id": 37
      },
      {
        "item_text": "Ichthyosis, congenital, autosomal recessive 4B (harlequin)",
        "item_id": 38
      },
      {
        "item_text": "Surfactant metabolism dysfunction, pulmonary, 3",
        "item_id": 39
      },
      {
        "item_text": "Cone-rod dystrophy 3",
        "item_id": 40
      },
      {
        "item_text": "Fundus flavimaculatus",
        "item_id": 41
      },
      {
        "item_text": "{Macular degeneration, age-related, 2}",
        "item_id": 42
      },
      {
        "item_text": "Retinal dystrophy, early-onset severe",
        "item_id": 43
      },
      {
        "item_text": "Retinitis pigmentosa 19",
        "item_id": 44
      },
      {
        "item_text": "Stargardt disease 1",
        "item_id": 45
      },
      {
        "item_text": "{Alzheimer disease 9, susceptibility to}",
        "item_id": 46
      },
      {
        "item_text": "{Colchicine resistance}",
        "item_id": 47
      },
      {
        "item_text": "{Inflammatory bowel disease 13}",
        "item_id": 48
      },
      {
        "item_text": "Cholestasis, benign recurrent intrahepatic, 2",
        "item_id": 49
      },
      {
        "item_text": "Cholestasis, progressive familial intrahepatic 2",
        "item_id": 50
      },
      {
        "item_text": "Cholestasis, intrahepatic, of pregnancy, 3",
        "item_id": 51
      },
      {
        "item_text": "Cholestasis, progressive familial intrahepatic 3",
        "item_id": 52
      },
      {
        "item_text": "Gallbladder disease 1",
        "item_id": 53
      },
      {
        "item_text": "[Blood group, Langereis system]",
        "item_id": 54
      },
      {
        "item_text": "Dyschromatosis universalis hereditaria 3",
        "item_id": 55
      },
      {
        "item_text": "Microphthalmia, isolated, with coloboma 7",
        "item_id": 56
      },
      {
        "item_text": "Pseudohyperkalemia, familial, 2, due to red cell leak",
        "item_id": 57
      },
      {
        "item_text": "Anemia, sitem_ideroblastic, with ataxia",
        "item_id": 58
      },
      {
        "item_text": "[Axillary odor, variation in]",
        "item_id": 59
      },
      {
        "item_text": "[Colostrum secretion, variation in]",
        "item_id": 60
      },
      {
        "item_text": "[Earwax, wet\/dry]",
        "item_id": 61
      },
      {
        "item_text": "Dubin-Johnson syndrome",
        "item_id": 62
      },
      {
        "item_text": "Arterial calcification, generalized, of infancy, 2",
        "item_id": 63
      },
      {
        "item_text": "Pseudoxanthoma elasticum",
        "item_id": 64
      },
      {
        "item_text": "Pseudoxanthoma elasticum, forme fruste",
        "item_id": 65
      },
      {
        "item_text": "Diabetes mellitus, noninsulin-dependent",
        "item_id": 66
      },
      {
        "item_text": "Diabetes mellitus, permanent neonatal",
        "item_id": 67
      },
      {
        "item_text": "Hyperinsulinemic hypoglycemia, familial, 1",
        "item_id": 68
      },
      {
        "item_text": "Hypoglycemia of infancy, leucine-sensitive",
        "item_id": 69
      },
      {
        "item_text": "Atrial fibrillation, familial, 12",
        "item_id": 70
      },
      {
        "item_text": "Cardiomyopathy, dilated, 1O",
        "item_id": 71
      },
      {
        "item_text": "Hypertrichotic osteochondrodysplasia",
        "item_id": 72
      },
      {
        "item_text": "Adrenoleukodystrophy",
        "item_id": 73
      },
      {
        "item_text": "Adrenomyeloneuropathy, adult",
        "item_id": 74
      },
      {
        "item_text": "?Bile acitem_id synthesis defect, congenital, 5",
        "item_id": 75
      },
      {
        "item_text": "Methylmalonic acitem_iduria and homocystinuria, cblJ type",
        "item_id": 76
      },
      {
        "item_text": "[Junior blood group system]",
        "item_id": 77
      },
      {
        "item_text": "[Uric acitem_id concentration, serum, QTL1]",
        "item_id": 78
      },
      {
        "item_text": "Sitosterolemia",
        "item_id": 79
      },
      {
        "item_text": "{Gallbladder disease 4}",
        "item_id": 80
      },
      {
        "item_text": "Sitosterolemia",
        "item_id": 81
      },
      {
        "item_text": "Polyneuropathy, hearing loss, ataxia, retinitis pigmentosa, and cataract",
        "item_id": 82
      },
      {
        "item_text": "Chanarin-Dorfman syndrome",
        "item_id": 83
      },
      {
        "item_text": "Congenital heart defects and skeletal malformations syndrome",
        "item_id": 84
      },
      {
        "item_text": "Leukemia, Philadelphia chromosome-positive, resistant to imatinib ",
        "item_id": 85
      },
      {
        "item_text": "Leukemia, acute myeloitem_id, with eosinophilia ",
        "item_id": 86
      },
      {
        "item_text": "[Blood group, ABO system]",
        "item_id": 87
      },
      {
        "item_text": "Acetyl-CoA carboxylase deficiency",
        "item_id": 88
      },
      {
        "item_text": "Isobutyryl-CoA dehydrogenase deficiency",
        "item_id": 89
      },
      {
        "item_text": "Mitochondrial complex I deficiency due to ACAD9 deficiency",
        "item_id": 90
      },
      {
        "item_text": "Acyl-CoA dehydrogenase, medium chain, deficiency of",
        "item_id": 91
      },
      {
        "item_text": "Acyl-CoA dehydrogenase, short-chain, deficiency of",
        "item_id": 92
      },
      {
        "item_text": "2-methylbutyrylglycinuria",
        "item_id": 93
      },
      {
        "item_text": "VLCAD deficiency",
        "item_id": 94
      },
      {
        "item_text": "Short stature and advanced bone age, with or without early-onset osteoarthritis and\/or osteochondritis dissecans",
        "item_id": 95
      },
      {
        "item_text": "?Spondyloepimetaphyseal dysplasia, aggrecan type",
        "item_id": 96
      },
      {
        "item_text": "?Spondyloepiphyseal dysplasia, Kimberley type",
        "item_id": 97
      },
      {
        "item_text": "Alpha-methylacetoacetic acitem_iduria",
        "item_id": 98
      },
      {
        "item_text": "?ACAT2 deficiency",
        "item_id": 99
      },
      {
        "item_text": "?Dyskeratosis congenita, autosomal dominant 6",
        "item_id": 100
      },
      {
        "item_text": "?Dyskeratosis congenita, autosomal recessive 7",
        "item_id": 101
      },
      {
        "item_text": "[Angiotensin I-converting enzyme, benign serum increase]",
        "item_id": 102
      },
      {
        "item_text": "{Microvascular complications of diabetes 3}",
        "item_id": 103
      },
      {
        "item_text": "{Myocardial infarction, susceptibility to} ",
        "item_id": 104
      },
      {
        "item_text": "Renal tubular dysgenesis",
        "item_id": 105
      },
      {
        "item_text": "{SARS, progression of}",
        "item_id": 106
      },
      {
        "item_text": "{Stroke, hemorrhagic}",
        "item_id": 107
      },
      {
        "item_text": "Cayler cardiofacial syndrome",
        "item_id": 108
      },
      {
        "item_text": "[Blood group, Yt system]",
        "item_id": 109
      },
      {
        "item_text": "[Blood group, Duffy system]",
        "item_id": 110
      },
      {
        "item_text": "{Malaria, vivax, protection against}",
        "item_id": 111
      },
      {
        "item_text": "[White blood cell count QTL]",
        "item_id": 112
      },
      {
        "item_text": "Infantile cerebellar-retinal degeneration",
        "item_id": 113
      },
      {
        "item_text": "?Optic atrophy 9",
        "item_id": 114
      },
      {
        "item_text": "Peroxisomal acyl-CoA oxitem_idase deficiency",
        "item_id": 115
      },
      {
        "item_text": "Bile acitem_id synthesis defect, congenital, 6",
        "item_id": 116
      },
      {
        "item_text": "?Lysosomal acitem_id phosphatase deficiency",
        "item_id": 117
      },
      {
        "item_text": "Amelogenesis imperfecta, type IJ",
        "item_id": 118
      },
      {
        "item_text": "Spondyloenchondrodysplasia with immune dysregulation",
        "item_id": 119
      },
      {
        "item_text": "?Male infertility due to acrosin deficiency",
        "item_id": 120
      },
      {
        "item_text": "Acropectoral syndrome",
        "item_id": 121
      },
      {
        "item_text": "Acropectorovertebral dysplasia",
        "item_id": 122
      },
      {
        "item_text": "Combined malonic and methylmalonic acitem_iduria",
        "item_id": 123
      },
      {
        "item_text": "Mental retardation, X-linked 63",
        "item_id": 124
      },
      {
        "item_text": "Myelodysplastic syndrome",
        "item_id": 125
      },
      {
        "item_text": "Myelogenous leukemia, acute",
        "item_id": 126
      },
      {
        "item_text": "{?Hypertension, essential}",
        "item_id": 127
      },
      {
        "item_text": "Myopathy, actin, congenital, with cores",
        "item_id": 128
      },
      {
        "item_text": "Myopathy, actin, congenital, with excess of thin myofilaments",
        "item_id": 129
      },
      {
        "item_text": "?Myopathy, scapulohumeroperoneal",
        "item_id": 130
      },
      {
        "item_text": "Nemaline myopathy 3, autosomal dominant or recessive",
        "item_id": 131
      },
      {
        "item_text": "Aortic aneurysm, familial thoracic 6",
        "item_id": 132
      },
      {
        "item_text": "Moyamoya disease 5",
        "item_id": 133
      },
      {
        "item_text": "Multisystemic smooth muscle dysfunction syndrome",
        "item_id": 134
      },
      {
        "item_text": "Baraitser-Winter syndrome 1",
        "item_id": 135
      },
      {
        "item_text": "?Dystonia, juvenile-onset",
        "item_id": 136
      },
      {
        "item_text": "Atrial septal defect 5",
        "item_id": 137
      },
      {
        "item_text": "Cardiomyopathy, dilated, 1R",
        "item_id": 138
      },
      {
        "item_text": "Cardiomyopathy, hypertrophic, 11",
        "item_id": 139
      },
      {
        "item_text": "Left ventricular noncompaction 4",
        "item_id": 140
      },
      {
        "item_text": "Baraitser-Winter syndrome 2",
        "item_id": 141
      },
      {
        "item_text": "Deafness, autosomal dominant 20\/26",
        "item_id": 142
      },
      {
        "item_text": "Visceral myopathy",
        "item_id": 143
      },
      {
        "item_text": "Bleeding disorder, platelet-type, 15",
        "item_id": 144
      },
      {
        "item_text": "Cardiomyopathy, dilated, 1AA, with or without LVNC",
        "item_id": 145
      },
      {
        "item_text": "Cardiomyopathy, hypertrophic, 23, with or without LVNC",
        "item_id": 146
      },
      {
        "item_text": "[Alpha-actinin-3 deficiency] ",
        "item_id": 147
      },
      {
        "item_text": "[Sprinting performance] ",
        "item_id": 148
      },
      {
        "item_text": "Glomerulosclerosis, focal segmental, 1",
        "item_id": 149
      },
      {
        "item_text": "Fibrodysplasia ossificans progressiva",
        "item_id": 150
      },
      {
        "item_text": "Pancreatic cancer, somatic ",
        "item_id": 151
      },
      {
        "item_text": "Heterotaxy, visceral, 4, autosomal",
        "item_id": 152
      },
      {
        "item_text": "Telangiectasia, hereditary hemorrhagic, type 2",
        "item_id": 153
      },
      {
        "item_text": "Aminoacylase 1 deficiency",
        "item_id": 154
      },
      {
        "item_text": "Alzheimer disease-10",
        "item_id": 155
      },
      {
        "item_text": "Alzheimer disease-11",
        "item_id": 156
      },
      {
        "item_text": "{Alzheimer disease 12}",
        "item_id": 157
      },
      {
        "item_text": "{Alzheimer disease-13}",
        "item_id": 158
      },
      {
        "item_text": "{Alzheimer disease-14}",
        "item_id": 159
      },
      {
        "item_text": "{Alzheimer disease-15}",
        "item_id": 160
      },
      {
        "item_text": "{Alzheimer disease 16}",
        "item_id": 161
      },
      {
        "item_text": "Alzheimer disease 17",
        "item_id": 162
      },
      {
        "item_text": "Alzheimer disease-5",
        "item_id": 163
      },
      {
        "item_text": "Alzheimer disease 6",
        "item_id": 164
      },
      {
        "item_text": "Alzheimer disease-7",
        "item_id": 165
      },
      {
        "item_text": "Alzheimer disease 8",
        "item_id": 166
      },
      {
        "item_text": "Adenosine deaminase deficiency, partial",
        "item_id": 167
      },
      {
        "item_text": "Severe combined immunodeficiency due to ADA deficiency",
        "item_id": 168
      },
      {
        "item_text": "Polyarteritis nodosa, childhood-onset",
        "item_id": 169
      },
      {
        "item_text": "?Sneddon syndrome",
        "item_id": 170
      },
      {
        "item_text": "{Alzheimer disease 18, susceptibility to}",
        "item_id": 171
      },
      {
        "item_text": "Reticulate acropigmentation of Kitamura",
        "item_id": 172
      },
      {
        "item_text": "?Inflammatory skin and bowel disease, neonatal, 1",
        "item_id": 173
      },
      {
        "item_text": "Cone-rod dystrophy 9",
        "item_id": 174
      },
      {
        "item_text": "Weill-Marchesani syndrome 1, recessive",
        "item_id": 175
      },
      {
        "item_text": "Thrombotic thrombocytopenic purpura, familial",
        "item_id": 176
      },
      {
        "item_text": "Weill-Marchesani-like syndrome",
        "item_id": 177
      },
      {
        "item_text": "Microcornea, myopic chorioretinal atrophy, and telecanthus",
        "item_id": 178
      },
      {
        "item_text": "Ehlers-Danlos syndrome, type VIIC",
        "item_id": 179
      },
      {
        "item_text": "Geleophysic dysplasia 1",
        "item_id": 180
      },
      {
        "item_text": "Ectopia lentis et pupillae",
        "item_id": 181
      },
      {
        "item_text": "Ectopia lentis, isolated, autosomal recessive",
        "item_id": 182
      },
      {
        "item_text": "Aicardi-Goutieres syndrome 6",
        "item_id": 183
      },
      {
        "item_text": "Dyschromatosis symmetrica hereditaria",
        "item_id": 184
      },
      {
        "item_text": "Mental retardation, autosomal recessive 36",
        "item_id": 185
      },
      {
        "item_text": "?Deafness, autosomal recessive 44",
        "item_id": 186
      },
      {
        "item_text": "{Hypercalciuria, absorptive, susceptibility to}",
        "item_id": 187
      },
      {
        "item_text": "Dyskinesia, familial, with facial myokymia",
        "item_id": 188
      },
      {
        "item_text": "?Lethal congenital contracture syndrome 8",
        "item_id": 189
      },
      {
        "item_text": "{Hypertension, essential, salt-sensitive}",
        "item_id": 190
      },
      {
        "item_text": "Cerebral palsy, spastic quadriplegic, 3",
        "item_id": 191
      },
      {
        "item_text": "Albinism-deafness syndrome",
        "item_id": 192
      },
      {
        "item_text": "Vibratory urticaria",
        "item_id": 193
      },
      {
        "item_text": "Polymicrogyria, bilateral frontoparietal",
        "item_id": 194
      },
      {
        "item_text": "Polymicrogyria, bilateral perisylvian",
        "item_id": 195
      },
      {
        "item_text": "Vas deferens, congenital bilateral aplasia of, X-linked",
        "item_id": 196
      },
      {
        "item_text": "Lethal congenital contracture syndrome 9",
        "item_id": 197
      },
      {
        "item_text": "?Febrile seizures, familial, 4",
        "item_id": 198
      },
      {
        "item_text": "Usher syndrome, type 2C",
        "item_id": 199
      },
      {
        "item_text": "Usher syndrome, type 2C, GPR98\/PDZD7 digenic",
        "item_id": 200
      },
      {
        "item_text": "{Aerodigestive tract cancer, squamous cell, alcohol-related, protection against} ",
        "item_id": 201
      },
      {
        "item_text": "{Alcohol dependence, protection against}",
        "item_id": 202
      },
      {
        "item_text": "{Alcohol dependence, protection against}",
        "item_id": 203
      },
      {
        "item_text": "{Parkinson disease, susceptibility to}",
        "item_id": 204
      },
      {
        "item_text": "{Attention deficit-hyperactivity disorder}",
        "item_id": 205
      },
      {
        "item_text": "{Attention deficit-hyperactivity disorder}",
        "item_id": 206
      },
      {
        "item_text": "{Attention deficit-hyperactivity disorder}",
        "item_id": 207
      },
      {
        "item_text": "{Attention deficit-hyperactivity disorder}",
        "item_id": 208
      },
      {
        "item_text": "{Attention deficit-hyperactivity disorder, susceptibility to, 5}",
        "item_id": 209
      },
      {
        "item_text": "{Attention deficit-hyperactivity disorder, susceptibility to, 6}",
        "item_id": 210
      },
      {
        "item_text": "Adiponectin deficiency",
        "item_id": 211
      },
      {
        "item_text": "{Adiponectin, serum level of, QTL2}",
        "item_id": 212
      },
      {
        "item_text": "{Adiponectin, serum level of, QTL3}",
        "item_id": 213
      },
      {
        "item_text": "{Adiponectin, serum level of, QTL4}",
        "item_id": 214
      },
      {
        "item_text": "{Adiponectin, serum level of, QTL5]",
        "item_id": 215
      },
      {
        "item_text": "Hypermethioninemia due to adenosine kinase deficiency",
        "item_id": 216
      },
      {
        "item_text": "Helsmoortel-van der Aa syndrome",
        "item_id": 217
      },
      {
        "item_text": "Epilepsy, myoclonic, familial adult, 2",
        "item_id": 218
      },
      {
        "item_text": "{Congestive heart failure and beta-blocker response, modifier of} ",
        "item_id": 219
      },
      {
        "item_text": "{Congestive heart failure and beta-blocker response, modifier of} ",
        "item_id": 220
      },
      {
        "item_text": "[Resting heart rate]",
        "item_id": 221
      },
      {
        "item_text": "{Asthma, nocturnal, susceptibility to}",
        "item_id": 222
      },
      {
        "item_text": "Beta-2-adrenoreceptor agonist, reduced response to ",
        "item_id": 223
      },
      {
        "item_text": "{Obesity, susceptibility to}",
        "item_id": 224
      },
      {
        "item_text": "{Obesity, susceptibility to}",
        "item_id": 225
      },
      {
        "item_text": "Adenylosuccinase deficiency",
        "item_id": 226
      },
      {
        "item_text": "Myopathy, distal, 5",
        "item_id": 227
      },
      {
        "item_text": "Mental retardation, X-linked, FRAXE type",
        "item_id": 228
      },
      {
        "item_text": "CHOPS syndrome",
        "item_id": 229
      },
      {
        "item_text": "Spastic ataxia 5, autosomal recessive",
        "item_id": 230
      },
      {
        "item_text": "Spinocerebellar ataxia 28",
        "item_id": 231
      },
      {
        "item_text": "Alpha-fetoprotein deficiency",
        "item_id": 232
      },
      {
        "item_text": "[Hereditary persistence of alpha-fetoprotein]",
        "item_id": 233
      },
      {
        "item_text": "Aspartylglucosaminuria",
        "item_id": 234
      },
      {
        "item_text": "Alopecia, androgenetic, 1",
        "item_id": 235
      },
      {
        "item_text": "Alopecia, androgenetic, 2",
        "item_id": 236
      },
      {
        "item_text": "Alopecia, androgenetic, 3",
        "item_id": 237
      },
      {
        "item_text": "Corneal dystrophy, Fuchs endothelial, 8",
        "item_id": 238
      },
      {
        "item_text": "Retinitis pigmentosa 75",
        "item_id": 239
      },
      {
        "item_text": "Cataract 38, autosomal recessive",
        "item_id": 240
      },
      {
        "item_text": "Sengers syndrome",
        "item_id": 241
      },
      {
        "item_text": "Glycogen storage disease IIIa",
        "item_id": 242
      },
      {
        "item_text": "Glycogen storage disease IIIb",
        "item_id": 243
      },
      {
        "item_text": "Agammaglobulinemia, X-linked 2",
        "item_id": 244
      },
      {
        "item_text": "Lipodystrophy, congenital generalized, type 1",
        "item_id": 245
      },
      {
        "item_text": "Rhizomelic chondrodysplasia punctata, type 3",
        "item_id": 246
      },
      {
        "item_text": "Myasthenic syndrome, congenital, 8, with pre- and postsynaptic defects",
        "item_id": 247
      },
      {
        "item_text": "{Leanness, inherited} ",
        "item_id": 248
      },
      {
        "item_text": "{Obesity, late-onset}",
        "item_id": 249
      },
      {
        "item_text": "Angio serpiginosum",
        "item_id": 250
      },
      {
        "item_text": "{Hypertension, essential, susceptibility to}",
        "item_id": 251
      },
      {
        "item_text": "{Preeclampsia, susceptibility to} ",
        "item_id": 252
      },
      {
        "item_text": "Renal tubular dysgenesis",
        "item_id": 253
      },
      {
        "item_text": "{Hypertension, essential}",
        "item_id": 254
      },
      {
        "item_text": "Renal tubular dysgenesis",
        "item_id": 255
      },
      {
        "item_text": "Hyperoxaluria, primary, type 1",
        "item_id": 256
      },
      {
        "item_text": "[Beta-aminoisobutyric acitem_id, urinary excretion of]",
        "item_id": 257
      },
      {
        "item_text": "Hypermethioninemia with deficiency of S-adenosylhomocysteine hydrolase",
        "item_id": 258
      },
      {
        "item_text": "Xia-Gibbs syndrome",
        "item_id": 259
      },
      {
        "item_text": "Joubert syndrome 3",
        "item_id": 260
      },
      {
        "item_text": "Aicardi syndrome",
        "item_id": 261
      },
      {
        "item_text": "Immunodeficiency with hyper-IgM, type 2",
        "item_id": 262
      },
      {
        "item_text": "Combined oxitem_idative phosphorylation deficiency 6",
        "item_id": 263
      },
      {
        "item_text": "Cowchock syndrome",
        "item_id": 264
      },
      {
        "item_text": "Deafness, X-linked 5",
        "item_id": 265
      },
      {
        "item_text": "?Amelogenesis imperfecta, type IE, X-linked 2",
        "item_id": 266
      },
      {
        "item_text": "Leukodystrophy, hypomyelinating, 3",
        "item_id": 267
      },
      {
        "item_text": "Pituitary adenoma 1, multiple types",
        "item_id": 268
      },
      {
        "item_text": "Pituitary adenoma predisposition",
        "item_id": 269
      },
      {
        "item_text": "Cone-rod dystrophy",
        "item_id": 270
      },
      {
        "item_text": "Leber congenital amaurosis 4",
        "item_id": 271
      },
      {
        "item_text": "Retinitis pigmentosa, juvenile",
        "item_id": 272
      },
      {
        "item_text": "Acute insulin response",
        "item_id": 273
      },
      {
        "item_text": "Autoimmune polyendocrinopathy syndrome , type I, with or without reversible metaphyseal dysplasia",
        "item_id": 274
      },
      {
        "item_text": "{Autoimmune disease, susceptibility to, 2}",
        "item_id": 275
      },
      {
        "item_text": "{Autoimmune disease, susceptibility to, 3}",
        "item_id": 276
      },
      {
        "item_text": "{Autoimmune disease, susceptibility to, 4}",
        "item_id": 277
      },
      {
        "item_text": "{Autoimmune thyroitem_id disease, susceptibility to, 1}",
        "item_id": 278
      },
      {
        "item_text": "{Autoimmune thyroitem_id disease, susceptibility to, 2}",
        "item_id": 279
      },
      {
        "item_text": "{Autoimmune thyroitem_id disease, susceptibility to, 4}",
        "item_id": 280
      },
      {
        "item_text": "Hemolytic anemia due to adenylate kinase deficiency",
        "item_id": 281
      },
      {
        "item_text": "Reticular dysgenesis",
        "item_id": 282
      },
      {
        "item_text": "{Cardiac conduction defect, susceptibility to}",
        "item_id": 283
      },
      {
        "item_text": "?Long QT syndrome-11",
        "item_id": 284
      },
      {
        "item_text": "Obesity, hyperphagia, and developmental delay ",
        "item_id": 285
      },
      {
        "item_text": "46XY sex reversal 8",
        "item_id": 286
      },
      {
        "item_text": "{46XY sex reversal 8, modifier of}",
        "item_id": 287
      },
      {
        "item_text": "Bile acitem_id synthesis defect, congenital, 2",
        "item_id": 288
      },
      {
        "item_text": "Breast cancer, somatic",
        "item_id": 289
      },
      {
        "item_text": "Colorectal cancer, somatic",
        "item_id": 290
      },
      {
        "item_text": "Cowden syndrome 6",
        "item_id": 291
      },
      {
        "item_text": "Ovarian cancer, somatic",
        "item_id": 292
      },
      {
        "item_text": "Proteus syndrome, somatic",
        "item_id": 293
      },
      {
        "item_text": "{Schizophrenia, susceptibility to}",
        "item_id": 294
      },
      {
        "item_text": "Diabetes mellitus, type II",
        "item_id": 295
      },
      {
        "item_text": "Hypoinsulinemic hypoglycemia with hemihypertrophy",
        "item_id": 296
      },
      {
        "item_text": "Megalencephaly-polymicrogyria-polydactyly-hydrocephalus syndrome 2",
        "item_id": 297
      },
      {
        "item_text": "{Lead poisoning, susceptibility to}",
        "item_id": 298
      },
      {
        "item_text": "Porphyria, acute hepatic",
        "item_id": 299
      },
      {
        "item_text": "Anemia, sitem_ideroblastic, 1",
        "item_id": 300
      },
      {
        "item_text": "Protoporphyria, erythropoietic, X-linked",
        "item_id": 301
      },
      {
        "item_text": "Analbuminemia",
        "item_id": 302
      },
      {
        "item_text": "[Dysalbuminemic hyperthyroxinemia]",
        "item_id": 303
      },
      {
        "item_text": "Cutis laxa, autosomal dominant 3",
        "item_id": 304
      },
      {
        "item_text": "Cutis laxa, autosomal recessive, type IIIA",
        "item_id": 305
      },
      {
        "item_text": "Spastic paraplegia 9A, autosomal dominant",
        "item_id": 306
      },
      {
        "item_text": "Spastic paraplegia 9B, autosomal recessive",
        "item_id": 307
      },
      {
        "item_text": "Microphthalmia, isolated 8",
        "item_id": 308
      },
      {
        "item_text": "Alcohol sensitivity, acute",
        "item_id": 309
      },
      {
        "item_text": "{Esophageal cancer, alcohol-related, susceptibility to} ",
        "item_id": 310
      },
      {
        "item_text": "{Hangover, susceptibility to}",
        "item_id": 311
      },
      {
        "item_text": "{Sublingual nitroglycerin, susceptibility to poor response to} ",
        "item_id": 312
      },
      {
        "item_text": "Sjogren-Larsson syndrome",
        "item_id": 313
      },
      {
        "item_text": "Hyperprolinemia, type II",
        "item_id": 314
      },
      {
        "item_text": "Succinic semialdehyde dehydrogenase deficiency",
        "item_id": 315
      },
      {
        "item_text": "Methylmalonate semialdehyde dehydrogenase deficiency",
        "item_id": 316
      },
      {
        "item_text": "Epilepsy, pyritem_idoxine-dependent",
        "item_id": 317
      },
      {
        "item_text": "Glycogen storage disease XII",
        "item_id": 318
      },
      {
        "item_text": "Fructose intolerance, hereditary",
        "item_id": 319
      },
      {
        "item_text": "Congenital disorder of glycosylation, type Ik",
        "item_id": 320
      },
      {
        "item_text": "{Long QT syndrome, acquired, reduced susceptibility to}",
        "item_id": 321
      },
      {
        "item_text": "Congenital disorder of glycosylation, type Ip",
        "item_id": 322
      },
      {
        "item_text": "Congenital disorder of glycosylation, type Ig",
        "item_id": 323
      },
      {
        "item_text": "?Congenital disorder of glycosylation, type Is",
        "item_id": 324
      },
      {
        "item_text": "Epileptic encephalopathy, early infantile, 36",
        "item_id": 325
      },
      {
        "item_text": "?Myasthenic syndrome, congenital, 15, without tubular aggregates",
        "item_id": 326
      },
      {
        "item_text": "?Congenital disorder of glycosylation, type Ii",
        "item_id": 327
      },
      {
        "item_text": "Myasthenic syndrome, congenital, 14, with tubular aggregates",
        "item_id": 328
      },
      {
        "item_text": "Congenital disorder of glycosylation, type item_id",
        "item_id": 329
      },
      {
        "item_text": "Congenital disorder of glycosylation, type Ic",
        "item_id": 330
      },
      {
        "item_text": "Congenital disorder of glycosylation, type Ih",
        "item_id": 331
      },
      {
        "item_text": "Congenital disorder of glycosylation, type Il",
        "item_id": 332
      },
      {
        "item_text": "Gillessen-Kaesbach-Nishimura syndrome",
        "item_id": 333
      },
      {
        "item_text": "{Neuroblastoma, susceptibility to, 3}",
        "item_id": 334
      },
      {
        "item_text": "{Leukemia, acute lymphocytic, susceptibility to, 1}",
        "item_id": 335
      },
      {
        "item_text": "{Leukemia, acute lymphoblastic, susceptibility to, 2}",
        "item_id": 336
      },
      {
        "item_text": "Alstrom syndrome",
        "item_id": 337
      },
      {
        "item_text": "Ichthyosis, congenital, autosomal recessive 2",
        "item_id": 338
      },
      {
        "item_text": "{Asthma, diminished response to antileukotriene treatment in}",
        "item_id": 339
      },
      {
        "item_text": "{Atherosclerosis, susceptibility to} ",
        "item_id": 340
      },
      {
        "item_text": "{Stroke, susceptibility to}",
        "item_id": 341
      },
      {
        "item_text": "Ichthyosis, congenital, autosomal recessive 3",
        "item_id": 342
      },
      {
        "item_text": "Hypophosphatasia, adult",
        "item_id": 343
      },
      {
        "item_text": "Hypophosphatasia, childhood",
        "item_id": 344
      },
      {
        "item_text": "Hypophosphatasia, infantile",
        "item_id": 345
      },
      {
        "item_text": "Odontohypophosphatasia",
        "item_id": 346
      },
      {
        "item_text": "{Alkaline phosphatase, plasma level of, QTL1}",
        "item_id": 347
      },
      {
        "item_text": "{Alkaline phosphatase, plasma level of, QTL 2}",
        "item_id": 348
      },
      {
        "item_text": "{Alkaline phosphatase, plasma level of, QTL3}",
        "item_id": 349
      },
      {
        "item_text": "{Alkaline phosphatase, plasma level of, QTL4}",
        "item_id": 350
      },
      {
        "item_text": "Amyotrophic lateral sclerosis 2, juvenile",
        "item_id": 351
      },
      {
        "item_text": "Primary lateral sclerosis, juvenile",
        "item_id": 352
      },
      {
        "item_text": "Spastic paralysis, infantile onset ascending",
        "item_id": 353
      },
      {
        "item_text": "Amyotrophic lateral sclerosis 3",
        "item_id": 354
      },
      {
        "item_text": "Amyotrophic lateral sclerosis 7",
        "item_id": 355
      },
      {
        "item_text": "?Frontonasal dysplasia 3",
        "item_id": 356
      },
      {
        "item_text": "Frontonasal dysplasia 1",
        "item_id": 357
      },
      {
        "item_text": "{Craniosynostosis 5, susceptibility to}",
        "item_id": 358
      },
      {
        "item_text": "Frontonasal dysplasia 2",
        "item_id": 359
      },
      {
        "item_text": "Parietal foramina 2",
        "item_id": 360
      },
      {
        "item_text": "Alpha-methylacyl-CoA racemase deficiency",
        "item_id": 361
      },
      {
        "item_text": "Bile acitem_id synthesis defect, congenital, 4",
        "item_id": 362
      },
      {
        "item_text": "Amelogenesis imperfecta, type IF",
        "item_id": 363
      },
      {
        "item_text": "Arthrogryposis multiplex congenita, neurogenic",
        "item_id": 364
      },
      {
        "item_text": "Amelogenesis imperfecta, type 1E",
        "item_id": 365
      },
      {
        "item_text": "Osteopathia striata with cranial sclerosis",
        "item_id": 366
      },
      {
        "item_text": "Persistent Mullerian duct syndrome, type I",
        "item_id": 367
      },
      {
        "item_text": "Persistent Mullerian duct syndrome, type II",
        "item_id": 368
      },
      {
        "item_text": "Alport syndrome, mental retardation, mitem_idface hypoplasia, and elliptocytosis",
        "item_id": 369
      },
      {
        "item_text": "Mitem_idface hypoplasia, hearing impairment, elliptocytosis, and nephrocalcinosis",
        "item_id": 370
      },
      {
        "item_text": "Megaloblastic anemia-1, Norwegian type",
        "item_id": 371
      },
      {
        "item_text": "Myopathy due to myoadenylate deaminase deficiency",
        "item_id": 372
      },
      {
        "item_text": "Pontocerebellar hypoplasia, type 9",
        "item_id": 373
      },
      {
        "item_text": "?Spastic paraplegia 63",
        "item_id": 374
      },
      {
        "item_text": "[AMP deaminase deficiency, erythrocytic]",
        "item_id": 375
      },
      {
        "item_text": "Glycine encephalopathy",
        "item_id": 376
      },
      {
        "item_text": "?Amelogenesis imperfecta, type IIIB",
        "item_id": 377
      },
      {
        "item_text": "Aneurysmal bone cysts",
        "item_id": 378
      },
      {
        "item_text": "?Anal canal carcinoma",
        "item_id": 379
      },
      {
        "item_text": "Amyotrophic lateral sclerosis 9",
        "item_id": 380
      },
      {
        "item_text": "Hypobetalipoproteinemia, familial, 2",
        "item_id": 381
      },
      {
        "item_text": "Plasma triglyceritem_ide level QTL, low",
        "item_id": 382
      },
      {
        "item_text": "Aneurysm, intracranial berry, 1",
        "item_id": 383
      },
      {
        "item_text": "{Aneurysm, intracranial berry, 10}",
        "item_id": 384
      },
      {
        "item_text": "Aneurysm, intracranial berry, 11",
        "item_id": 385
      },
      {
        "item_text": "Aneurysm, intracranial berry, 2",
        "item_id": 386
      },
      {
        "item_text": "Aneurysm, intracranial berry, 3",
        "item_id": 387
      },
      {
        "item_text": "Aneurysm, intracranial berry, 4",
        "item_id": 388
      },
      {
        "item_text": "Aneurysm, intracranial berry, 5",
        "item_id": 389
      },
      {
        "item_text": "{Aneurysm, intracranial berry, 6}",
        "item_id": 390
      },
      {
        "item_text": "Aneurysm, intracranial berry, 7",
        "item_id": 391
      },
      {
        "item_text": "Aneurysm, intracranial berry, 8",
        "item_id": 392
      },
      {
        "item_text": "{Aneurysm, intracranial berry, 9}",
        "item_id": 393
      },
      {
        "item_text": "Anosmia, isolated congenital",
        "item_id": 394
      },
      {
        "item_text": "Spherocytosis, type 1",
        "item_id": 395
      },
      {
        "item_text": "Cardiac arrhythmia, ankyrin-B-related",
        "item_id": 396
      },
      {
        "item_text": "Long QT syndrome 4",
        "item_id": 397
      },
      {
        "item_text": "?Mental retardation, autosomal recessive, 37",
        "item_id": 398
      },
      {
        "item_text": "Chondrocalcinosis 2",
        "item_id": 399
      },
      {
        "item_text": "Craniometaphyseal dysplasia",
        "item_id": 400
      },
      {
        "item_text": "Dopamine receptor D2, reduced brain density of ",
        "item_id": 401
      },
      {
        "item_text": "?Microcephaly 16, primary, autosomal recessive",
        "item_id": 402
      },
      {
        "item_text": "KBG syndrome",
        "item_id": 403
      },
      {
        "item_text": "Thrombocytopenia 2",
        "item_id": 404
      },
      {
        "item_text": "Nephronophthisis 16",
        "item_id": 405
      },
      {
        "item_text": "Focal segmental glomerulosclerosis 8",
        "item_id": 406
      },
      {
        "item_text": "Anisomastia",
        "item_id": 407
      },
      {
        "item_text": "Spinocerebellar ataxia, autosomal recessive 10",
        "item_id": 408
      },
      {
        "item_text": "Dystonia 24",
        "item_id": 409
      },
      {
        "item_text": "Gnathodiaphyseal dysplasia",
        "item_id": 410
      },
      {
        "item_text": "Miyoshi muscular dystrophy 3",
        "item_id": 411
      },
      {
        "item_text": "Muscular dystrophy, limb-girdle, type 2L",
        "item_id": 412
      },
      {
        "item_text": "Scott syndrome",
        "item_id": 413
      },
      {
        "item_text": "{Anorexia nervosa, susceptibility to, 1}",
        "item_id": 414
      },
      {
        "item_text": "?Microphthalmia, syndromic 4",
        "item_id": 415
      },
      {
        "item_text": "Hypogonadotropic hypogonadism 1 with or without anosmia (Kallmann syndrome 1)",
        "item_id": 416
      },
      {
        "item_text": "GAPO syndrome",
        "item_id": 417
      },
      {
        "item_text": "{?Hemangioma, capillary infantile, susceptibility to}",
        "item_id": 418
      },
      {
        "item_text": "Hyaline fibromatosis syndrome",
        "item_id": 419
      },
      {
        "item_text": "{Pregnancy loss, recurrent, susceptibility to, 3}",
        "item_id": 420
      },
      {
        "item_text": "Acromegaloitem_id features, overgrowth, cleft palate, and hernia",
        "item_id": 421
      },
      {
        "item_text": "Abdominal obesity-metabolic syndrome 1",
        "item_id": 422
      },
      {
        "item_text": "Abdominal obesity-metabolic syndrome",
        "item_id": 423
      },
      {
        "item_text": "MEDNIK syndrome",
        "item_id": 424
      },
      {
        "item_text": "Mental retardation, X-linked syndromic 5",
        "item_id": 425
      },
      {
        "item_text": "{Psoriasis 15, pustular, susceptibility to}",
        "item_id": 426
      },
      {
        "item_text": "Hypocalciuric hypercalcemia, type III",
        "item_id": 427
      },
      {
        "item_text": "Hermansky-Pudlak syndrome 2",
        "item_id": 428
      },
      {
        "item_text": "Epileptic encephalopathy, early infantile, 48",
        "item_id": 429
      },
      {
        "item_text": "?Hermansky-Pudlak syndrome 10",
        "item_id": 430
      },
      {
        "item_text": "Spastic paraplegia 47, autosomal recessive",
        "item_id": 431
      },
      {
        "item_text": "Spastic paraplegia 51, autosomal recessive",
        "item_id": 432
      },
      {
        "item_text": "Stuttering, familial persistent, 1",
        "item_id": 433
      },
      {
        "item_text": "Spastic paraplegia 50, autosomal recessive",
        "item_id": 434
      },
      {
        "item_text": "Spastic paraplegia 52, autosomal recessive",
        "item_id": 435
      },
      {
        "item_text": "Spastic paraplegia 48, autosomal recessive",
        "item_id": 436
      },
      {
        "item_text": "Adenoma, periampullary, somatic ",
        "item_id": 437
      },
      {
        "item_text": "Adenomatous polyposis coli",
        "item_id": 438
      },
      {
        "item_text": "Brain tumor-polyposis syndrome 2",
        "item_id": 439
      },
      {
        "item_text": "Colorectal cancer, somatic",
        "item_id": 440
      },
      {
        "item_text": "Desmoitem_id disease, hereditary",
        "item_id": 441
      },
      {
        "item_text": "Gardner syndrome",
        "item_id": 442
      },
      {
        "item_text": "Gastric cancer, somatic",
        "item_id": 443
      },
      {
        "item_text": "Hepatoblastoma, somatic",
        "item_id": 444
      },
      {
        "item_text": "?Sotos syndrome 3",
        "item_id": 445
      },
      {
        "item_text": "Hypotrichosis 1",
        "item_id": 446
      },
      {
        "item_text": "{?Amyloitem_idosis, secondary, susceptibility to} ",
        "item_id": 447
      },
      {
        "item_text": "Alopecia-mental retardation syndrome 1",
        "item_id": 448
      },
      {
        "item_text": "Alopecia-mental retardation syndrome 2",
        "item_id": 449
      },
      {
        "item_text": "Alopecia-mental retardation syndrome 3",
        "item_id": 450
      },
      {
        "item_text": "Amyloitem_idosis, 3 or more types",
        "item_id": 451
      },
      {
        "item_text": "ApoA-I and apoC-III deficiency, combined ",
        "item_id": 452
      },
      {
        "item_text": "Corneal clouding, autosomal recessive ",
        "item_id": 453
      },
      {
        "item_text": "Hypoalphalipoproteinemia",
        "item_id": 454
      },
      {
        "item_text": "Apolipoprotein A-II deficiency ",
        "item_id": 455
      },
      {
        "item_text": "{Hypercholesterolemia, familial, modifier of}",
        "item_id": 456
      },
      {
        "item_text": "Hyperchylomicronemia, late-onset",
        "item_id": 457
      },
      {
        "item_text": "{Hypertriglyceritem_idemia, susceptibility to}",
        "item_id": 458
      },
      {
        "item_text": "Hypercholesterolemia, due to ligand-defective apo B",
        "item_id": 459
      },
      {
        "item_text": "Hypobetalipoproteinemia",
        "item_id": 460
      },
      {
        "item_text": "Hyperlipoproteinemia, type Ib",
        "item_id": 461
      },
      {
        "item_text": "Apolipoprotein C-III deficiency",
        "item_id": 462
      },
      {
        "item_text": "Alzheimer disease-2",
        "item_id": 463
      },
      {
        "item_text": "{Coronary artery disease, severe, susceptibility to}",
        "item_id": 464
      },
      {
        "item_text": "Hyperlipoproteinemia, type III",
        "item_id": 465
      },
      {
        "item_text": "Lipoprotein glomerulopathy",
        "item_id": 466
      },
      {
        "item_text": "{?Macular degeneration, age-related}",
        "item_id": 467
      },
      {
        "item_text": "Sea-blue histiocyte disease",
        "item_id": 468
      },
      {
        "item_text": "{End-stage renal disease, nondiabetic, susceptibility to}",
        "item_id": 469
      },
      {
        "item_text": "{Glomerulosclerosis, focal segmental, 4, susceptibility to}",
        "item_id": 470
      },
      {
        "item_text": "{Schizophrenia}",
        "item_id": 471
      },
      {
        "item_text": "{Schizophrenia}",
        "item_id": 472
      },
      {
        "item_text": "Mitochondrial complex IV deficiency",
        "item_id": 473
      },
      {
        "item_text": "Alzheimer disease 1, familial",
        "item_id": 474
      },
      {
        "item_text": "Cerebral amyloitem_id angiopathy, Dutch, Italian, Iowa, Flemish, Arctic variants",
        "item_id": 475
      },
      {
        "item_text": "{Maturity-onset diabetes of the young, type 14}",
        "item_id": 476
      },
      {
        "item_text": "Adenine phosphoribosyltransferase deficiency",
        "item_id": 477
      },
      {
        "item_text": "Ataxia, early-onset, with oculomotor apraxia and hypoalbuminemia",
        "item_id": 478
      },
      {
        "item_text": "[Aquaporin-1 deficiency] ",
        "item_id": 479
      },
      {
        "item_text": "[Blood group, Colton]",
        "item_id": 480
      },
      {
        "item_text": "Diabetes insipitem_idus, nephrogenic",
        "item_id": 481
      },
      {
        "item_text": "[Blood group GIL]",
        "item_id": 482
      },
      {
        "item_text": "Palmoplantar keratoderma, Bothnian type",
        "item_id": 483
      },
      {
        "item_text": "[Glycerol quantitative trait locus]",
        "item_id": 484
      },
      {
        "item_text": "Androgen insensitivity",
        "item_id": 485
      },
      {
        "item_text": "Androgen insensitivity, partial, with or without breast cancer",
        "item_id": 486
      },
      {
        "item_text": "{Prostate cancer, susceptibility to}",
        "item_id": 487
      },
      {
        "item_text": "Spinal and bulbar muscular atrophy of Kennedy",
        "item_id": 488
      },
      {
        "item_text": "Ichthyosis, congenital, autosomal recessive 7",
        "item_id": 489
      },
      {
        "item_text": "Short stature, rhizomelic, with microcephaly, micrognathia, and developmental delay",
        "item_id": 490
      },
      {
        "item_text": "Periventricular heterotopia with microcephaly",
        "item_id": 491
      },
      {
        "item_text": "Argininemia",
        "item_id": 492
      },
      {
        "item_text": "Leukemia, juvenile myelomonocytic, somatic",
        "item_id": 493
      },
      {
        "item_text": "Adams-Oliver syndrome 1",
        "item_id": 494
      },
      {
        "item_text": "Nephrotic syndrome, type 8",
        "item_id": 495
      },
      {
        "item_text": "?Slowed nerve conduction velocity, AD",
        "item_id": 496
      },
      {
        "item_text": "Retinitis pigmentosa 78",
        "item_id": 497
      },
      {
        "item_text": "?Neurodevelopmental disorder with mitem_idbrain and hindbrain malformations",
        "item_id": 498
      },
      {
        "item_text": "Mental retardation, X-linked 46",
        "item_id": 499
      },
      {
        "item_text": "Epileptic encephalopathy, early infantile, 8",
        "item_id": 500
      },
      {
        "item_text": "{Age-related hearing impairment 1}",
        "item_id": 501
      },
      {
        "item_text": "{Age-related hearing impairment 2}",
        "item_id": 502
      },
      {
        "item_text": "Coffin-Siris syndrome 2",
        "item_id": 503
      },
      {
        "item_text": "Coffin-Siris syndrome 1",
        "item_id": 504
      },
      {
        "item_text": "Joubert syndrome 8",
        "item_id": 505
      },
      {
        "item_text": "Retinitis pigmentosa with or without situs inversus",
        "item_id": 506
      },
      {
        "item_text": "{Bardet-Biedl syndrome 1, modifier of}",
        "item_id": 507
      },
      {
        "item_text": "Bardet-Biedl syndrome 3",
        "item_id": 508
      },
      {
        "item_text": "?Retinitis pigmentosa 55",
        "item_id": 509
      },
      {
        "item_text": "?Spastic paraplegia 61, autosomal recessive",
        "item_id": 510
      },
      {
        "item_text": "Ciliary dyskinesia, primary, 23",
        "item_id": 511
      },
      {
        "item_text": "ACTH-independent macronodular adrenal hyperplasia 2",
        "item_id": 512
      },
      {
        "item_text": "Joubert syndrome 30",
        "item_id": 513
      },
      {
        "item_text": "Macular degeneration, age-related, 10",
        "item_id": 514
      },
      {
        "item_text": "{Macular degeneration, age-related, 8}",
        "item_id": 515
      },
      {
        "item_text": "?Webb-Dattani syndrome",
        "item_id": 516
      },
      {
        "item_text": "Platelet abnormalities with eosinophilia and immune-mediated inflammatory disease",
        "item_id": 517
      },
      {
        "item_text": "Metachromatic leukodystrophy",
        "item_id": 518
      },
      {
        "item_text": "Mucopolysaccharitem_idosis type VI (Maroteaux-Lamy)",
        "item_id": 519
      },
      {
        "item_text": "Chondrodysplasia punctata, X-linked recessive",
        "item_id": 520
      },
      {
        "item_text": "[Blood group, Dombrock]",
        "item_id": 521
      },
      {
        "item_text": "Epileptic encephalopathy, early infantile, 38",
        "item_id": 522
      },
      {
        "item_text": "Arrhythmogenic right ventricular dysplasia 3",
        "item_id": 523
      },
      {
        "item_text": "Arrhythmogenic right ventricular dysplasia 4",
        "item_id": 524
      },
      {
        "item_text": "Arrhythmogenic right ventricular dysplasia 6",
        "item_id": 525
      },
      {
        "item_text": "Epileptic encephalopathy, early infantile, 1",
        "item_id": 526
      },
      {
        "item_text": "Hydranencephaly with abnormal genitalia",
        "item_id": 527
      },
      {
        "item_text": "Lissencephaly, X-linked 2",
        "item_id": 528
      },
      {
        "item_text": "Mental retardation, X-linked 29 and others",
        "item_id": 529
      },
      {
        "item_text": "Partington syndrome",
        "item_id": 530
      },
      {
        "item_text": "Proud syndrome",
        "item_id": 531
      },
      {
        "item_text": "Farber lipogranulomatosis",
        "item_id": 532
      },
      {
        "item_text": "Spinal muscular atrophy with progressive myoclonic epilepsy",
        "item_id": 533
      },
      {
        "item_text": "Glaucoma 1, open angle, F",
        "item_id": 534
      },
      {
        "item_text": "Barrett esophagus\/esophageal adenocarcinoma",
        "item_id": 535
      },
      {
        "item_text": "?Spinal muscular atrophy with congenital bone fractures 2",
        "item_id": 536
      },
      {
        "item_text": "Central hypoventilation syndrome, congenital",
        "item_id": 537
      },
      {
        "item_text": "Haddad syndrome",
        "item_id": 538
      },
      {
        "item_text": "Atrial septal defect 1",
        "item_id": 539
      },
      {
        "item_text": "[Skin\/hair\/eye pigmentation 9, brown\/nonbrown eyes]",
        "item_id": 540
      },
      {
        "item_text": "[Skin\/hair\/eye pigmentation 9, dark\/light hair]",
        "item_id": 541
      },
      {
        "item_text": "Argininosuccinic acitem_iduria",
        "item_id": 542
      },
      {
        "item_text": "Asparagine synthetase deficiency",
        "item_id": 543
      },
      {
        "item_text": "Canavan disease",
        "item_id": 544
      },
      {
        "item_text": "{Asperger syndrome susceptibility 1}",
        "item_id": 545
      },
      {
        "item_text": "{Asperger syndrome susceptibility 2}",
        "item_id": 546
      },
      {
        "item_text": "{Asperger syndrome susceptibility 3}",
        "item_id": 547
      },
      {
        "item_text": "{Asperger syndrome susceptibility 4}",
        "item_id": 548
      },
      {
        "item_text": "Traboulsi syndrome",
        "item_id": 549
      },
      {
        "item_text": "Microcephaly 5, primary, autosomal recessive",
        "item_id": 550
      },
      {
        "item_text": "{Lumbar disc degeneration}",
        "item_id": 551
      },
      {
        "item_text": "{Osteoarthritis susceptibility 3}",
        "item_id": 552
      },
      {
        "item_text": "Alveolar soft-part sarcoma",
        "item_id": 553
      },
      {
        "item_text": "{Asthma-related traits, susceptibility to, 3}",
        "item_id": 554
      },
      {
        "item_text": "{Asthma-related traits, susceptibility to, 4}",
        "item_id": 555
      },
      {
        "item_text": "{Asthma-related traits, susceptibility to, 6}",
        "item_id": 556
      },
      {
        "item_text": "{Asthma-related traits, susceptibility to, 8}",
        "item_id": 557
      },
      {
        "item_text": "Citrullinemia",
        "item_id": 558
      },
      {
        "item_text": "Bohring-Opitz syndrome",
        "item_id": 559
      },
      {
        "item_text": "Myelodysplastic syndrome, somatic",
        "item_id": 560
      },
      {
        "item_text": "Shashi-Pena syndrome",
        "item_id": 561
      },
      {
        "item_text": "Bainbritem_idge-Ropers syndrome",
        "item_id": 562
      },
      {
        "item_text": "Harel-Yoon syndrome",
        "item_id": 563
      },
      {
        "item_text": "Ataxia, cerebellar, Cayman type",
        "item_id": 564
      },
      {
        "item_text": "Short-rib thoracic dysplasia 1 with or without polydactyly",
        "item_id": 565
      },
      {
        "item_text": "Achromatopsia 7",
        "item_id": 566
      },
      {
        "item_text": "Atrial fibrillation, familial, 1",
        "item_id": 567
      },
      {
        "item_text": "Atrial fibrillation, familial, 2",
        "item_id": 568
      },
      {
        "item_text": "{Atrial fibrillation, familial, 5}",
        "item_id": 569
      },
      {
        "item_text": "Atrial fibrillation, familial, 8",
        "item_id": 570
      },
      {
        "item_text": "{Inflammatory bowel disease (Crohn disease) 10}",
        "item_id": 571
      },
      {
        "item_text": "?Spinocerebellar ataxia, autosomal recessive 25",
        "item_id": 572
      },
      {
        "item_text": "{Atherosclerosis, susceptibility to}",
        "item_id": 573
      },
      {
        "item_text": "AICA-ribositem_iduria due to ATIC deficiency",
        "item_id": 574
      },
      {
        "item_text": "Neuropathy, hereditary sensory, type item_id",
        "item_id": 575
      },
      {
        "item_text": "Spastic paraplegia 3A, autosomal dominant",
        "item_id": 576
      },
      {
        "item_text": "Neuropathy, hereditary sensory, type IF",
        "item_id": 577
      },
      {
        "item_text": "Ataxia-telangiectasia",
        "item_id": 578
      },
      {
        "item_text": "{Breast cancer, susceptibility to}",
        "item_id": 579
      },
      {
        "item_text": "Lymphoma, mantle cell, somatic ",
        "item_id": 580
      },
      {
        "item_text": "T-cell prolymphocytic leukemia, somatic ",
        "item_id": 581
      },
      {
        "item_text": "Dentatorubro-pallitem_idoluysian atrophy",
        "item_id": 582
      },
      {
        "item_text": "{Dermatitis, atopic, susceptibility to, 1}",
        "item_id": 583
      },
      {
        "item_text": "{Dermatitis, atopic, susceptibility to, 3}",
        "item_id": 584
      },
      {
        "item_text": "{Dermatitis, atopic, susceptibility to, 4}",
        "item_id": 585
      },
      {
        "item_text": "{Dermatitis, atopic, susceptibility to, 5}",
        "item_id": 586
      },
      {
        "item_text": "{Dermatitis, atopic, susceptibility to, 6}",
        "item_id": 587
      },
      {
        "item_text": "{Dermatitis, atopic, susceptibility to, 7}",
        "item_id": 588
      },
      {
        "item_text": "{Dermatitis, atopic, susceptibility to, 8}",
        "item_id": 589
      },
      {
        "item_text": "{Dermatitis, atopic, susceptibility to, 9}",
        "item_id": 590
      },
      {
        "item_text": "Persistent hyperplastic primary vitreous, autosomal recessive",
        "item_id": 591
      },
      {
        "item_text": "Kufor-Rakeb syndrome",
        "item_id": 592
      },
      {
        "item_text": "Spastic paraplegia 78, autosomal recessive",
        "item_id": 593
      },
      {
        "item_text": "Alternating hemiplegia of childhood",
        "item_id": 594
      },
      {
        "item_text": "Migraine, familial basilar",
        "item_id": 595
      },
      {
        "item_text": "Migraine, familial hemiplegic, 2",
        "item_id": 596
      },
      {
        "item_text": "Alternating hemiplegia of childhood 2",
        "item_id": 597
      },
      {
        "item_text": "CAPOS syndrome",
        "item_id": 598
      },
      {
        "item_text": "Dystonia-12",
        "item_id": 599
      },
      {
        "item_text": "[Blood pressure regulation QTL]",
        "item_id": 600
      },
      {
        "item_text": "Brody myopathy",
        "item_id": 601
      },
      {
        "item_text": "Acrokeratosis verruciformis",
        "item_id": 602
      },
      {
        "item_text": "Darier disease",
        "item_id": 603
      },
      {
        "item_text": "{Deafness, autosomal recessive 12, modifier of}",
        "item_id": 604
      },
      {
        "item_text": "?Spinocerebellar ataxia, X-linked 1",
        "item_id": 605
      },
      {
        "item_text": "Hailey-Hailey disease",
        "item_id": 606
      },
      {
        "item_text": "?Combined oxitem_idative phosphorylation deficiency 22",
        "item_id": 607
      },
      {
        "item_text": "?Mitochondrial complex (ATP synthase) deficiency, nuclear type 4",
        "item_id": 608
      },
      {
        "item_text": "?Mitochondrial complex V (ATP synthase) deficiency, nuclear type 3",
        "item_id": 609
      },
      {
        "item_text": "Immunodeficiency 47",
        "item_id": 610
      },
      {
        "item_text": "Mental retardation, X-linked, syndromic, Hedera type",
        "item_id": 611
      },
      {
        "item_text": "?Parkinsonism with spasticity, X-linked",
        "item_id": 612
      },
      {
        "item_text": "Cutis laxa, autosomal recessive, type IIA",
        "item_id": 613
      },
      {
        "item_text": "Wrinkly skin syndrome",
        "item_id": 614
      },
      {
        "item_text": "Renal tubular acitem_idosis, distal, autosomal recessive",
        "item_id": 615
      },
      {
        "item_text": "Cutis laxa, autosomal recessive, type Iitem_id",
        "item_id": 616
      },
      {
        "item_text": "Renal tubular acitem_idosis with deafness",
        "item_id": 617
      },
      {
        "item_text": "Deafness, congenital, with onychodystrophy, autosomal dominant",
        "item_id": 618
      },
      {
        "item_text": "Zimmermann-Laband syndrome 2",
        "item_id": 619
      },
      {
        "item_text": "Cutis laxa, autosomal recessive, type IIC",
        "item_id": 620
      },
      {
        "item_text": "Menkes disease",
        "item_id": 621
      },
      {
        "item_text": "Occipital horn syndrome",
        "item_id": 622
      },
      {
        "item_text": "Spinal muscular atrophy, distal, X-linked 3",
        "item_id": 623
      },
      {
        "item_text": "Wilson disease",
        "item_id": 624
      },
      {
        "item_text": "?Cerebellar ataxia, mental retardation, and dysequilibrium syndrome 4",
        "item_id": 625
      },
      {
        "item_text": "Cholestasis, benign recurrent intrahepatic",
        "item_id": 626
      },
      {
        "item_text": "Cholestasis, intrahepatic, of pregnancy, 1",
        "item_id": 627
      },
      {
        "item_text": "Cholestasis, progressive familial intrahepatic 1",
        "item_id": 628
      },
      {
        "item_text": "?Mitochondrial complex V (ATP synthase) deficiency, nuclear type 1",
        "item_id": 629
      },
      {
        "item_text": "?Antiphospholipitem_id syndrome, familial",
        "item_id": 630
      },
      {
        "item_text": "?Cutaneous telangiectasia and cancer syndrome, familial",
        "item_id": 631
      },
      {
        "item_text": "Seckel syndrome 1",
        "item_id": 632
      },
      {
        "item_text": "Mental retardation, X-linked 52",
        "item_id": 633
      },
      {
        "item_text": "Alpha-thalassemia myelodysplasia syndrome, somatic",
        "item_id": 634
      },
      {
        "item_text": "Alpha-thalassemia\/mental retardation syndrome",
        "item_id": 635
      },
      {
        "item_text": "Mental retardation-hypotonic facies syndrome, X-linked",
        "item_id": 636
      },
      {
        "item_text": "Spinocerebellar ataxia 1",
        "item_id": 637
      },
      {
        "item_text": "Spinocerebellar ataxia 10",
        "item_id": 638
      },
      {
        "item_text": "{Amyotrophic lateral sclerosis, susceptibility to, 13}",
        "item_id": 639
      },
      {
        "item_text": "{Parkinson disease, late-onset, susceptibility to}",
        "item_id": 640
      },
      {
        "item_text": "Spinocerebellar ataxia 2",
        "item_id": 641
      },
      {
        "item_text": "Machado-Joseph disease",
        "item_id": 642
      },
      {
        "item_text": "Spinocerebellar ataxia 7",
        "item_id": 643
      },
      {
        "item_text": "Spinocerebellar ataxia 8",
        "item_id": 644
      },
      {
        "item_text": "Spinocerebellar ataxia 8",
        "item_id": 645
      },
      {
        "item_text": "3-methylglutaconic acitem_iduria, type I",
        "item_id": 646
      },
      {
        "item_text": "{Colon cancer, susceptibility to}",
        "item_id": 647
      },
      {
        "item_text": "Spermatogenic failure 5",
        "item_id": 648
      },
      {
        "item_text": "{Autism susceptibility 1}",
        "item_id": 649
      },
      {
        "item_text": "{Autism, susceptibility to, 10}",
        "item_id": 650
      },
      {
        "item_text": "{Autism susceptibility 11}",
        "item_id": 651
      },
      {
        "item_text": "{Autism susceptibility 12}",
        "item_id": 652
      },
      {
        "item_text": "{Autism susceptibility 13}",
        "item_id": 653
      },
      {
        "item_text": "Mental retardation, autosomal dominant 26",
        "item_id": 654
      },
      {
        "item_text": "{Autism susceptibility 3}",
        "item_id": 655
      },
      {
        "item_text": "{Autism susceptibility 4}",
        "item_id": 656
      },
      {
        "item_text": "{Autism susceptibility 5}",
        "item_id": 657
      },
      {
        "item_text": "{Autism susceptibility 6}",
        "item_id": 658
      },
      {
        "item_text": "{Autism susceptibility 7}",
        "item_id": 659
      },
      {
        "item_text": "{Autism susceptibility 8}",
        "item_id": 660
      },
      {
        "item_text": "{Autism, susceptibility to, 9}",
        "item_id": 661
      },
      {
        "item_text": "Diabetes insipitem_idus, neurohypophyseal",
        "item_id": 662
      },
      {
        "item_text": "Diabetes insipitem_idus, nephrogenic",
        "item_id": 663
      },
      {
        "item_text": "Nephrogenic syndrome of inappropriate antitem_idiuresis",
        "item_id": 664
      },
      {
        "item_text": "{Atrioventricular septal defect, susceptibility to, 1}",
        "item_id": 665
      },
      {
        "item_text": "?Caudal duplication anomaly",
        "item_id": 666
      },
      {
        "item_text": "Hepatocellular carcinoma, somatic",
        "item_id": 667
      },
      {
        "item_text": "Colorectal cancer, somatic",
        "item_id": 668
      },
      {
        "item_text": "Oligodontia-colorectal cancer syndrome",
        "item_id": 669
      },
      {
        "item_text": "?Amyloitem_idosis, familial visceral",
        "item_id": 670
      },
      {
        "item_text": "Immunodeficiency 43",
        "item_id": 671
      },
      {
        "item_text": "[Blood group, P1PK system, P(k) phenotype]",
        "item_id": 672
      },
      {
        "item_text": "[Blood group, globositem_ide system]",
        "item_id": 673
      },
      {
        "item_text": "Muscular dystrophy-dystroglycanopathy (congenital with brain and eye anomalies, type A, 11",
        "item_id": 674
      },
      {
        "item_text": "Ehlers-Danlos syndrome, progeroitem_id type, 2",
        "item_id": 675
      },
      {
        "item_text": "Spondyloepimetaphyseal dysplasia with joint laxity, type 1, with or without fractures",
        "item_id": 676
      },
      {
        "item_text": "Multiple joint dislocations, short stature, craniofacial dysmorphism, with or without congenital heart defects",
        "item_id": 677
      },
      {
        "item_text": "Peters-plus syndrome",
        "item_id": 678
      },
      {
        "item_text": "Spastic paraplegia 26, autosomal recessive",
        "item_id": 679
      },
      {
        "item_text": "Congenital disorder of glycosylation, type Iitem_id",
        "item_id": 680
      },
      {
        "item_text": "Ehlers-Danlos syndrome with short stature and limb anomalies",
        "item_id": 681
      },
      {
        "item_text": "Muscular dystrophy-dystroglycanopathy (congenital with brain and eye anomalies), type A, 13",
        "item_id": 682
      },
      {
        "item_text": "{Vitamin B6 plasma level QTL 1}",
        "item_id": 683
      },
      {
        "item_text": "Joubert syndrome 27",
        "item_id": 684
      },
      {
        "item_text": "?Meckel syndrome 9",
        "item_id": 685
      },
      {
        "item_text": "Meckel syndrome 10",
        "item_id": 686
      },
      {
        "item_text": "Hypercholanemia, familial",
        "item_id": 687
      },
      {
        "item_text": "Cardiomyopathy, dilated, 1HH",
        "item_id": 688
      },
      {
        "item_text": "Myopathy, myofibrillar, 6",
        "item_id": 689
      },
      {
        "item_text": "Nestor-Guillermo progeria syndrome",
        "item_id": 690
      },
      {
        "item_text": "Tumor predisposition syndrome",
        "item_id": 691
      },
      {
        "item_text": "{Breast cancer, susceptibility to}",
        "item_id": 692
      },
      {
        "item_text": "Colorectal cancer, somatic",
        "item_id": 693
      },
      {
        "item_text": "T-cell acute lymphoblastic leukemia, somatic",
        "item_id": 694
      },
      {
        "item_text": "?Bardet-Biedl syndrome 18",
        "item_id": 695
      },
      {
        "item_text": "Bardet-Biedl syndrome 1",
        "item_id": 696
      },
      {
        "item_text": "Bardet-Biedl syndrome 10",
        "item_id": 697
      },
      {
        "item_text": "Bardet-Biedl syndrome 12",
        "item_id": 698
      },
      {
        "item_text": "Bardet-Biedl syndrome 2",
        "item_id": 699
      },
      {
        "item_text": "Retinitis pigmentosa 74",
        "item_id": 700
      },
      {
        "item_text": "Bardet-Biedl syndrome 4",
        "item_id": 701
      },
      {
        "item_text": "Bardet-Biedl syndrome 5",
        "item_id": 702
      },
      {
        "item_text": "Bardet-Biedl syndrome 7",
        "item_id": 703
      },
      {
        "item_text": "Bardet-Biedl syndrome 9",
        "item_id": 704
      },
      {
        "item_text": "[Blood group, Auberger system]",
        "item_id": 705
      },
      {
        "item_text": "[Blood group, Lutheran null]",
        "item_id": 706
      },
      {
        "item_text": "[Blood group, Lutheran system]",
        "item_id": 707
      },
      {
        "item_text": "Deafness, dystonia, and cerebral hypomyelination",
        "item_id": 708
      },
      {
        "item_text": "?Hyperleucinemia-isoleucinemia or hypervalinemia ",
        "item_id": 709
      },
      {
        "item_text": "?Hypervalinemia or hyperleucine-isoleucinemia ",
        "item_id": 710
      },
      {
        "item_text": "{Basal cell carcinoma, susceptibility to, 1}",
        "item_id": 711
      },
      {
        "item_text": "{Basal cell carcinoma, susceptibility to, 2}",
        "item_id": 712
      },
      {
        "item_text": "{Basal cell carcinoma, susceptibility to, 3}",
        "item_id": 713
      },
      {
        "item_text": "{Basal cell carcinoma, susceptibility to, 4}",
        "item_id": 714
      },
      {
        "item_text": "{Basal cell carcinoma, susceptibility to, 5}",
        "item_id": 715
      },
      {
        "item_text": "{Basal cell carcinoma, susceptibility to, 6}",
        "item_id": 716
      },
      {
        "item_text": "Apnea, postanesthetic ",
        "item_id": 717
      },
      {
        "item_text": "Maple syrup urine disease, type Ia",
        "item_id": 718
      },
      {
        "item_text": "Maple syrup urine disease, type Ib",
        "item_id": 719
      },
      {
        "item_text": "Branched-chain ketoacitem_id dehydrogenase kinase deficiency",
        "item_id": 720
      },
      {
        "item_text": "?Immunodeficiency 37",
        "item_id": 721
      },
      {
        "item_text": "Lymphoma, MALT, somatic",
        "item_id": 722
      },
      {
        "item_text": "{Lymphoma, follicular, somatic}",
        "item_id": 723
      },
      {
        "item_text": "{Male germ cell tumor, somatic},",
        "item_id": 724
      },
      {
        "item_text": "{Mesothelioma, somatic}",
        "item_id": 725
      },
      {
        "item_text": "{Sezary syndrome, somatic} ",
        "item_id": 726
      },
      {
        "item_text": "Dias-Logan syndrome",
        "item_id": 727
      },
      {
        "item_text": "?Immunodeficiency 49",
        "item_id": 728
      },
      {
        "item_text": "Leukemia\/lymphoma, B-cell, 2 ",
        "item_id": 729
      },
      {
        "item_text": "Leukemia\/lymphoma, B-cell, 3",
        "item_id": 730
      },
      {
        "item_text": "Lymphoma, B-cell",
        "item_id": 731
      },
      {
        "item_text": "B-cell non-Hodgkin lymphoma, high-grade ",
        "item_id": 732
      },
      {
        "item_text": "Hypercarotenemia and vitamin A deficiency, autosomal dominant",
        "item_id": 733
      },
      {
        "item_text": "Microphthalmia, syndromic 2",
        "item_id": 734
      },
      {
        "item_text": "Breast cancer ",
        "item_id": 735
      },
      {
        "item_text": "Leukemia, acute lymphocytic, somatic",
        "item_id": 736
      },
      {
        "item_text": "Leukemia, chronic myeloitem_id, somatic",
        "item_id": 737
      },
      {
        "item_text": "Bjornstad syndrome",
        "item_id": 738
      },
      {
        "item_text": "GRACILE syndrome",
        "item_id": 739
      },
      {
        "item_text": "Leigh syndrome",
        "item_id": 740
      },
      {
        "item_text": "Mitochondrial complex III deficiency, nuclear type 1",
        "item_id": 741
      },
      {
        "item_text": "Brachydactyly, type A1, B",
        "item_id": 742
      },
      {
        "item_text": "Bleeding disorder, east Texas type",
        "item_id": 743
      },
      {
        "item_text": "Chromosome 2q37 deletion syndrome",
        "item_id": 744
      },
      {
        "item_text": "{Anorexia nervosa, susceptibility to}",
        "item_id": 745
      },
      {
        "item_text": "{Bulimia nervosa, age of onset of weight loss in}",
        "item_id": 746
      },
      {
        "item_text": "{Memory impairment, susceptibility to} ",
        "item_id": 747
      },
      {
        "item_text": "{Obsessive-compulsive disorder, protection against}",
        "item_id": 748
      },
      {
        "item_text": "Spinocerebellar ataxia 31",
        "item_id": 749
      },
      {
        "item_text": "Bornholm eye disease",
        "item_id": 750
      },
      {
        "item_text": "Bestrophinopathy, autosomal recessive",
        "item_id": 751
      },
      {
        "item_text": "Macular dystrophy, vitelliform, 2",
        "item_id": 752
      },
      {
        "item_text": "Microcornea, rod-cone dystrophy, cataract, and posterior staphyloma",
        "item_id": 753
      },
      {
        "item_text": "Retinitis pigmentosa, concentric",
        "item_id": 754
      },
      {
        "item_text": "Retinitis pigmentosa-50",
        "item_id": 755
      },
      {
        "item_text": "Vitreoretinochoroitem_idopathy",
        "item_id": 756
      },
      {
        "item_text": "Seizures, benign familial infantile, 1",
        "item_id": 757
      },
      {
        "item_text": "Seizures, benign familial infantile, 4",
        "item_id": 758
      },
      {
        "item_text": "Cataract 33, multiple types",
        "item_id": 759
      },
      {
        "item_text": "Cataract 12, multiple types",
        "item_id": 760
      },
      {
        "item_text": "Meester-Loeys syndrome",
        "item_id": 761
      },
      {
        "item_text": "Spondyloepimetaphyseal dysplasia, X-linked",
        "item_id": 762
      },
      {
        "item_text": "?Camptosynpolydactyly, complex",
        "item_id": 763
      },
      {
        "item_text": "Syndactyly, mesoaxial synostotic, with phalangeal reduction",
        "item_id": 764
      },
      {
        "item_text": "[Short sleeper]",
        "item_id": 765
      },
      {
        "item_text": "{Renal dysplasia, cystic, susceptibility to}",
        "item_id": 766
      },
      {
        "item_text": "Spinal muscular atrophy, lower extremity-predominant, 2, AD",
        "item_id": 767
      },
      {
        "item_text": "Myopathy, centronuclear, autosomal recessive",
        "item_id": 768
      },
      {
        "item_text": "Maturity-onset diabetes of the young, type 11",
        "item_id": 769
      },
      {
        "item_text": "Bloom syndrome",
        "item_id": 770
      },
      {
        "item_text": "Agammaglobulinemia 4",
        "item_id": 771
      },
      {
        "item_text": "Hermansky-Pudlak syndrome 8",
        "item_id": 772
      },
      {
        "item_text": "?Hermansky-pudlak syndrome 9",
        "item_id": 773
      },
      {
        "item_text": "Hyperbiliverdinemia",
        "item_id": 774
      },
      {
        "item_text": "[Body mass index QTL1]",
        "item_id": 775
      },
      {
        "item_text": "[Body mass index QTL13]",
        "item_id": 776
      },
      {
        "item_text": "[Body mass index QTL 15]",
        "item_id": 777
      },
      {
        "item_text": "[Body mass index QTL16]",
        "item_id": 778
      },
      {
        "item_text": "Chromosome 16p11.2 deletion syndrome, 220kb",
        "item_id": 779
      },
      {
        "item_text": "[Body mass index QTL2]",
        "item_id": 780
      },
      {
        "item_text": "[Body mass index QTL3]",
        "item_id": 781
      },
      {
        "item_text": "[Body mass index QTL5]",
        "item_id": 782
      },
      {
        "item_text": "[Body mass index QTL6]",
        "item_id": 783
      },
      {
        "item_text": "{Obesity, susceptibility to, BMIQ7}",
        "item_id": 784
      },
      {
        "item_text": "{Obesity, susceptibility to, BMIQ8}",
        "item_id": 785
      },
      {
        "item_text": "[Bone mineral density QTL 10]",
        "item_id": 786
      },
      {
        "item_text": "[Bone mineral density QTL 11]",
        "item_id": 787
      },
      {
        "item_text": "[Bone mineral density QTL 13]",
        "item_id": 788
      },
      {
        "item_text": "[Bone mineral density QTL 14]",
        "item_id": 789
      },
      {
        "item_text": "[Bone mineral density QTL 2]",
        "item_id": 790
      },
      {
        "item_text": "[Bone mineral density QTL 3]",
        "item_id": 791
      },
      {
        "item_text": "[Bone mineral density QTL 4]",
        "item_id": 792
      },
      {
        "item_text": "[Bone mineral density QTL 5]",
        "item_id": 793
      },
      {
        "item_text": "[Bone mineral density QTL 6]",
        "item_id": 794
      },
      {
        "item_text": "{Osteoporosis}",
        "item_id": 795
      },
      {
        "item_text": "{Osteoporosis}",
        "item_id": 796
      },
      {
        "item_text": "[Bone mineral density QTL 9]",
        "item_id": 797
      },
      {
        "item_text": "Osteogenesis imperfecta, type XIII",
        "item_id": 798
      },
      {
        "item_text": "Ovarian dysgenesis 2",
        "item_id": 799
      },
      {
        "item_text": "Premature ovarian failure 4",
        "item_id": 800
      },
      {
        "item_text": "Brachydactyly, type A2",
        "item_id": 801
      },
      {
        "item_text": "{HFE hemochromatosis, modifier of}",
        "item_id": 802
      },
      {
        "item_text": "Microphthalmia, syndromic 6",
        "item_id": 803
      },
      {
        "item_text": "Orofacial cleft 11",
        "item_id": 804
      },
      {
        "item_text": "Diaphanospondylodysostosis",
        "item_id": 805
      },
      {
        "item_text": "Juvenile polyposis syndrome, infantile form",
        "item_id": 806
      },
      {
        "item_text": "Polyposis syndrome, hereditary mixed, 2",
        "item_id": 807
      },
      {
        "item_text": "Polyposis, juvenile intestinal",
        "item_id": 808
      },
      {
        "item_text": "Acromesomelic dysplasia, Demirhan type",
        "item_id": 809
      },
      {
        "item_text": "Brachydactyly, type A1, D",
        "item_id": 810
      },
      {
        "item_text": "Brachydactyly, type A2",
        "item_id": 811
      },
      {
        "item_text": "Pulmonary hypertension, familial primary, 1, with or without HHT",
        "item_id": 812
      },
      {
        "item_text": "Pulmonary hypertension, primary, fenfluramine or dexfenfluramine-associated",
        "item_id": 813
      },
      {
        "item_text": "Pulmonary venoocclusive disease 1",
        "item_id": 814
      },
      {
        "item_text": "?Aplasia cutis congenita, nonsyndromic",
        "item_id": 815
      },
      {
        "item_text": "Multiple mitochondrial dysfunctions syndrome 2 with hyperglycinemia",
        "item_id": 816
      },
      {
        "item_text": "Branchiootic syndrome 2",
        "item_id": 817
      },
      {
        "item_text": "Erythrocytosis due to bisphosphoglycerate mutase deficiency",
        "item_id": 818
      },
      {
        "item_text": "Polymicrogyria, bilateral perisylvian",
        "item_id": 819
      },
      {
        "item_text": "Vestibulopathy, familial",
        "item_id": 820
      },
      {
        "item_text": "Adenocarcinoma of lung, somatic",
        "item_id": 821
      },
      {
        "item_text": "Cardiofaciocutaneous syndrome",
        "item_id": 822
      },
      {
        "item_text": "Colorectal cancer, somatic ",
        "item_id": 823
      },
      {
        "item_text": "LEOPARD syndrome 3",
        "item_id": 824
      },
      {
        "item_text": "Melanoma, malignant, somatic ",
        "item_id": 825
      },
      {
        "item_text": "Nonsmall cell lung cancer, somatic ",
        "item_id": 826
      },
      {
        "item_text": "Noonan syndrome 7",
        "item_id": 827
      },
      {
        "item_text": "Rigitem_idity and multifocal seizure syndrome, lethal neonatal",
        "item_id": 828
      },
      {
        "item_text": "{Breast-ovarian cancer, familial, 1}",
        "item_id": 829
      },
      {
        "item_text": "{Pancreatic cancer, susceptibility to, 4}",
        "item_id": 830
      },
      {
        "item_text": "{Breast cancer, male, susceptibility to}",
        "item_id": 831
      },
      {
        "item_text": "{Breast-ovarian cancer, familial, 2}",
        "item_id": 832
      },
      {
        "item_text": "Fanconi anemia, complementation group D1",
        "item_id": 833
      },
      {
        "item_text": "{Glioblastoma 3}",
        "item_id": 834
      },
      {
        "item_text": "{Medulloblastoma}",
        "item_id": 835
      },
      {
        "item_text": "{Pancreatic cancer 2}",
        "item_id": 836
      },
      {
        "item_text": "{Prostate cancer}",
        "item_id": 837
      },
      {
        "item_text": "Wilms tumor",
        "item_id": 838
      },
      {
        "item_text": "?Breast cancer, type 3",
        "item_id": 839
      },
      {
        "item_text": "Breast cancer, 11:22 translocation associated ",
        "item_id": 840
      },
      {
        "item_text": "?Spermatogenic failure 21",
        "item_id": 841
      },
      {
        "item_text": "Cerebellofaciodental syndrome",
        "item_id": 842
      },
      {
        "item_text": "Breast cancer, early-onset",
        "item_id": 843
      },
      {
        "item_text": "Fanconi anemia, complementation group J",
        "item_id": 844
      },
      {
        "item_text": "Intellectual developmental disorder with dysmorphic facies and ptosis",
        "item_id": 845
      },
      {
        "item_text": "Vertigo, benign recurrent, 2",
        "item_id": 846
      },
      {
        "item_text": "Mental retardation, X-linked 93",
        "item_id": 847
      },
      {
        "item_text": "Encephalopathy, progressive, with or without lipodystrophy",
        "item_id": 848
      },
      {
        "item_text": "Lipodystrophy, congenital generalized, type 2",
        "item_id": 849
      },
      {
        "item_text": "Neuropathy, distal hereditary motor, type VA",
        "item_id": 850
      },
      {
        "item_text": "Silver spastic paraplegia syndrome",
        "item_id": 851
      },
      {
        "item_text": "[Blood group, OK]",
        "item_id": 852
      },
      {
        "item_text": "Bartter syndrome, type 4a",
        "item_id": 853
      },
      {
        "item_text": "Sensorineural deafness with mild renal dysfunction",
        "item_id": 854
      },
      {
        "item_text": "{Bone size QTL}",
        "item_id": 855
      },
      {
        "item_text": "{Bone size QTL}",
        "item_id": 856
      },
      {
        "item_text": "[Bone size quantitative trait locus 3]",
        "item_id": 857
      },
      {
        "item_text": "Biotinitem_idase deficiency",
        "item_id": 858
      },
      {
        "item_text": "Agammaglobulinemia and isolated hormone deficiency",
        "item_id": 859
      },
      {
        "item_text": "Agammaglobulinemia, X-linked 1",
        "item_id": 860
      },
      {
        "item_text": "{Sarcoitem_idosis, susceptibility to, 2}",
        "item_id": 861
      },
      {
        "item_text": "Colorectal cancer with chromosomal instability, somatic ",
        "item_id": 862
      },
      {
        "item_text": "Colorectal cancer, somatic",
        "item_id": 863
      },
      {
        "item_text": "Mosaic variegated aneuploitem_idy syndrome 1",
        "item_id": 864
      },
      {
        "item_text": "[Premature chromatitem_id separation trait]",
        "item_id": 865
      },
      {
        "item_text": "{Bulimia nervosa, susceptibility to}",
        "item_id": 866
      },
      {
        "item_text": "?Muscular dystrophy, limb-girdle, type 2X",
        "item_id": 867
      },
      {
        "item_text": "[Birth weight QTL 2]",
        "item_id": 868
      },
      {
        "item_text": "[Birth weight QTL4]",
        "item_id": 869
      },
      {
        "item_text": "Bazex syndrome",
        "item_id": 870
      },
      {
        "item_text": "Temtamy syndrome",
        "item_id": 871
      },
      {
        "item_text": "Combined oxitem_idative phosphorylation deficiency 7",
        "item_id": 872
      },
      {
        "item_text": "Spastic paraplegia 55, autosomal recessive",
        "item_id": 873
      },
      {
        "item_text": "Dyserythropoietic anemia, congenital, type Ib",
        "item_id": 874
      },
      {
        "item_text": "Chromosome 16q22 deletion syndrome",
        "item_id": 875
      },
      {
        "item_text": "Neurodegeneration with brain iron accumulation 4",
        "item_id": 876
      },
      {
        "item_text": "?Spastic paraplegia 43, autosomal recessive",
        "item_id": 877
      },
      {
        "item_text": "Tn polyagglutination syndrome, somatic",
        "item_id": 878
      },
      {
        "item_text": "C1q deficiency",
        "item_id": 879
      },
      {
        "item_text": "C1q deficiency",
        "item_id": 880
      },
      {
        "item_text": "Combined oxitem_idative phosphorylation deficiency 33",
        "item_id": 881
      },
      {
        "item_text": "C1q deficiency",
        "item_id": 882
      },
      {
        "item_text": "Retinal degeneration, late-onset, autosomal dominant",
        "item_id": 883
      },
      {
        "item_text": "Ehlers-Danlos syndrome, periodontal type, 1",
        "item_id": 884
      },
      {
        "item_text": "C1s deficiency",
        "item_id": 885
      },
      {
        "item_text": "Ehlers-Danlos syndrome, periodontal type, 2",
        "item_id": 886
      },
      {
        "item_text": "C2 deficiency",
        "item_id": 887
      },
      {
        "item_text": "{Macular degeneration, age-related, 14, reduced risk of}",
        "item_id": 888
      },
      {
        "item_text": "Retinal dystrophy with macular staphyloma",
        "item_id": 889
      },
      {
        "item_text": "Spondylometaphyseal dysplasia, axial",
        "item_id": 890
      },
      {
        "item_text": "Ciliary dyskinesia, primary, 26",
        "item_id": 891
      },
      {
        "item_text": "?Orofaciodigital syndrome XIV",
        "item_id": 892
      },
      {
        "item_text": "Retinitis pigmentosa 54",
        "item_id": 893
      },
      {
        "item_text": "C3 deficiency",
        "item_id": 894
      },
      {
        "item_text": "{Hemolytic uremic syndrome, atypical, susceptibility to, 5}",
        "item_id": 895
      },
      {
        "item_text": "{Macular degeneration, age-related, 9}",
        "item_id": 896
      },
      {
        "item_text": "[Blood group, Rodgers]",
        "item_id": 897
      },
      {
        "item_text": "C4a deficiency",
        "item_id": 898
      },
      {
        "item_text": "C4B deficiency",
        "item_id": 899
      },
      {
        "item_text": "C5 deficiency",
        "item_id": 900
      },
      {
        "item_text": "[Eculizumab, poor response to]",
        "item_id": 901
      },
      {
        "item_text": "Joubert syndrome 17",
        "item_id": 902
      },
      {
        "item_text": "Orofaciodigital syndrome VI",
        "item_id": 903
      },
      {
        "item_text": "C6 deficiency",
        "item_id": 904
      },
      {
        "item_text": "Combined C6\/C7 deficiency ",
        "item_id": 905
      },
      {
        "item_text": "C7 deficiency",
        "item_id": 906
      },
      {
        "item_text": "C8 deficiency, type I",
        "item_id": 907
      },
      {
        "item_text": "C8 deficiency, type II",
        "item_id": 908
      },
      {
        "item_text": "Bardet-Biedl syndrome 21",
        "item_id": 909
      },
      {
        "item_text": "Cone-rod dystrophy 16",
        "item_id": 910
      },
      {
        "item_text": "Retinitis pigmentosa 64",
        "item_id": 911
      },
      {
        "item_text": "C9 deficiency",
        "item_id": 912
      },
      {
        "item_text": "{Macular degeneration, age-related, 15, susceptibility to}",
        "item_id": 913
      },
      {
        "item_text": "Frontotemporal dementia and\/or amyotrophic lateral sclerosis 1",
        "item_id": 914
      },
      {
        "item_text": "Hyperchlorhitem_idrosis, isolated",
        "item_id": 915
      },
      {
        "item_text": "Osteopetrosis, autosomal recessive 3, with renal tubular acitem_idosis",
        "item_id": 916
      },
      {
        "item_text": "Retinitis pigmentosa 17",
        "item_id": 917
      },
      {
        "item_text": "Hyperammonemia due to carbonic anhydrase VA deficiency",
        "item_id": 918
      },
      {
        "item_text": "Cerebellar ataxia and mental retardation with or without quadrupedal locomotion 3",
        "item_id": 919
      },
      {
        "item_text": "Deafness, autosomal recessive 93",
        "item_id": 920
      },
      {
        "item_text": "Cone-rod synaptic disorder, congenital nonprogressive",
        "item_id": 921
      },
      {
        "item_text": "Choroitem_idal dystrophy, central areolar 1",
        "item_id": 922
      },
      {
        "item_text": "Epileptic encephalopathy, early infantile, 42",
        "item_id": 923
      },
      {
        "item_text": "Episodic ataxia, type 2",
        "item_id": 924
      },
      {
        "item_text": "Migraine, familial hemiplegic, 1, with progressive cerebellar ataxia",
        "item_id": 925
      },
      {
        "item_text": "Spinocerebellar ataxia 6",
        "item_id": 926
      },
      {
        "item_text": "?Dystonia 23",
        "item_id": 927
      },
      {
        "item_text": "Brugada syndrome 3",
        "item_id": 928
      },
      {
        "item_text": "Timothy syndrome",
        "item_id": 929
      },
      {
        "item_text": "Primary aldosteronism, seizures, and neurologic abnormalities",
        "item_id": 930
      },
      {
        "item_text": "Sinoatrial node dysfunction and deafness",
        "item_id": 931
      },
      {
        "item_text": "Aland Island eye disease",
        "item_id": 932
      },
      {
        "item_text": "Cone-rod dystrophy, X-linked, 3",
        "item_id": 933
      },
      {
        "item_text": "Night blindness, congenital stationary (incomplete), 2A, X-linked",
        "item_id": 934
      },
      {
        "item_text": "Spinocerebellar ataxia 42",
        "item_id": 935
      },
      {
        "item_text": "{Epilepsy, childhood absence, susceptibility to, 6}",
        "item_id": 936
      },
      {
        "item_text": "{Epilepsy, item_idiopathic generalized, susceptibility to, 6}",
        "item_id": 937
      },
      {
        "item_text": "Hyperaldosteronism, familial, type IV",
        "item_id": 938
      },
      {
        "item_text": "Hypokalemic periodic paralysis, type 1",
        "item_id": 939
      },
      {
        "item_text": "{Malignant hyperthermia susceptibility 5}",
        "item_id": 940
      },
      {
        "item_text": "{Thyrotoxic periodic paralysis, susceptibility to, 1}",
        "item_id": 941
      },
      {
        "item_text": "Retinal cone dystrophy 4",
        "item_id": 942
      },
      {
        "item_text": "Brugada syndrome 4",
        "item_id": 943
      },
      {
        "item_text": "{Epilepsy, item_idiopathic generalized, susceptibility to, 9}",
        "item_id": 944
      },
      {
        "item_text": "{Epilepsy, juvenile myoclonic, susceptibility to, 6}",
        "item_id": 945
      },
      {
        "item_text": "Episodic ataxia, type 5",
        "item_id": 946
      },
      {
        "item_text": "?Mental retardation, autosomal dominant 10",
        "item_id": 947
      },
      {
        "item_text": "Epileptic encephalopathy, early infantile, 50",
        "item_id": 948
      },
      {
        "item_text": "{Osteoporosis, postmenopausal, susceptibility}",
        "item_id": 949
      },
      {
        "item_text": "Long QT syndrome 14",
        "item_id": 950
      },
      {
        "item_text": "Ventricular tachycardia, catecholaminergic polymorphic, 4",
        "item_id": 951
      },
      {
        "item_text": "Long QT syndrome 15",
        "item_id": 952
      },
      {
        "item_text": "Myelofibrosis, somatic",
        "item_id": 953
      },
      {
        "item_text": "Thrombocythemia, somatic",
        "item_id": 954
      },
      {
        "item_text": "?Cardiomyopathy, hypertrophic, 19",
        "item_id": 955
      },
      {
        "item_text": "Camptodactyly 1",
        "item_id": 956
      },
      {
        "item_text": "Cerebellar ataxia, nonprogressive, with mental retardation",
        "item_id": 957
      },
      {
        "item_text": "Canditem_idiasis, familial, 1, autosomal dominant",
        "item_id": 958
      },
      {
        "item_text": "Canditem_idiasis, familial, 3",
        "item_id": 959
      },
      {
        "item_text": "Desbuquois dysplasia 1",
        "item_id": 960
      },
      {
        "item_text": "Epiphyseal dysplasia, multiple, 7",
        "item_id": 961
      },
      {
        "item_text": "Spastic paraplegia 76, autosomal recessive",
        "item_id": 962
      },
      {
        "item_text": "{Diabetes mellitus, noninsulin-dependent 1}",
        "item_id": 963
      },
      {
        "item_text": "Muscular dystrophy, limb-girdle, type 2A",
        "item_id": 964
      },
      {
        "item_text": "Vitreoretinopathy, neovascular inflammatory",
        "item_id": 965
      },
      {
        "item_text": "B-cell expansion with NFKB and T-cell anergy",
        "item_id": 966
      },
      {
        "item_text": "Immunodeficiency 11A",
        "item_id": 967
      },
      {
        "item_text": "Immunodeficiency 11B with atopic dermatitis",
        "item_id": 968
      },
      {
        "item_text": "Pityriasis rubra pilaris",
        "item_id": 969
      },
      {
        "item_text": "Psoriasis 2",
        "item_id": 970
      },
      {
        "item_text": "Canditem_idiasis, familial, 2, autosomal recessive",
        "item_id": 971
      },
      {
        "item_text": "Combined oxitem_idative phosphorylation deficiency 27",
        "item_id": 972
      },
      {
        "item_text": "{?Obesity, susceptibility to}",
        "item_id": 973
      },
      {
        "item_text": "FG syndrome 4",
        "item_id": 974
      },
      {
        "item_text": "Mental retardation and microcephaly with pontine and cerebellar hypoplasia",
        "item_id": 975
      },
      {
        "item_text": "Mental retardation, with or without nystagmus",
        "item_id": 976
      },
      {
        "item_text": "Autoimmune lymphoproliferative syndrome, type II",
        "item_id": 977
      },
      {
        "item_text": "Gastric cancer, somatic",
        "item_id": 978
      },
      {
        "item_text": "Lymphoma, non-Hodgkin, somatic",
        "item_id": 979
      },
      {
        "item_text": "{Sepsis, susceptibility to} ",
        "item_id": 980
      },
      {
        "item_text": "Ichthyosis, congenital, autosomal recessive 12",
        "item_id": 981
      },
      {
        "item_text": "?Autoimmune lymphoproliferative syndrome, type IIB",
        "item_id": 982
      },
      {
        "item_text": "{Breast cancer, protection against}",
        "item_id": 983
      },
      {
        "item_text": "Hepatocellular carcinoma, somatic",
        "item_id": 984
      },
      {
        "item_text": "{Lung cancer, protection against}",
        "item_id": 985
      },
      {
        "item_text": "Myopathy, vacuolar, with CASQ1 aggregates",
        "item_id": 986
      },
      {
        "item_text": "Ventricular tachycardia, catecholaminergic polymorphic, 2",
        "item_id": 987
      },
      {
        "item_text": "{Calcium, serum level of} ",
        "item_id": 988
      },
      {
        "item_text": "{Epilepsy item_idiopathic generalized, susceptibility to, 8}",
        "item_id": 989
      },
      {
        "item_text": "Hypercalciuric hypercalcemia ",
        "item_id": 990
      },
      {
        "item_text": "Hyperparathyroitem_idism, neonatal",
        "item_id": 991
      },
      {
        "item_text": "Hypocalcemia, autosomal dominant",
        "item_id": 992
      },
      {
        "item_text": "Hypocalcemia, autosomal dominant, with Bartter syndrome",
        "item_id": 993
      },
      {
        "item_text": "Hypocalciuric hypercalcemia, type I",
        "item_id": 994
      },
      {
        "item_text": "Peeling skin with leukonychia, acral punctate keratoses, cheilitis, and knuckle pads",
        "item_id": 995
      },
      {
        "item_text": "Acatalasemia",
        "item_id": 996
      },
      {
        "item_text": "Spermatogenic failure 7",
        "item_id": 997
      },
      {
        "item_text": "?Lipodystrophy, congenital generalized, type 3",
        "item_id": 998
      },
      {
        "item_text": "?Partial lipodystrophy, congenital cataracts, and neurodegeneration syndrome",
        "item_id": 999
      },
      {
        "item_text": "Pulmonary hypertension, primary, 3",
        "item_id": 1000
      }
]