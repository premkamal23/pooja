import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { omimList } from './omim-list.data';
import { OpenAnalysisService } from '../../common/services/open-analysis.service';

@Component({
    selector: 'app-phenotypes',
    templateUrl: './phenotypes.component.html',
    styleUrls: ['./phenotypes.component.css']
})
export class PhenotypesComponent implements OnInit {

    @Input('phenotypeData') phenotypeData: any = {};
    @Output('filterChanged') filterChanged = new EventEmitter<any>();
    dropdownList = [];
    dropdownSettings = {};
    selectedItems = [];
    omimList = omimList;
    filterName: string;

    modelMapping: any = {
        omim: 'omim_options'
    };
    constructor(private openanalysisService: OpenAnalysisService) { }

    ngOnInit() {
        this.filterName = this.phenotypeData.name;
        const self: any = this;
        this.dropdownSettings = {
            singleSelection: false,
            idField: 'item_id',
            textField: 'item_text',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 3,
            allowSearchFilter: true
        };

        if (this.phenotypeData.options.omim) {
            let i, j, flag = false;
            for (i = 0; i < this.phenotypeData.options.omim_options.length; i++) {
                flag = false;
                for (j = 0; j < this.omimList.length; j++) {
                    if (this.phenotypeData.options.omim_options[i].item_id === this.omimList[j].item_id) {
                        flag = true;
                        this.selectedItems.push(this.omimList[j]);
                        break;
                    }
                }
                if (!flag) {
                    this.omimList.push({ item_id: i, item_text: this.phenotypeData.options.omim_options[i] });
                    this.selectedItems.push({ item_id: i, item_text: this.phenotypeData.options.omim_options[i] });
                }
            }
        }
    }

    dataTemplate() {
        return {
            name: this.filterName,
            options: {
                type: `com.pki.ngs.entities.PhenotypeFilter`,
                keep_exclude: this.phenotypeData.options.keep_exclude,
                zygosity: this.phenotypeData.options.zygosity,
                any_all: this.phenotypeData.options.any_all
            }
        };
    }

    _filterChanged({ target }, fieldName) {
        const { name, checked } = target;
        const mappedModel = this.modelMapping[name];
        const data = this.dataTemplate();

        data.options[name] = checked;
        if (checked) {
            const field = this[fieldName].value;
            const selected = field.filter(f => f.check).map(f => f.type);
            data.options[mappedModel] = selected;
        } else {
            data.options[mappedModel] = [];
        }

        let result = {};
        if (!this.phenotypeData.options.omim) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    _dropDownOptionsChanged(item, modelName, fieldName) {
        const data = this.dataTemplate();
        data.options[modelName] = this[fieldName].map(o => o.item_text);
        let result = {};
        if (!this.phenotypeData.options.omim) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    filterChangedOptions(filterName, value) {
        const data = this.dataTemplate();
        data.options[filterName] = value;
        let result = {};
        if (!this.phenotypeData.options.omim) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    filter(e) {
        this.openanalysisService.getOmimData(e.target.value).subscribe((data: any) => {
            const authToken = data.token;
            if (data.token !== null) {
                sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            const content: any = data.data;
            for (let i = 0; i < content.length; i++) {
                content[i].item_text = content[i]['item_name'];
                delete content[i].item_name;
            }
            this.omimList = content;
        });
    }

    filterNameChanged() {
        const data = this.dataTemplate();
        let result = {};
        if (!this.phenotypeData.options.omim) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

}
