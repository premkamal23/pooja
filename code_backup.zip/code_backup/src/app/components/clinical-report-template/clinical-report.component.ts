import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'clinical-report',
  templateUrl: './clinical-report.component.html',
  styleUrls: ['./clinical-report.component.css']
})
export class ClinicalReportComponent implements OnInit {

  purpleboolean: boolean = false;
  normalboolean: boolean = true;

  constructor(private router: Router) { }

  ngOnInit() {
    this.router.navigate(['app/clinical-report/report-module']);
  }

  getNormalBoard() {
    this.normalboolean = true;
    this.purpleboolean = false;
    this.router.navigate(['app/clinical-report/report-module']);
  }

  getPurpleBoard() {
    this.normalboolean = false;
    this.purpleboolean = true;
    this.router.navigate(['app/clinical-report/purple-module']);
  }

}
