import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { UserManagementService } from '../../common/services/user-management.service';

export interface ConfirmModel {
  user_id: number;
  email: string;
  loc: string;
}

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent extends DialogComponent<ConfirmModel, any> implements ConfirmModel, OnInit {

  old_password: string;
  new_password: string;
  confirm_password: string;
  user_id: number;
  email: string;
  error_msg: string;
  loc: string;
  errorList: Array<any>;

  constructor(
    dialogService: DialogService,
    private service: UserManagementService
  ) {
    super(dialogService);
  }

  ngOnInit() {
    this.clearError();
  }

  clearError() {
    this.errorList = [];
  }

  changePassword() {
    this.clearError();
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
    if (!passwordRegex.test(this.new_password)) {
      this.errorList.push('Please enter valid password. The password should be atleast 8 characters long, alphanumeric and with one special character.');
    } else {
      const addUser = this.service.addUser(this.user_id, this.email, this.old_password, this.new_password, this.confirm_password);
      addUser.subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        if (this.loc === 'user') {
          this.result = 'Your password has been changed successfully. Login again to continue.';
        } else {
          this.result = 'Password changed. Please Login to continue';
        }
        this.close();
      },
        (error: any) => {
          console.error(error.error.data);
          this.errorList.push(error.error.data);
        });
    }
  }

  closeModal() {
    this.result = false;
    this.close();
  }

}
