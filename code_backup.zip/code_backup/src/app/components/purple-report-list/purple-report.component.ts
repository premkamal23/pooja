import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReportModuleService } from '../../common/services/report-module.service';
declare var $: any;

@Component({
  selector: 'purple-report',
  templateUrl: './purple-report.component.html',
  styleUrls: ['./purple-report.component.css']
})
export class PurpleReportComponent implements OnInit {
  offset: number;
  firstRecord: number;
  limit = 10;
  filterPayload: any;
  sortBy = 'created_on';
  sortDir = 'desc';
  gridContent: any;
  totalRecords: any;
  report_id: any;
  savedMessage: string;
  constructor(
    private router: Router,
    private service: ReportModuleService
  ) { }

  ngOnInit() {
  }

  createNewTemplate() {
    this.router.navigate(['app/clinical-report/new-purple/null']);
  }

  getFileData() {
    this.service.getReportData(this.sortBy, this.sortDir, this.offset, this.limit, this.filterPayload).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.gridContent = [...response.data.reportTemplateWrapperList];
      this.totalRecords = response.data.totalCount;
    });
  }

  lazyLoadData(event) {
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = event.first / event.rows;
    this.firstRecord = event.first;
    this.sortBy = event.sortField ? event.sortField : 'id';
    this.sortDir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    const filters = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});
    this.filterPayload = filters ? filters : {};
    this.getFileData();
  }

  deleteTemplate() {
    this.service.deleteReport(this.report_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.savedMessage = response.data;
      $('#deleteAlert').modal('toggle');
      this.getFileData();
    }, (err) => {
      this.savedMessage = err.error.data;
      $('#deleteAlert').modal('toggle');
    });
  }

  deleteReportTemplate(dataItem) {
    this.report_id = dataItem.id
    $('#deleteTemplateModal').modal('toggle');
  }

  editTemplate(dataItem) {
    this.router.navigate(['app/clinical-report/new-purple/' + dataItem.id]);
  }

}
