import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';

export interface ConfirmModel {
  id: string;
  description: string;
  isEdit: boolean;
}

@Component({
  selector: 'clinical-notes-dialog',
  templateUrl: './clinical-notes-dialog.component.html',
  styleUrls: ['./clinical-notes-dialog.component.css']
})

export class ClinicalNotesDialogComponent extends DialogComponent<ConfirmModel, any> implements ConfirmModel, OnInit {
  client_ids = [];
  active: boolean;
  id: string;
  description: string;
  errorList: Array<any>;
  isEdit: boolean;
  NotesCkeditorConfig = {
    allowedContent: true,
    height: 450,
    resize_enabled: false,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker,JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock'
  };
  constructor(dialogService: DialogService) {
    super(dialogService);
  }

  ngOnInit() {
    this.clearError();
  }

  confirm() {
    this.result = true;
    this.close();
  }

  closeModal() {
    this.result = false;
    this.isEdit = false;
    this.close();
  }

  addNotes() {
    this.clearError();
    if (!this.id) {
      this.errorList.push('Please enter name');
    }
    if (!this.description) {
      this.errorList.push('Please enter notes');
    }
    if (this.errorList.length > 0) {

    } else {
      this.result = {
        id: this.id,
        description: this.description,
        created_by: null,
        modified_by: null
      }
      this.close();
    }
  }

  clearError() {
    this.errorList = [];
  }
  
}
