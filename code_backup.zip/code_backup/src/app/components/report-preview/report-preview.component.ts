import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { ReportModuleService } from '../../common/services/report-module.service';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-report-preview',
  templateUrl: './report-preview.component.html',
  styleUrls: ['./report-preview.component.css'],
  encapsulation: ViewEncapsulation.Emulated
})
export class ReportPreviewComponent implements OnInit {
  @Input() reportData: any;
  @Input() editFlag: boolean;
  leftlogo: string;
  rightlogo: string;
  alertMessage: string;
  errorFlag: boolean = false;
  errorMessage: string;
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  YearRange: any = '';
  CkeditorConfigForTextbox = {
    allowedContent: true,
    height: 30,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };
  CkeditorConfig = {
    allowedContent: true,
    height: 100,
    resize_enabled: false,
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    fontSize_defaultLabel: '11',
    extraPlugins: "divarea",
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker'
  };

  VariantInterpretationCkeditorConfig = {
    allowedContent: true,
    height: 100,
    resize_enabled: false,
    extraPlugins: "divarea",
    fontSize_defaultLabel: '11',
    copyFormatting_allowedContexts: false,
    pasteFromWordRemoveFontStyles: true,
    pasteFromWordRemoveStyles: true,
    removePlugins: 'wsc,scayt,ToolbarBreak,about,specialchar,scayt,spellchecker,elementspath,resize,magicline',
    removeButtons: 'ToolbarBreak,Save,NewPage,Preview,Print,Templates,Button,TemplatesCut,Copy,Undo,Cut,Redo,Replace,Find,SelectAll,\
                ,Undo,Paste,PasteText,PasteFromWord,Form,Radio,TextField,Textarea,Checkbox,Select,\
                ,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,Indent,\
                ,Blockquote,CreateDiv,Language,BidiRtl,BidiLtr,Anchor,Unlink,Link,Image,Flash,Table,\
                ,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,TextColor,Maximize,About,\
                ,ShowBlocks,BGColor,Format,Source,Strike,spellchecker,JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock'
  };

  constructor(private service: ReportModuleService, private router: Router) { }

  ngOnInit() {
    if (this.reportData) {
      this.leftlogo = this.reportData.logo1_path; //'http://10.53.18.133' + 
      this.rightlogo = this.reportData.logo2_path; //'http://10.53.18.133' + 
    }
    this.YearRange = '1928:' + (new Date().getFullYear());
  }

  ngDoCheck() {
    if (this.reportData) {
      this.leftlogo = this.reportData.logo1_path; //'http://10.53.18.133' +
      this.rightlogo = this.reportData.logo2_path; //'http://10.53.18.133' + 
    }
  }


  saveReportData() {
    if (this.reportData.id === null || this.reportData.id === "") {
      this.errorMessage = 'Please Enter Template Name';
      $('#errorAlert').modal('toggle');
      return;
    }
    if (this.reportData.test_ids === null || this.reportData.test_ids.length === 0) {
      this.errorMessage = 'Please Enter Test Id';
      $('#errorAlert').modal('toggle');
      return;
    }

    if (this.editFlag) {
      this.reportData.modified_by = sessionStorage.getItem('user');
      this.service.editReportTemplate(this.reportData).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        if (response) {

          this.alertMessage = response.data;
          $('#saveAlert').modal('toggle');
        }
      }, (err) => {
        this.errorMessage = err.error.data;
        $('#errorAlert').modal('toggle');
      })
    } else {
      this.reportData.created_by = sessionStorage.getItem('user');
      this.service.saveReportTemplate(this.reportData).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        if (response) {
          this.alertMessage = response.data;
          $('#saveAlert').modal('toggle');
        }
      }, (err) => {
        this.errorMessage = err.error.data;
        $('#errorAlert').modal('toggle');
      })
    }

  }

  closeWindow() {
    this.notify.emit('Success');
  }
}
