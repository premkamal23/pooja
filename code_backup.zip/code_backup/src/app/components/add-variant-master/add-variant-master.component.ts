import { Component, OnInit, Input } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { OpenAnalysisService } from '../../common/services/open-analysis.service';
import { MasterTablesService } from '../../common/services/master-tables.service';
import { data } from './variantData';


export interface ACMGData {
  acmgData: any;
}

@Component({
  selector: 'add-variant-master',
  templateUrl: './add-variant-master.component.html',
  styleUrls: ['./add-variant-master.component.css']
})
export class AddVariantMasterComponent extends DialogComponent<ACMGData, any> implements ACMGData, OnInit {

  acmgData: any;
  genelist: any = [];
  variantData: data = {};
  errorMsg: string;
  errorList = [];
  load = false;
  gene = '';

  constructor(
    dialogService: DialogService,
    private openanalysisService: OpenAnalysisService,
    private masterService: MasterTablesService
  ) {
    super(dialogService);
  }

  ngOnInit() {
    this.variantData.emv_class = '';
    this.variantData.hgmd_class = '';
    this.variantData.clinvar = '';
    this.variantData.gnomad_high_freq_pop = '';
    this.variantData.chrom = '';
    this.getGeneList();
    this.off();
    this.load = false;
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  getGeneList() {
    this.openanalysisService.getGeneList()
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.genelist = response.data;
      });
  }

  onSelectType(event) {
  }

  typeaheadOnSelect(event) {
    this.variantData.gene = event.value;
  }

  addVariant() {
    this.clearError();
    if (this.variantData.chrom === '' || this.variantData.chrom === undefined) {
      this.errorList.push('Please enter Chromosome value');
    }
    if (this.variantData.gene === '' || this.variantData.gene === undefined) {
      this.errorList.push('Please select Gene name');
    }
    if (this.variantData.genomic_start === null || this.variantData.genomic_start === undefined) {
      this.errorList.push('Please enter Start position value');
    }
    if (this.variantData.genomic_stop === null || this.variantData.genomic_stop === undefined) {
      this.errorList.push('Please enter End position value');
    }
    if (this.variantData.ref === '' || this.variantData.ref === undefined) {
      this.errorList.push('Please enter Ref value');
    }
    if (this.variantData.alt === '' || this.variantData.alt === undefined) {
      this.errorList.push('Please enter Alt value');
    }
    if (this.variantData.cdna === '' || this.variantData.cdna === undefined) {
      this.errorList.push('Please enter cDNA value');
    } if (this.errorList.length > 0) {

    } else {
      this.variantData.manually_added_by_name = sessionStorage.getItem('user');
      this.variantData.manually_added_by_email = sessionStorage.getItem('email');
      this.on();
      this.load = true;
      this.masterService.addVariantToMaster(this.variantData).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.result = 'success';
        this.close();
        this.off();
        this.load = false;
      }, (err) => {
        this.errorMsg = err.error.data;
        this.load = false;
        this.off();
      });
    }

  }

  on() {
    document.getElementById("overlay").style.display = "block";
  }

  off() {
    document.getElementById("overlay").style.display = "none";
  }

  clearError() {
    this.errorList = [];
  }
}
