export interface data {
    chrom?: string,
    gene?: string,
    genomic_start?: number,
    genomic_stop?: number,
    ref?: string,
    alt?: string,
    cdna?: string;
    protein?: string,
    dbsnp?: string,
    transcript?: string;
    zygosity?: string,
    exon?: number,

    emv_class?: string,
    hgmd_class?: string,
    clinvar?: string,

    thousand_genomes_af_all?: number,
    thousand_genomes_af_afr?: number,
    thousand_genomes_af_amr?: number,
    thousand_genomes_af_asn?: number,
    thousand_genomes_af_eur?: number,

    ex_ac_af_all_perc?: number,
    ex_ac_af_afr_perc?: number,
    ex_ac_af_amr_perc?: number,
    ex_ac_af_eas_perc?: number,
    ex_ac_af_fin_perc?: number,
    ex_ac_af_nfe_perc?: number,
    ex_ac_af_sas_perc?: number,

    ex_ac_af_all_count?: number,
    ex_ac_af_afr_count?: number,
    ex_ac_af_amr_count?: number,
    ex_ac_af_eas_count?: number,
    ex_ac_af_fin_count?: number,
    ex_ac_af_nfe_count?: number,
    ex_ac_af_sas_count?: number,

    gnomad_high_freq?: number,
    gnom_ad_popmax_perc?: number,
    gnom_ad_all_perc?: number,
    gnom_ad_other_perc?: number,

    gnomad_high_freq_pop?: string,

    gnomad_high_freq_count?: number,
    gnom_ad_popmax_count?: number,
    gnom_ad_all_count?: number,
    gnom_ad_other_count?: number,
    gnomad_hom_count?: number,
    gnomad_hemi_count?: number,

    gme_af?: number,
    gme_ac?: number,

    dbsnp_af?: number,

    manually_added_by_name?: string,
    manually_added_by_email?: string
}