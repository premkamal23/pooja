import { IDropdownList } from './dropdown-list.interface';

export const chromosomeList: Array<IDropdownList> = [
    { item_id: 1, item_text: '1' },
    { item_id: 2, item_text: '2' },
    { item_id: 3, item_text: '3' },
    { item_id: 4, item_text: '4' },
    { item_id: 5, item_text: '5' },
    { item_id: 6, item_text: '6'},
    { item_id: 7, item_text: '7' },
    { item_id: 8, item_text: '8' },
    { item_id: 9, item_text: '9' },
    { item_id: 10, item_text: '10'},
    { item_id: 11, item_text: '11'},
    { item_id: 12, item_text: '12'},
    { item_id: 13, item_text: '13'},
    { item_id: 14, item_text: '14'},
    { item_id: 15, item_text: '15'},
    { item_id: 16, item_text: '16'},
    { item_id: 17, item_text: '17'},
    { item_id: 18, item_text: '18'},
    { item_id: 19, item_text: '19'},
    { item_id: 20, item_text: '20'},
    { item_id: 21, item_text: '21'},
    { item_id: 22, item_text: '22'},
    { item_id: 23, item_text: 'X'},
    { item_id: 24, item_text: 'Y'},
    { item_id: 25, item_text: 'MT'}
];
