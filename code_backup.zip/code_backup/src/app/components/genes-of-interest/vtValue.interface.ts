interface IValue {
    type: string;
    check: boolean;
}

export interface IGOIData {
    key: string;
    value: Array<IValue>;
}
