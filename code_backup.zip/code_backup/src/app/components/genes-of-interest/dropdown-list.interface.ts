export interface IDropdownList {
    item_id: number;
    item_text: any;
}
