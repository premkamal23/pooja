import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { chromosomeList } from './chromosome-list.data';
import { variantTypeData } from './variant-type.data';
import { IGOIData } from './vtValue.interface';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-genes-of-interest',
    templateUrl: './genes-of-interest.component.html',
    styleUrls: ['./genes-of-interest.component.css']
})
export class GenesOfInterestComponent implements OnInit {

    @Input('geneOfInterestData') geneOfInterestData: any = {};
    @Output('filterChanged') filterChanged = new EventEmitter<any>();
    chromosomeList = chromosomeList;
    chromosome_list = [];
    goiList = [];
    variantTypeData: IGOIData = variantTypeData;
    dropdownSettings = {};
    selectedItems = [];
    selectedGOI = [];
    geneListURL = '/api/geneFiles';
    filterName: string;
    modelMapping: any = {
        goi: 'goi_options',
        chrom: 'chrom_options',
        varient_type: 'varient_options'
    };

    constructor(
        private http: HttpClient
    ) { }

    ngOnInit() {
        this.filterName = this.geneOfInterestData.name;
        this.http.get(this.geneListURL).subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
                sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.chromosome_list = this.chromosomeList;
            for (let i = 0; i < response.data.content.length; i++) {
                this.goiList = this.goiList.concat({ item_id: i, item_text: response.data.content[i].file_name });
            }
            this.dropdownSettings = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                selectAllText: 'Select All',
                unSelectAllText: 'UnSelect All',
                itemsShowLimit: 3,
                allowSearchFilter: true
            };

            const opts = this.geneOfInterestData.options;
            const okeys = Object.keys(opts);
            okeys.forEach(o => {
                if (o.endsWith('_options')) {
                    opts[o] = Array.isArray(opts[o]) ? opts[o] : [];
                }
            });
            if (this.geneOfInterestData.options.chrom) {
                this.selectedItems = this.chromosomeList
                    .filter(cvl => this.geneOfInterestData.options.chrom_options.find(co => co === cvl.item_text));
            }
            if (this.geneOfInterestData.options.goi) {
                this.selectedGOI = this.goiList
                    .filter(cvl => this.geneOfInterestData.options.goi_options.find(co => co === cvl.item_text));
            }
            if (this.geneOfInterestData.options.variantTypeData) {
                this.variantTypeData.value = this.setSelectedModels('variantTypeData', 'varient_options');
            }
        });
    }

    setSelectedModels(model, incomingData) {
        return this[model].value.map(v => {
            if (this.geneOfInterestData.options[incomingData].includes(v.type)) {
                v.check = true;
            }
            return v;
        });
    }

    dataTemplate() {
        return {
            name: this.filterName,
            options: {
                type: `com.pki.ngs.entities.GoiFilter`,
                keep_exclude: this.geneOfInterestData.options.keep_exclude,
                zygosity: this.geneOfInterestData.options.zygosity,
                any_all: this.geneOfInterestData.options.any_all
            }
        };
    }

    _dropDownOptionsChanged(item, modelName, fieldName) {
        const data = this.dataTemplate();
        data.options[modelName] = this[fieldName].map(o => o.item_text);
        let result = {};
        if (!this.geneOfInterestData.options.goi && !this.geneOfInterestData.options.chrom
            && !this.geneOfInterestData.options.varient_type) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    _filterChanged({ target }, fieldName) {
        const { name, checked } = target;
        const mappedModel = this.modelMapping[name];
        const data = this.dataTemplate();

        data.options[name] = checked;
        if (checked) {
            const field = this[fieldName].value;
            const selected = field.filter(f => f.check).map(f => f.type);
            data.options[mappedModel] = selected;
        } else {
            data.options[mappedModel] = [];
        }
        let result = {};
        if (!this.geneOfInterestData.options.goi && !this.geneOfInterestData.options.chrom
            && !this.geneOfInterestData.options.varient_type) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    filterChangedOptions(filterName, value) {
        const data = this.dataTemplate();
        data.options[filterName] = value;
        let result = {};
        if (!this.geneOfInterestData.options.goi && !this.geneOfInterestData.options.chrom
            && !this.geneOfInterestData.options.varient_type) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    _optionsFilterChanged(modelName, fieldName) {
        const data = this.dataTemplate();
        const field = this[fieldName].value;

        const selected = field.filter(f => f.check).map(f => f.type);
        data.options[modelName] = selected;
        let result = {};
        if (!this.geneOfInterestData.options.goi && !this.geneOfInterestData.options.chrom
            && !this.geneOfInterestData.options.varient_type) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }

    filterNameChanged() {
        const data = this.dataTemplate();
        let result = {};
        if (!this.geneOfInterestData.options.goi && !this.geneOfInterestData.options.chrom
            && !this.geneOfInterestData.options.varient_type) {
            result = {
                name: this.filterName,
                options: null
            };
        } else {
            result = data;
        }
        this.filterChanged.emit(result);
    }
}
