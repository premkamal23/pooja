import { IGOIData } from './vtValue.interface';

export const variantTypeData: IGOIData = {
    key: 'varient_type',
    value: [
        {
            type: 'SNV',
            check: false
        },
        {
            type: 'MNV',
            check: false
        },
        {
            type: 'InDel',
            check: false
        }
    ]
};
