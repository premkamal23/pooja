import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { ProjectService } from '../../common/services/project.service';

export interface AnalysisData {
  client_id: number;
  owner: string;
}

@Component({
  selector: 'app-change-of-custody',
  templateUrl: './change-of-custody.component.html',
  styleUrls: ['./change-of-custody.component.css']
})
export class ChangeOfCustodyComponent extends DialogComponent<AnalysisData, any> implements AnalysisData, OnInit {

  client_id: number;
  owner: string;
  client_array = [];
  new_client: string;
  error_msg: string;
  error_boolean = false;
  logged_user: string;
  approvePermissions: boolean;

  constructor(
    dialogService: DialogService,
    private service: ProjectService
  ) {
    super(dialogService);
  }

  ngOnInit() {
    const permissions = sessionStorage.getItem('permissions').split(',');
    this.approvePermissions = permissions.includes('CHANGE_CUSTODY') ? true : false;
    this.logged_user = sessionStorage.getItem('user');
    this.getAllUsersForClient();
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  getAllUsersForClient() {
    this.service.getUsersForClient(this.client_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.client_array = response.data;
    });
  }

  ChangeCustody() {
    const client = this.new_client.split('^');
    if (this.owner !== this.logged_user) {
      if (!this.approvePermissions) {
        this.error_msg = 'The user must be the owner of analysis or possess Change of custody permission to continue with this action.';
        this.error_boolean = true;
      } else {
        this.result = {
          'ownerName': client[0],
          'email': client[1]
        }
        this.close();
      }
    } else {
      this.result = {
        'ownerName': client[0],
        'email': client[1]
      }
      this.close();
    }
  }

}
