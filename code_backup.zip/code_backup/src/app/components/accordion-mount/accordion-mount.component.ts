import {
  Input,
  OnInit,
  Output,
  ViewChild,
  Component,
  EventEmitter,
  ViewContainerRef,
  ComponentFactoryResolver
} from '@angular/core';

@Component({
  selector: 'app-accordion-mount',
  templateUrl: './accordion-mount.component.html',
  styleUrls: ['./accordion-mount.component.css']
})
export class AccordionMountComponent implements OnInit {
  @Input('componentData')
  componentData: any;

  @Output('filterChanged')
  filterChanged: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('container', { read: ViewContainerRef })
  container: ViewContainerRef;

  childComponent: any;

  constructor(private componentFactoryResolver: ComponentFactoryResolver) {
    console.clear();
  }

  ngOnInit() {
    const { component, inputs, outputs } = this.componentData;
    const childComponent = this.componentFactoryResolver.resolveComponentFactory(component);
    const componentInstance = this.container.createComponent(childComponent);

    inputs.forEach(i => {
      componentInstance.instance[i.name] = i.value;
    });

    outputs.forEach(o => {
      componentInstance.instance[o.name] = o.value;
    });
  }

  emitData(data) {

  }

  
}
