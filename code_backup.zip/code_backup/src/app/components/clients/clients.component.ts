import { Component, OnInit } from '@angular/core';
import { DialogService } from 'ng2-bootstrap-modal';
import { ClientDialogComponent } from '../client-dialog/client-dialog.component';
import { UserManagementService } from '../../common/services/user-management.service';
declare var $: any;

@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css']
})
export class ClientsComponent implements OnInit {

  Gridcontent: any;
  apiResponse: any;
  totalRecords: any;
  client_id: number;
  name: string;
  alertMessage: string;
  folderNames = [];
  active: boolean;
  offset = 0;
  limit = 10;
  sortBy = 'name';
  sortDir = 'asc';
  firstRecord: number;
  notes_edit = false;
  invalid_notes = false;
  clientDetails = {
    name: this.name,
    folderNames: this.folderNames,
    isEdit: false,
    active: this.active
  };
  activeMapper: any = {
    true: 'Active',
    false: 'Deactivated'
  };

  constructor(
    private service: UserManagementService,
    private dialogService: DialogService
  ) { }

  ngOnInit() {
    this.getAllClients();
  }

  getAllClients() {
    this.service.getAllClientsPages(this.sortBy, this.sortDir, this.offset, this.limit).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.apiResponse = response.data.content.map(r => {
        r.status = this.activeMapper[r.active];
        return r;
      });
      this.totalRecords = response.data.totalElements;
      this.Gridcontent = [...this.apiResponse];
    });
  }

  deleteClient(event) {
    this.client_id = event.id;
    $('#removeClient').modal('toggle');
  }

  deleteSelectedClient() {
    this.service.deleteClient(this.client_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.getAllClients();
    });
  }

  addClient() {
    if (!this.notes_edit) {
      let newobj: any = {};
      this.clientDetails = newobj;
    } else {
      this.clientDetails.folderNames = this.folderNames;
      this.clientDetails.name = this.name;
    }
    const disposable = this.dialogService.addDialog(ClientDialogComponent, this.clientDetails);
    disposable.subscribe((response: any) => {
      if (response !== false) {
        this.name = response.name;
        this.folderNames = response.folders;
        this.service.createClient(response.name, response.folders).
          subscribe((data: any) => {
            const authToken = data.token;
            if (data.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.notes_edit = false;
            this.invalid_notes = false;
            this.getAllClients();
            this.alertMessage = data.data;
            $('#alert').modal('toggle');
          }, (err) => {
            this.invalid_notes = true;
            this.alertMessage = err.error.data;
            $('#alert').modal('toggle');
          });
      }
      else {
        this.notes_edit = false;
        this.invalid_notes = false;
        this.getAllClients();
      }
    });
  }

  editClient(event) {
    this.clientDetails.name = event.name;
    this.client_id = event.id;
    this.clientDetails.folderNames = event.folderNames;
    this.clientDetails.isEdit = true;
    this.clientDetails.active = event.active;
    const disposable = this.dialogService.addDialog(ClientDialogComponent, this.clientDetails);
    disposable.subscribe((response: any) => {
      if (response !== false) {
        this.service.editClient(this.client_id, response.name, response.folders, response.active).subscribe((data: any) => {
          const authToken = data.token;
          if (data.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.getAllClients();
        });
      }
    });
  }

  lazyLoadData(event) {
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = event.first / event.rows;
    this.firstRecord = event.first;
    this.sortBy = event.sortField ? event.sortField : 'name';
    this.sortDir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    if (key.length !== 0) {
      this.service.getAllClientsSearch(this.sortBy, this.sortDir, this.offset, this.limit, event.filters.name.value)
        .subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.apiResponse = response.data.content.map(r => {
            r.status = this.activeMapper[r.active];
            return r;
          });
          this.totalRecords = response.data.totalElements;
          this.Gridcontent = [...this.apiResponse];
        });
    } else {
      this.getAllClients();
    }
  }

}
