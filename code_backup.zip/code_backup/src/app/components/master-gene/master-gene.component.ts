import { Component, OnInit } from '@angular/core';
import { MasterTablesService } from '../../common/services/master-tables.service';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-master-gene',
  templateUrl: './master-gene.component.html',
  styleUrls: ['./master-gene.component.css']
})
export class MasterGeneComponent implements OnInit {

  selectedRow: any;
  gridContent: any;
  apiResponse: any;
  totalRecords: number;
  firstRecord = 0;
  column_name = 'gene';
  filters: any;
  sort = 'asc';
  offset = 0;
  limit = 15;
  acmgFlag = false;
  gene_boolean = false;
  gene_name: any;
  sub: any;
  lowerPanelContentLength: number;
  lowerPanelContent: any;
  constructor(
    private service: MasterTablesService,
    private router: Router,
    private routes: ActivatedRoute,
    private dashboard: DashboardComponent
  ) { }

  ngOnInit() {
  }

  onRowClick(event) {
    this.acmgFlag = true;
    const gene = event.data.gene;
    this.getGeneDetails();
  }

  getLowerPanel() {
    if (this.selectedRow) {
      this.getGeneDetails();
    }
  }

  getGeneData() {
    this.service.getGeneData(this.column_name, this.sort, this.offset, this.limit).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.gene_boolean = false;
      this.apiResponse = response.data.content;
      this.selectedRow = response.data.content[0];
      this.getLowerPanel();
      this.totalRecords = response.data.totalElements;
      this.gridContent = [...this.apiResponse];
    });
  }

  getGeneByVariant() {
    this.service.getGeneByVariant(this.gene_name).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.gene_boolean = true;
      let responseArray = [];
      this.selectedRow = response.data;
      this.getLowerPanel();
      responseArray = responseArray.concat(response.data);
      this.totalRecords = responseArray.length;
      this.gridContent = responseArray;
    });
  }

  paginate(event) {
    this.firstRecord = event.first;
    this.offset = event.first / event.rows;
    this.limit = event.rows;
    if (this.filters) {
      this.service.getFilteredGeneData(this.column_name, this.sort, this.offset, this.limit, this.filters)
        .subscribe((response: any) => {
          const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          this.apiResponse = response.data.content;
          this.selectedRow = response.data.content[0];
          this.getLowerPanel();
          this.totalRecords = response.data.totalElements;
          this.gridContent = [...this.apiResponse];
        });
    } else {
      this.getGeneData();
    }
  }

  lazyLoadData(event) {
    this.sub = this.routes
      .queryParams
      .subscribe(params => {
        this.gene_name = params.gene;
      });
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = 0;
    this.firstRecord = event.first;
    this.column_name = event.sortField ? event.sortField : 'gene';
    this.sort = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    this.filters = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});
    if (this.gene_name) {
      this.getGeneByVariant();
    } else {
      if (key.length !== 0) {
        this.service.getFilteredGeneData(this.column_name, this.sort, this.offset, this.limit, this.filters)
          .subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.apiResponse = response.data.content;
            this.selectedRow = response.data.content[0];
            this.getLowerPanel();
            this.totalRecords = response.data.totalElements;
            this.gridContent = [...this.apiResponse];
          });
      } else {
        this.getGeneData();
      }
    }

  }

  refresh() {
    this.router.navigate(['app/master-gene']);
    this.getGeneData();
  }

  getVariantData(event) {
    this.dashboard.getSpecificMasterVariantBoard(event);
  }

  getColor(element, dataitem, type) {
    switch (type) {

      case 'coverage_color':
        if (dataitem[type] === 'gray') {
          element.parentNode.parentNode.style.background = 'darkgrey';
        }
        break;
      case 'gnomad_high_freq_color':
        if (dataitem[type] === 'pink') {
          element.parentNode.parentNode.style.background = 'lightpink';
        }
        break;
    }
  }

  start = 0;
  firstRecordForOtherGrid = 0;
  sortBy = 'chrom';
  sortDir = 'asc';
  filterPayload = {};

  otherAnalysisData(event) {
    if (this.selectedRow) {
      const sortOrderMapper = {
        '1': 'asc',
        '-1': 'desc'
      };
      this.start = event.first / event.rows;
      this.firstRecord = event.first;
      this.sortBy = event.sortField ? event.sortField : 'chrom';
      this.sortDir = sortOrderMapper[event.sortOrder];
      const key = Object.keys(event.filters);
      const filters = key.reduce((f, c) => {
        f[c] = event.filters[c].value;
        return f;
      }, {});
      this.filterPayload = filters ? filters : {};
      this.getGeneDetails();
    }
  }

  getGeneDetails() {
    const gene = this.selectedRow.gene;
    if (gene !== '') {
      this.service.getVariantByGene(gene, this.sortBy, this.sortDir, this.start, 10, this.filterPayload).subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.lowerPanelContentLength = response.data.totalElements;
        this.lowerPanelContent = response.data.content;
      });
    }
  }

}
