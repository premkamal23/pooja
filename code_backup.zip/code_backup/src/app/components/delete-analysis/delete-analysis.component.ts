import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { ProjectService } from '../../common/services/project.service';

export interface idData {
  analysis_id: number;
  analysis_name: string;
}

@Component({
  selector: 'app-delete-analysis',
  templateUrl: './delete-analysis.component.html',
  styleUrls: ['./delete-analysis.component.css']
})
export class DeleteAnalysisComponent extends DialogComponent<idData, any> implements idData, OnInit {

  analysis_id: number;
  analysis_name: string;
  error_msg: string;
  error_boolean = false;
  deleteProgress = false;

  constructor(
    dialogService: DialogService
  ) {
    super(dialogService);
  }

  ngOnInit() {
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  deleteAnalysis() {
    this.deleteProgress = true;
    this.result = true;
    this.close();
  }

}
