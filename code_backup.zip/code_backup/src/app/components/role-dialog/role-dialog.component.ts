import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { UserManagementService } from '../../common/services/user-management.service';

export interface ConfirmModel {
  name: string;
  permission_ids: Array<any>;
}

@Component({
  selector: 'app-role-dialog',
  templateUrl: './role-dialog.component.html',
  styleUrls: ['./role-dialog.component.css']
})

export class RoleDialogComponent extends DialogComponent<ConfirmModel, any> implements ConfirmModel, OnInit {
  title: string;
  message: string;
  permissions: any;
  permission_list = [];
  name = '';
  permission_ids: Array<any>;
  errorList: Array<any>;
  constructor(
    dialogService: DialogService,
    private userService: UserManagementService
  ) {
    super(dialogService);
  }

  ngOnInit() {
    this.clearError();
    this.getAllPermissions();
    if (this.permission_ids) {
      this.permission_list = this.permission_ids;
    }
  }

  confirm() {
    this.result = true;
    this.close();
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  getAllPermissions() {
    this.userService.getAllpermissions().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.permissions = response.data;
    });
  }

  setData(value) {
    if (value.target.checked) {
      this.permission_list.push(Number(value.target.value));
    } else {
      for (let i = 0; i < this.permission_list.length; i++) {
        if (this.permission_list[i] === Number(value.target.value)) {
          this.permission_list.splice(i, 1);
          break;
        }
      }
    }
  }

  getRoleDetails() {
    this.clearError();
    if (this.name === '') {
      this.errorList.push('Please enter Role Name');
    }
    if (this.permission_list.length === 0) {
      this.errorList.push('Please select atlease one permission before saving');
    }
    if (this.errorList.length > 0) {

    } else {
      this.result = {
        name: this.name,
        permission_list: this.permission_list
      };
      this.close();
    }
  }

  clearError() {
    this.errorList = [];
  }


}
