import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { BAData } from './baData';
import { BPData } from './bpData';
import { BSData } from './bsData';
import { PMData } from './pmData';
import { PSData } from './psData';
import { PPData } from './ppData';
import { PVSData } from './pvsData';

export interface ACMGData {
  acmgData: any;
}

@Component({
  selector: 'app-acmg-calculator',
  templateUrl: './acmg-calculator.component.html',
  styleUrls: ['./acmg-calculator.component.css']
})
export class AcmgCalculatorComponent extends DialogComponent<ACMGData, any> implements ACMGData, OnInit {
  acmgData: any;
  data: Array<any> = [
    {
      name: 'pvsData',
      value: PVSData,
      color: 'red'
    },
    {
      name: 'psData',
      value: PSData,
      color: 'red'
    },
    {
      name: 'pmData',
      value: PMData,
      color: 'yellow'
    },
    {
      name: 'ppData',
      value: PPData,
      color: 'green'
    },
    {
      name: 'baData',
      value: BAData,
      color: 'mediumpurple'
    },
    {
      name: 'bsData',
      value: BSData,
      color: 'red'
    },
    {
      name: 'bpData',
      value: BPData,
      color: 'green'
    }
  ];
  ACMGOutput = this.data.reduce((f, c) => {
    c.value.value.forEach(v => {
      f[v.type.toLowerCase()] = v.check;
    });
    return f;
  }, {});
  
  constructor(dialogService: DialogService) {
    super(dialogService);
  }

  ngOnInit() {
    this.ACMGOutput = this.acmgData ? this.acmgData : {};
  }

  resetAcmgCalc() {
    this.ACMGOutput = this.data.reduce((f, c) => {
      c.value.value.forEach(v => {
        f[v.type.toLowerCase()] = v.check = false;
      });
      return f;
    }, {});

  }

  closeModal() {
    this.result = false;
    this.close();
  }
  getAcmgCalculation() {
    this.result = this.ACMGOutput;
    this.close();
  }


}
