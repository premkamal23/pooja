export const PPData = {
    key: 'PP',
    value: [
        {
            type: 'PP1',
            check: false,
            title:  `Cosegregation with disease in multiple affected family members in a gene
                   definitively known to cause the disease`
        },
        {
            type: 'PP2',
            check: false,
            title:  `Missense variant in a gene that has a low rate of benign missense variation
                   and in which missense variants are a common mechanism of disease`
        },
        {
            type: 'PP3',
            check: false,
            title:  `Multiple lines of computational evidence support a deleterious effect on
                   the gene or gene product (conservation, evolutionary, splicing impact, etc.)`
        },
        {
            type: 'PP4',
            check: false,
            title:  `Patient’s phenotype or family history is highly specific for a disease
                   with a single genetic etiology`
        },
        {
            type: 'PP5',
            check: false,
            title:  `Reputable source recently reports variant as pathogenic, but the evidence
                   is not available to the laboratory to perform an independent evaluation`
        }
    ]
};
