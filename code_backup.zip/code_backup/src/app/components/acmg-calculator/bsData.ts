export const BSData = {
    key: 'BS',
    value: [
        {
            type: 'BS1',
            check: false,
            title:  `Allele frequency is greater than expected for disorder`
        },
        {
            type: 'BS2',
            check: false,
            title:  `Observed in a healthy adult individual for a recessive (homozygous), dominant
                    (heterozygous), or X-linked (hemizygous) disorder, with full penetrance expected at an early age`
        },
        {
            type: 'BS3',
            check: false,
            title:  `Well-established in vitro or in vivo functional studies show no damaging effect on
                    protein function or splicing`
        },
        {
            type: 'BS4',
            check: false,
            title:  `Lack of segregation in affected members of a family`
        }
    ]
};
