export const PSData = {
    key: 'PS',
    value: [
        {
            type: 'PS1',
            check: false,
            title:  `Same amino acid change as a previously established pathogenic variant
                    regardless of nucleotide change `
        },
        {
            type: 'PS2',
            check: false,
            title:  `De novo (both maternity and paternity confirmed) in a patient
                   with the disease and no family history `
        },
        {
            type: 'PS3',
            check: false,
            title:  `Well-established in vitro or in vivo functional studies supportive of a
                   damaging effect on the gene or gene product  `
        },
        {
            type: 'PS4',
            check: false,
            title:  `The prevalence of the variant in affected individuals is significantly
                    increased compared with the prevalence in controls `
        }
    ]
};
