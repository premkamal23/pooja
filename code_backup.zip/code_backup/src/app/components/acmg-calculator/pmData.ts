export const PMData = {
    key: 'PM',
    value: [
        {
            type: 'PM1',
            check: false,
            title:  `Located in a mutational hot spot and/or critical and well-established
                    functional domain (e.g., active site of an enzyme) without benign variation `
        },
        {
            type: 'PM2',
            check: false,
            title:  `Absent from controls (or at extremely low frequency if recessive)
                    (Table 6) in Exome Sequencing Project, 1000 Genomes Project, or Exome Aggregation Consortium  `
        },
        {
            type: 'PM3',
            check: false,
            title:  `For recessive disorders, detected in trans with a pathogenic variant  `
        },
        {
            type: 'PM4',
            check: false,
            title:  `Protein length changes as a result of in-frame deletions/insertions in
                    a nonrepeat region or stop-loss variants  `
        },
        {
            type: 'PM5',
            check: false,
            title:  `Novel missense change at an amino acid residue where a different missense
                   change determined to be pathogenic has been seen before `
        },
        {
            type: 'PM6',
            check: false,
            title:  `Assumed de novo, but without confirmation of paternity and maternity  `
        }
    ]
};
