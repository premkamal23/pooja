export const BAData = {
    key: 'BA',
    value: [
        {
            type: 'BA1',
            check: false,
            title:  `Allele frequency is >5% in Exome Sequencing Project, 1000 Genomes Project,
                    or Exome Aggregation Consortium`
        }
    ]
};
