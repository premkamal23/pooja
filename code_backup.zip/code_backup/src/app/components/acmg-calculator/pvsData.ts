
export const PVSData = {
    key: 'PVS',
    value: [
        {
            type: 'PVS1',
            check: false,
            title:  `null variant (nonsense,
            frameshift, canonical
             ±1 or 2 splice sites,initiation
              codon,single or multiexon
              deletion) in a gene where LOF
               is a known mechanism of disease`
        }
    ]
};
