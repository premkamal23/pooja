export const BPData = {
    key: 'BP',
    value: [
        {
            type: 'BP1',
            check: false,
            title:  `Missense variant in a gene for which primarily truncating variants are known
                   to cause disease`
        },
        {
            type: 'BP2',
            check: false,
            title:  `Observed in trans with a pathogenic variant for a fully penetrant dominant
                   gene/disorder or observed in cis with a pathogenic variant in any inheritance pattern`
        },
        {
            type: 'BP3',
            check: false,
            title:  `In-frame deletions/insertions in a repetitive region without a known function`
        },
        {
            type: 'BP4',
            check: false,
            title:  `Multiple lines of computational evidence suggest no impact on gene or gene product
                   (conservation, evolutionary, splicing impact, etc.)`
        },
        {
            type: 'BP5',
            check: false,
            title:  `Variant found in a case with an alternate molecular basis for disease`
        },
        {
            type: 'BP6',
            check: false,
            title:  `Reputable source recently reports variant as benign, but the evidence is not available
                   to the laboratory to perform an independent evaluation`
        },
        {
            type: 'BP7',
            check: false,
            title:  `A synonymous (silent) variant for which splicing prediction algorithms predict no impact
                    to the splice consensus sequence nor the creation of a new splice site AND the nucleotide is not
                     highly conserved`
        }
    ]
};
