import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { ProjectService } from '../../common/services/project.service';
export interface commentsData {
  status: string;
}
@Component({
  selector: 'edit-status',
  templateUrl: './edit-status.component.html',
  styleUrls: ['./edit-status.component.css']
})
export class EditStatusComponent extends DialogComponent<commentsData, any> implements commentsData, OnInit {

  status: string;
  new_status: string;
  status_list: any;

  constructor(
    dialogService: DialogService,
    private service: ProjectService
  ) {
    super(dialogService);
  }

  ngOnInit() {
    this.getstatusList();
  }

  getstatusList() {
    this.service.getStatusList().subscribe((response: any) => {
      const authToken = response.token;
      if (authToken !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.status_list = response.data;
    });
  }

  editStatus() {
    this.result = {
      status: this.new_status
    }
    this.close();
  }

  closeModal() {
    this.result = false;
    this.close();
  }
}

