import { Component, OnInit } from '@angular/core';
import { DialogService } from 'ng2-bootstrap-modal';
import { ClinicalNotesDialogComponent } from '../clinical-notes-dialog/clinical-notes-dialog.component';
import { ClinicalNotesService } from '../../common/services/clinical-notes.service';
declare var $: any;

@Component({
  selector: 'clinical-notes',
  templateUrl: './clinical-notes.component.html',
  styleUrls: ['./clinical-notes.component.css']
})
export class ClinicalNotesComponent implements OnInit {
  offset = 0;
  limit = 10;
  sortBy = 'created_on';
  sortDir = 'asc';
  firstRecord: number;
  filterPayload = {};
  gridContent: any;
  totalRecords: any;
  description: string;
  id: string;
  created_by: any;
  modified_by: any;
  alertMessage: string;
  delete_msg: string;
  report_id: string;
  clinicalNotesDetails = {
    'id': this.id,
    'description': this.description,
    'isEdit': false,
    'created_by': this.created_by,
    'modified_by': this.modified_by
  };

  result = {
    id: this.id,
    description: this.description,
    created_by: null,
    modified_by: null
  }
  user: any;
  exist_flag = false;

  constructor(
    private dialogService: DialogService,
    private service: ClinicalNotesService) { }

  ngOnInit() {
    this.user = sessionStorage.getItem('user');
  }

  lazyLoadData(event) {
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = event.first / event.rows;
    this.firstRecord = event.first;
    this.sortBy = event.sortField ? event.sortField : 'created_on';
    this.sortDir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    const filters = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});
    this.filterPayload = filters ? filters : {};
    this.getClinicalNotes();
  }


  addNewNote() {
    let newobj: any = {};
    this.clinicalNotesDetails = newobj;
    this.clinicalNotesDetails.isEdit = false;
    this.dialogService.addDialog(ClinicalNotesDialogComponent, this.clinicalNotesDetails).subscribe((response: any) => {
      if (response !== false) {
        this.result.id = response.id;
        this.result.description = response.description;
        this.result.created_by = sessionStorage.getItem('user');
        this.addToList();
      } else {
        let newobj: any = {};
        this.clinicalNotesDetails = newobj;
        this.getClinicalNotes();
      }
    });
  }

  addToList() {
    this.service.saveClinicalNotes(this.result, this.exist_flag).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.getClinicalNotes();
      this.alertMessage = data.data;
      $('#success').modal('toggle');
      this.exist_flag = false;
    }, (err) => {
      this.alertMessage = err.error.data;
      $('#alert').modal('toggle');
      this.exist_flag = typeof (err.error.data) == 'string' ? true : false;
    });
  }

  getClinicalNotes() {
    this.service.getAllClinicalNotes(this.sortBy, this.sortDir, this.offset, this.limit, this.filterPayload).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.gridContent = [...response.data.clinicalNotes.content];
      this.totalRecords = response.data.totalCount;
    });
  }

  editNotes(event) {
    this.clinicalNotesDetails.id = event.id;
    this.clinicalNotesDetails.description = event.description;
    this.clinicalNotesDetails.isEdit = true;
    const disposable = this.dialogService.addDialog(ClinicalNotesDialogComponent, this.clinicalNotesDetails);
    disposable.subscribe((Response: any) => {
      if (Response !== false) {
        this.result.id = Response.id;
        this.result.description = Response.description;
        this.result.created_by = event.created_by;
        this.result.modified_by = sessionStorage.getItem('user');
        this.editToList();
      } else {
        this.clinicalNotesDetails.isEdit = Response.isEdit;
      }
    });
  }

  editToList() {
    this.service.editClinicalNotes(this.result, this.exist_flag).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.getClinicalNotes();
      this.alertMessage = data.data;
      $('#success').modal('toggle');
      this.exist_flag = false;
    }, (err) => {
      this.alertMessage = err.error.data;
      $('#alertEdit').modal('toggle');
      this.exist_flag = typeof (err.error.data) == 'string' ? true : false;
    });
  }

  deleteReportTemplate(event) {
    this.report_id = event.id;
    this.delete_msg = 'Are you sure you want to delete this note?'
    $('#deleteUser').modal('toggle');
  }

  deleteSelectedNotes() {
    this.service.deleteClinicalNotes(this.report_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.getClinicalNotes();
    },
      (err) => {
        this.alertMessage = err.error.data;
        $('#alert').modal('toggle');
        setTimeout(function () {
          $('#alert').modal('hide');
        }, 4000);
      });
  }
}
