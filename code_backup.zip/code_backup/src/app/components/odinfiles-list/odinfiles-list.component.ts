import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { ProjectService } from '../../common/services/project.service';

export interface ClientDetails {
  client: number;
  vcf: boolean;
  type: string;
}

@Component({
  selector: 'app-odinfiles-list',
  templateUrl: './odinfiles-list.component.html',
  styleUrls: ['./odinfiles-list.component.css']
})
export class OdinfilesListComponent extends DialogComponent<ClientDetails, any> implements ClientDetails, OnInit {

  client: number;
  vcf = true;
  totalRecords: number;
  gridContent: any;
  type: string;
  fileSelected: any;
  offset: number;
  firstRecord: number;
  limit = 10;
  filterPayload: any;
  sortBy = 'name';
  sortDir = 'asc';

  constructor(
    dialogService: DialogService,
    private projectService: ProjectService
  ) {
    super(dialogService);
  }

  ngOnInit() {
  }

  getOdinFiles() {
    this.projectService.getfileData(this.client, this.vcf, this.offset, this.limit, this.sortBy, this.sortDir, this.filterPayload)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.totalRecords = response.data.totalCount;
        this.gridContent = [...response.data.samples];
      });
  }

  filesSelected(event) {
    this.fileSelected = event.data;
  }

  setSelectedFile() {
    this.result = {
      name: this.fileSelected.name,
      fq_name: this.fileSelected.fq_name,
      path: this.fileSelected.path,
      type: this.type
    };
    this.close();
  }

  closeModal() {
    this.result = false;
    this.close();
  }

  lazyLoadData(event) {
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = event.first / event.rows;
    this.firstRecord = event.first;
    this.sortBy = event.sortField ? event.sortField : 'name';
    this.sortDir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    const filters = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});
    this.filterPayload = filters ? filters : {};
    this.getOdinFiles();
  }

  loadFiles() {
    this.offset = 0;
    this.projectService.getRefreshedFileData(this.client, this.vcf, this.offset, this.limit, this.sortBy, this.sortDir)
      .subscribe((response: any) => {
        const authToken = response.token;
        if (response.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.totalRecords = response.data.totalCount;
        this.gridContent = [...response.data.samples];
      });
  }

}
