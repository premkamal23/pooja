import { Component, OnInit } from '@angular/core';
import { DialogService } from 'ng2-bootstrap-modal';
import { UserDialogComponent } from '../user-dialog/user-dialog.component';
import { ResetPasswordComponent } from '../reset-password/reset-password.component';
import { UserManagementService } from '../../common/services/user-management.service';
declare var $: any;

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  first_name: string;
  last_name: string;
  email: string;
  role: number;
  password: string;
  passwordMsg: string;
  confirmPassword: string;
  designation: string;
  user_id: number;
  active: boolean;
  client_ids = [];
  filterPayload = {};
  offset = 0;
  limit = 10;
  sortBy = 'first_name';
  sortDir = 'asc';
  firstRecord: number;
  alertMessage: string;
  invalid_email = false;
  delete_msg: string;
  error_msg: string;
  ClientData: any = {
    'first_name': this.first_name,
    'last_name': this.last_name,
    'email': this.email,
    'role': this.role,
    'password': this.password,
    'confirmPassword': this.confirmPassword,
    'isEdit': false,
    'user': this.user_id,
    'active': this.active,
    'client_ids': this.client_ids
  };
  resetPasswordData: any = {
    'user': this.user_id,
    'loc': 'user_management'
  };
  activeMapper: any = {
    true: 'Active',
    false: 'Deactivated'
  };
  client_list: any;
  Gridcontent: any;
  apiResponse: any;
  totalRecords: number;
  constructor(
    private dialogService: DialogService,
    private userService: UserManagementService) { }
  ngOnInit() {
  }

  addNewUser() {
    if (!this.invalid_email) {
      this.ClientData = {
        'first_name': null,
        'last_name': null,
        'email': null,
        'role': null,
        'password': null,
        'confirmPassword': null,
        'isEdit': false,
        'user': null,
        'active': null,
        'client_ids': null
      };
    } else {
      this.ClientData.first_name = this.first_name;
      this.ClientData.last_name = this.last_name;
      this.ClientData.email = this.email;
      this.ClientData.role = this.role;
      this.ClientData.designation = this.designation;
      this.ClientData.isEdit = false;
      this.ClientData.client_ids = this.client_ids;
    }
    const disposable = this.dialogService.addDialog(UserDialogComponent, this.ClientData);
    disposable.subscribe((response: any) => {
      if (response !== false) {
        this.first_name = response.first_name;
        this.last_name = response.last_name;
        this.email = response.email;
        this.role = response.role;
        this.password = response.password;
        this.confirmPassword = response.confirmPassword;
        this.designation = response.designation;
        this.client_ids = response.client_ids;
        this.userService.createUser(response.first_name, response.last_name, response.email,
          response.role, response.password, response.confirmPassword, response.designation, response.client_ids)
          .subscribe((data: any) => {
            const authToken = data.token;
            if (data.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.getUsersForClient();
            this.invalid_email = false;
          }, (err) => {
            this.alertMessage = err.error.data;
            $('#alert').modal('toggle');
          });
      } else {
        this.invalid_email = false;
        this.ClientData.isEdit = response.isEdit;
      }
    });
  }

  getUsersForClient() {
    this.userService.getAllUsers(this.offset, this.limit, this.sortBy, this.sortDir, this.filterPayload).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.userService.getAllRoles().subscribe((data: any) => {
        const authToken = data.token;
        if (data.token !== null) {
          sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
        } else { }
        this.userService.getAllClients().subscribe((clients: any) => {
          const authToken = clients.token;
          if (clients.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
          const statusMapper = {};
          data.data.content.forEach(d => {
            statusMapper[d.id] = d.name;
          });
          const clientMapper = {};
          clients.data.content.forEach(c => {
            clientMapper[c.id] = c.name;
          });
          this.apiResponse = response.data.users.map(r => {
            r.role_ids = statusMapper[r.role_id];
            r.role_name = statusMapper[r.role_id];
            if (r.client_ids) {
              r.clients = r.client_ids.map(client => {
                return clientMapper[client];
              });
            }
            r.status = this.activeMapper[r.active];
            return r;
          });
          this.totalRecords = response.data.totalCount;
          this.Gridcontent = [...this.apiResponse];
        });
      });
    });
  }

  onRowClick(event) {
  }

  editUser(event) {
    this.ClientData.user = event.id;
    this.ClientData.client = event.client_id;
    this.ClientData.first_name = event.first_name;
    this.ClientData.last_name = event.last_name;
    this.ClientData.email = event.email;
    this.ClientData.role = event.role_id;
    this.ClientData.designation = event.designation;
    this.ClientData.isEdit = true;
    this.ClientData.active = event.active;
    this.ClientData.client_ids = event.client_ids;
    const disposable = this.dialogService.addDialog(UserDialogComponent, this.ClientData);
    disposable.subscribe((Response: any) => {
      if (Response !== false) {
        this.userService.
          editUser(Response.user, Response.first_name, Response.last_name,
            Response.email, Response.role, Response.designation, Response.active, Response.client_ids).
          subscribe((response: any) => {
            const authToken = response.token;
            if (response.token !== null) {
              sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
            } else { }
            this.getUsersForClient();
          });
      } else {
        this.ClientData.isEdit = Response.isEdit;
      }
    });
  }

  deleteUser(event) {
    this.user_id = event.id;
    this.delete_msg = 'Are you sure you want to deactivate this User?'
    $('#deleteUser').modal('toggle');
  }

  deleteSelectedUser() {
    this.userService.deleteUSer(this.user_id).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.getUsersForClient();
    },
      (err) => {
        this.error_msg = err.error.data;
        $('#alert_error').modal('toggle');
        setTimeout(function () {
          $('#alert_error').modal('hide');
        }, 4000);
      });
  }

  resetPassword(event) {
    this.resetPasswordData.user = event.id;
    const disposable = this.dialogService.addDialog(ResetPasswordComponent, this.resetPasswordData);
    disposable.subscribe((response: any) => {
      if (response !== false) {
        this.passwordMsg = response;
        $('#resetPassword').modal('toggle');
      }
    });
  }

  lazyLoadData(event) {
    const sortOrderMapper = {
      '1': 'asc',
      '-1': 'desc'
    };
    this.offset = event.first / event.rows;
    this.firstRecord = event.first;
    this.sortBy = event.sortField ? event.sortField : 'first_name';
    this.sortDir = sortOrderMapper[event.sortOrder];
    const key = Object.keys(event.filters);
    const filters = key.reduce((f, c) => {
      f[c] = event.filters[c].value;
      return f;
    }, {});
    this.filterPayload = filters ? filters : {};
    this.getUsersForClient();
  }
}
