import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { OpenAnalysisService } from '../../common/services/open-analysis.service';
@Component({
  selector: 'app-drop-down-menu',
  templateUrl: './drop-down-menu.component.html',
  styleUrls: ['./drop-down-menu.component.css']
})
export class DropDownMenuComponent implements OnInit, OnChanges {
  @Input('filterName') filterName: string;
  @Input('dashboardData') dashboardData: any;
  @Input('globalFilters') globalFilters: any;

  currentOptions: any = {};
  apiEndPoint = '/api/refiningFilterCounts';
  url = '';
  counts: any;
  disableDropDown = false;
  constructor(private http: HttpClient, private openanalysisService: OpenAnalysisService) { }

  ngOnInit() {
    this.url = `${this.apiEndPoint}?analysis_id=${this.globalFilters.analysis_id_for_count}&gene_class=${this.globalFilters.gene_class}&location=${this.globalFilters.location}&sub_type=${this.globalFilters.sub_type}`;
  }

  ngOnChanges(changes) {
    if (changes.hasOwnProperty('filterName')) {
      this.filterName = changes.filterName.currentValue;
    } else if (changes.hasOwnProperty('dashboardData')) {
      this.dashboardData = changes.dashboardData.currentValue;
    }
    if (this.dashboardData && this.filterName && this.url !== '') {
      this.counts = [];
      this.currentOptions = this.dashboardData.find(c => c.name === this.filterName);

      if (this.currentOptions) {
        this.url = `${this.apiEndPoint}?analysis_id=${this.globalFilters.analysis_id_for_count}&gene_class=${this.globalFilters.gene_class}&location=${this.globalFilters.location}&sub_type=${this.globalFilters.sub_type}`;
        if(this.openanalysisService.checkIfIsEditFilter() && this.apiEndPoint.indexOf('refiningFilter?') !== -1) {
          this.http.put(this.url, this.currentOptions)
          .subscribe((response: any) => {
            const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
            this.counts = response.data;
          });
        }
        else {
          this.http.post(this.url, this.currentOptions)
          .subscribe((response: any) => {
            const authToken = response.token;
          if (response.token !== null) {
            sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
          } else { }
            this.counts = response.data;
          });
        }

      }
    }
  }
}
