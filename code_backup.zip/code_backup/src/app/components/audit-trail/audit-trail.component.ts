import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../../common/services/project.service';
import * as FileSaver from 'file-saver';
declare var $: any;

@Component({
  selector: 'app-audit-trail',
  templateUrl: './audit-trail.component.html',
  styleUrls: ['./audit-trail.component.css']
})
export class AuditTrailComponent implements OnInit {

  from_date = new Date(Date.now() - 864e5);
  to_date = new Date();

  from_Udate = new Date(Date.now() - 864e5);
  to_Udate = new Date();

  from_Vdate = new Date(Date.now() - 864e5);
  to_Vdate = new Date();

  from_Rdate = new Date(Date.now() - 864e5);
  to_Rdate = new Date();

  date = new Date();
  old_pki_classification: string = 'Any';
  new_pki_classification: string = 'Any';
  pki_class_list: any;
  user_list: any;
  userSelected: any;
  userforVariant: any;
  userforReport: any;
  result_obj = {
    fromDate: new Date(Date.now() - 864e5).getTime(),
    toDate: new Date().getTime(),
    old_pki_classification: this.old_pki_classification,
    new_pki_classification: this.new_pki_classification
  }

  user_audit_obj = {
    fromDate: new Date(Date.now() - 864e5).getTime(),
    toDate: new Date().getTime(),
    userName: 'Any',
    user_email: 'Any'
  };

  report_audit_obj = {
    fromDate: new Date(Date.now() - 864e5).getTime(),
    toDate: new Date().getTime(),
    userName: 'Any',
    user_email: 'Any'
  };

  variant_audit_obj = {
    from_date: new Date(Date.now() - 864e5).getTime(),
    to_date: new Date().getTime(),
    user_name: 'Any',
    user_email: 'Any'
  };
  selectedAnalysisName = '';
  constructor(
    private service: ProjectService
  ) {
  }

  ngOnInit() {
    this.getPkiClass();
    this.getAllUsers();
  }

  getPkiClass() {
    this.pki_class_list = [{ id: "Any", pki_classification_value: "Any" }]
    this.service.getPKIClass().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.pki_class_list = this.pki_class_list.concat(response.data.content);
    });
  }

  getAllUsers() {
    this.userSelected = 'All Users User/Email ID';
    this.userforVariant = 'All Users User/Email ID';
    this.userforReport = 'All Users User/Email ID';
    this.user_list = [{ first_name: "All Users", last_name: "User", email: "Email ID" }];
    this.service.getalluserforAudit().subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      this.user_list = this.user_list.concat(response.data);
    });
  }

  showDate(type) {
    this.result_obj[type] = type === 'fromDate' ? this.from_date.getTime() : this.to_date.getTime();
  }

  showDateForUser(type) {
    this.user_audit_obj[type] = type === 'fromDate' ? this.from_Udate.getTime() : this.to_Udate.getTime();
  }

  showDateForVariant(type) {
    this.variant_audit_obj[type] = type === 'from_date' ? this.from_Vdate.getTime() : this.to_Vdate.getTime();
  }

  showDateForReport(type) {
    this.report_audit_obj[type] = type === 'fromDate' ? this.from_Rdate.getTime() : this.to_Rdate.getTime();
  }

  getClass(value) {
    this.result_obj[value] = value === 'old_pki_classification' ? this.old_pki_classification : this.new_pki_classification;
  }

  getUser() {
    if (this.userSelected === 'All Users User/Email ID') {
      this.user_audit_obj.userName = 'Any';
      this.user_audit_obj.user_email = 'Any';
    } else {
      const user = this.userSelected.split('/');
      this.user_audit_obj.userName = user[0];
      this.user_audit_obj.user_email = user[1];
    }
  }

  getUserForVariant() {
    if (this.userforVariant === 'All Users User/Email ID') {
      this.variant_audit_obj.user_name = 'Any';
      this.variant_audit_obj.user_email = 'Any';
    } else {
      const user = this.userforVariant.split('/');
      this.variant_audit_obj.user_name = user[0];
      this.variant_audit_obj.user_email = user[1];
    }
  }

  getUserForReport() {
    if (this.userforReport === 'All Users User/Email ID') {
      this.report_audit_obj.userName = 'Any';
      this.report_audit_obj.user_email = 'Any';
    } else {
      const user = this.userforReport.split('/');
      this.report_audit_obj.userName = user[0];
      this.report_audit_obj.user_email = user[1];
    }
  }

  getAuditTrail() {
    if (this.result_obj.new_pki_classification.toLowerCase() === 'Reset Classification'.toLowerCase()) {
      this.result_obj.new_pki_classification = '';
    }
    if (this.result_obj.old_pki_classification.toLowerCase() === 'Reset Classification'.toLowerCase()) {
      this.result_obj.old_pki_classification = '';
    }
    this.service.getauditTrail(this.result_obj).subscribe((data: any) => {
      const authToken = data.token;
      if (data.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      const e_date = new Date();
      const end_date = e_date.getMonth() + 1 + '/' + e_date.getDate() + '/' + e_date.getFullYear();
      if (typeof data.data === 'string') {
        this.selectedAnalysisName = data.data;
        $('#deleteAnalysisContainer').modal('toggle');
        setTimeout(function () {
          $('#deleteAnalysisContainer').modal('hide');
        }, 4000);
      } else {
        data.data = data.data.map(response => {
          const date_variable = new Date(response.date_of_Modification)
          response.date_of_Modification = [date_variable.getMonth() + 1, date_variable.getDate(), date_variable.getFullYear()].join('/') + ' ' +
            [date_variable.getHours(), date_variable.getMinutes(), date_variable.getSeconds()].join(':');
          return response;
        });
        var arrData = typeof data.data != 'object' ? JSON.parse(data.data) : data.data;
        var CSV = 'sep=,' + '\r\n\n';
        var row = "";
        for (var index in arrData[0]) {
          row += index + ',';
        }
        row = row.slice(0, -1);
        CSV += row + '\r\n';
        for (var i = 0; i < arrData.length; i++) {
          var row = "";
          for (var index in arrData[i]) {
            row += '"' + arrData[i][index] + '",';
          }
          row.slice(0, row.length - 1);
          CSV += row + '\r\n';
        }
        var blob = new Blob([CSV], { type: "data:text/csv;charset=utf-8" });
        FileSaver.saveAs(blob, 'ClassificationChangeAuditReport(' + end_date + ').csv');
      }
    });
  }

  getUserAudit() {
    this.service.getUserAudit(this.user_audit_obj).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      const e_date = new Date();
      const end_date = e_date.getMonth() + 1 + '/' + e_date.getDate() + '/' + e_date.getFullYear();
      if (typeof response.data === 'string') {
        this.selectedAnalysisName = response.data;
        $('#deleteAnalysisContainer').modal('toggle');
        setTimeout(function () {
          $('#deleteAnalysisContainer').modal('hide');
        }, 4000);
      } else {
        response.data = response.data.map(response => {
          const logged_in = new Date(response.logged_In_Time)
          response.logged_In_Time = [logged_in.getMonth() + 1, logged_in.getDate(), logged_in.getFullYear()].join('/') + ' ' +
            [logged_in.getHours(), logged_in.getMinutes(), logged_in.getSeconds()].join(':');
          if (response.logged_Out_Time !== 0) {
            const logged_out = new Date(response.logged_Out_Time)
            response.logged_Out_Time = [logged_out.getMonth() + 1, logged_out.getDate(), logged_out.getFullYear()].join('/') + ' ' +
              [logged_out.getHours(), logged_out.getMinutes(), logged_out.getSeconds()].join(':');
          } else {
            response.logged_Out_Time = '';
          }
          return response;
        });
        var arrData = typeof response.data != 'object' ? JSON.parse(response.data) : response.data;
        var CSV = 'sep=,' + '\r\n\n';
        var row = "";
        for (var index in arrData[0]) {
          row += index + ',';
        }
        row = row.slice(0, -1);
        CSV += row + '\r\n';
        for (var i = 0; i < arrData.length; i++) {
          var row = "";
          for (var index in arrData[i]) {
            row += '"' + arrData[i][index] + '",';
          }
          row.slice(0, row.length - 1);
          CSV += row + '\r\n';
        }
        var blob = new Blob([CSV], { type: "data:text/csv;charset=utf-8" });
        FileSaver.saveAs(blob, 'UserSessionAuditReport(' + end_date + ').csv');
      }
    });
  }

  getVariantAudit() {
    this.service.getVariantAudit(this.variant_audit_obj).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      const e_date = new Date();
      const end_date = e_date.getMonth() + 1 + '/' + e_date.getDate() + '/' + e_date.getFullYear();
      if (typeof response.data === 'string') {
        this.selectedAnalysisName = response.data;
        $('#deleteAnalysisContainer').modal('toggle');
        setTimeout(function () {
          $('#deleteAnalysisContainer').modal('hide');
        }, 4000);
      } else {
        response.data = response.data.map(response => {
          const created = new Date(response.created_date)
          response.created_date = [created.getMonth() + 1, created.getDate(), created.getFullYear()].join('/') + ' ' +
            [created.getHours(), created.getMinutes(), created.getSeconds()].join(':');
          return response;
        });
        var arrData = typeof response.data != 'object' ? JSON.parse(response.data) : response.data;
        var CSV = 'sep=,' + '\r\n\n';
        var row = "";
        for (var index in arrData[0]) {
          row += index + ',';
        }
        row = row.slice(0, -1);
        CSV += row + '\r\n';
        for (var i = 0; i < arrData.length; i++) {
          var row = "";
          for (var index in arrData[i]) {
            row += '"' + arrData[i][index] + '",';
          }
          row.slice(0, row.length - 1);
          CSV += row + '\r\n';
        }
        var blob = new Blob([CSV], { type: "data:text/csv;charset=utf-8" });
        FileSaver.saveAs(blob, 'AddVariantAuditReport(' + end_date + ').csv');
      }
    });
  }

  getReportAudit() {
    this.service.getReportAudit(this.report_audit_obj).subscribe((response: any) => {
      const authToken = response.token;
      if (response.token !== null) {
        sessionStorage.setItem('Authorization', 'Bearer ' + authToken);
      } else { }
      const e_date = new Date();
      const end_date = e_date.getMonth() + 1 + '/' + e_date.getDate() + '/' + e_date.getFullYear();
      if (typeof response.data === 'string') {
        this.selectedAnalysisName = response.data;
        $('#deleteAnalysisContainer').modal('toggle');
        setTimeout(function () {
          $('#deleteAnalysisContainer').modal('hide');
        }, 4000);
      } else {
        response.data = response.data.map(response => {
          if (response.reportedDate !== 0) {
            const logged_out = new Date(response.reportedDate)
            response.reportedDate = [logged_out.getMonth() + 1, logged_out.getDate(), logged_out.getFullYear()].join('/') + ' ' +
              [logged_out.getHours(), logged_out.getMinutes(), logged_out.getSeconds()].join(':');
          } else {
            response.reportedDate = '';
          }
          return response;
        });
        var arrData = typeof response.data != 'object' ? JSON.parse(response.data) : response.data;
        var CSV = 'sep=,' + '\r\n\n';
        var row = "";
        for (var index in arrData[0]) {
          row += index + ',';
        }
        row = row.slice(0, -1);
        CSV += row + '\r\n';
        for (var i = 0; i < arrData.length; i++) {
          var row = "";
          for (var index in arrData[i]) {
            row += '"' + arrData[i][index] + '",';
          }
          row.slice(0, row.length - 1);
          CSV += row + '\r\n';
        }
        var blob = new Blob([CSV], { type: "data:text/csv;charset=utf-8" });
        FileSaver.saveAs(blob, 'AutoReportAudit(' + end_date + ').csv');
      }
    });
  }

}
