import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DynamicModule } from 'ng-dynamic-component';
import { RouterModule } from '@angular/router';
import { DataTableModule } from 'primeng/primeng';
import { TooltipModule } from 'primeng/primeng';
import { TreeTableModule } from 'primeng/treetable';
import { PaginatorModule } from 'primeng/primeng';
import { ButtonModule } from 'primeng/primeng';
import { CalendarModule } from 'primeng/primeng';
import { MultiSelectModule } from 'primeng/primeng';
import { MessageService } from 'primeng/components/common/messageservice';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BootstrapModalModule } from 'ng2-bootstrap-modal';
import { PopoverModule } from 'ngx-popover';
import { AuthenticationService } from './common/services/authentication.service';
import { OpenAnalysisService } from './common/services/open-analysis.service';
import { ProjectService } from './common/services/project.service';
import { AuthenticateService } from './common/services/authenticate.service';
import { AuthServiceService } from './common/services/auth-service.service';
import { AuthenticateGuardService } from './common/services/authenticate-guard.service';
import { UserManagementService } from './common/services/user-management.service';
import { ReportTemplateService } from './common/services/report-template.service';
import { MasterTablesService } from './common/services/master-tables.service';
import { ReportModuleService } from './common/services/report-module.service';
import { routes } from './app.routes';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccordionModule } from 'ng2-accordion';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { OpenAnalysisComponent } from './components/open-analysis/open-analysis.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ProcessAnalysisComponent } from './components/process-analysis/process-analysis.component';
import { NewAnalysisComponent } from './components/new-analysis/new-analysis.component';

import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonHttpInterceptor } from './common/common-http.intercepter';
import { ConfidenceComponent } from './components/confidence/confidence.component';
import { PopulationFrequenciesComponent } from './components/population-frequencies/population-frequencies.component';
import { ClinicalClassificationComponent } from './components/clinical-classification/clinical-classification.component';
import { PhenotypesComponent } from './components/phenotypes/phenotypes.component';
import { GenesOfInterestComponent } from './components/genes-of-interest/genes-of-interest.component';
import { DropDownMenuComponent } from './components/drop-down-menu/drop-down-menu.component';
import { ModalComponentComponent } from './components/modal-component/modal-component.component';
import { AddComponentDirective } from './directives/add-component.directive';
import { WindowRef } from './common/services/windowRef';
import { GeneListComponent } from './components/gene-list/gene-list.component';
import { ReportTemplateComponent } from './components/blue-report-page/report-template.component';
import { AccordionMountComponent } from './components/accordion-mount/accordion-mount.component';
import { NgxEditorModule } from 'ngx-editor';
import { UserManagementComponent } from './components/user-management/user-management.component';
import { MasterGeneComponent } from './components/master-gene/master-gene.component';
import { MasterVariantComponent } from './components/master-variant/master-variant.component';
import { RolesComponent } from './components/roles/roles.component';
import { UsersComponent } from './components/users/users.component';
import { UserDialogComponent } from './components/user-dialog/user-dialog.component';
import { RoleDialogComponent } from './components/role-dialog/role-dialog.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ClientsComponent } from './components/clients/clients.component';
import { ClientDialogComponent } from './components/client-dialog/client-dialog.component';
import { OdinfilesListComponent } from './components/odinfiles-list/odinfiles-list.component';
import { AcmgCalculatorComponent } from './components/acmg-calculator/acmg-calculator.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { GenelistDialogComponent } from './components/genelist-dialog/genelist-dialog.component';
import { ChangeOfCustodyComponent } from './components/change-of-custody/change-of-custody.component';
import { DeleteAnalysisComponent } from './components/delete-analysis/delete-analysis.component';
import { EditCommentsComponent } from './components/edit-comments/edit-comments.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { AuditTrailComponent } from './components/audit-trail/audit-trail.component';
import { CKEditorModule } from 'ng2-ckeditor';
import { ReportModuleComponent } from './components/blue-report-list/report-module.component';
import { NewReportingModuleComponent } from './components/new-blue-report-template/new-reporting-module.component';
import { ReportPreviewComponent } from './components/report-preview/report-preview.component';
import { LogoBrowseComponent } from './components/logo-list/logo-browse.component';
import { VariantsForSectionComponent } from './components/variants-for-section/variants-for-section.component';
import { TagInputModule } from 'ngx-chips';
import { TypeaheadModule } from 'ngx-bootstrap';
import { DropdownModule } from 'primeng/dropdown';
import { ClinicalNotesComponent } from './components/clinical-notes/clinical-notes.component';
import { MiscellaneousModuleComponent } from './components/miscellaneous-module/miscellaneous-module.component';
import { ClinicalNotesService } from './common/services/clinical-notes.service';
import { MedixcelService } from './common/services/medixcel.service';
import { ClinicalNotesDialogComponent } from './components/clinical-notes-dialog/clinical-notes-dialog.component';
import { MedixcelComponent } from './components/medixcel/medixcel.component';
import { EditClassificationComponent } from './components/edit-classification/edit-classification.component';
import { ClinicalReportComponent } from './components/clinical-report-template/clinical-report.component';
import { PurpleReportComponent } from './components/purple-report-list/purple-report.component';
import { NewPurpleReportComponent } from './components/new-purple-report-template/new-purple-report.component';
import { DevelopedPurpleReportComponent } from './components/purple-report-page/developed-purple-report.component';
import { FilterComponentComponent } from './components/analysis-filter-component/filter-component.component';
import { AddVariantMasterComponent } from './components/add-variant-master/add-variant-master.component';
import { AddVariantAnalysisComponent } from './components/add-variant-analysis/add-variant-analysis.component';
import { EditStatusComponent } from './components/edit-status/edit-status.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    OpenAnalysisComponent,
    DashboardComponent,
    ProcessAnalysisComponent,
    NewAnalysisComponent,
    ConfidenceComponent,
    PopulationFrequenciesComponent,
    ClinicalClassificationComponent,
    PhenotypesComponent,
    GenesOfInterestComponent,
    DropDownMenuComponent,
    ModalComponentComponent,
    AddComponentDirective,
    GeneListComponent,
    AccordionMountComponent,
    ReportTemplateComponent,
    UserManagementComponent,
    MasterGeneComponent,
    MasterVariantComponent,
    RolesComponent,
    UsersComponent,
    UserDialogComponent,
    RoleDialogComponent,
    ChangePasswordComponent,
    ClientsComponent,
    ClientDialogComponent,
    OdinfilesListComponent,
    AcmgCalculatorComponent,
    ResetPasswordComponent,
    GenelistDialogComponent,
    ChangeOfCustodyComponent,
    DeleteAnalysisComponent,
    EditCommentsComponent,
    AuditTrailComponent,
    ReportModuleComponent,
    NewReportingModuleComponent,
    ReportPreviewComponent,
    LogoBrowseComponent,
    VariantsForSectionComponent,
    ClinicalNotesComponent,
    MiscellaneousModuleComponent,
    ClinicalNotesDialogComponent,
    MedixcelComponent,
    EditClassificationComponent,
    ClinicalReportComponent,
    PurpleReportComponent,
    NewPurpleReportComponent,
    DevelopedPurpleReportComponent,
    FilterComponentComponent,
    AddVariantMasterComponent,
    AddVariantAnalysisComponent,
    EditStatusComponent,
  ],
  entryComponents: [
    EditStatusComponent,
    AddVariantAnalysisComponent,
    AddVariantMasterComponent,
    FilterComponentComponent,
    EditClassificationComponent,
    ClinicalNotesDialogComponent,
    VariantsForSectionComponent,
    LogoBrowseComponent,
    AuditTrailComponent,
    EditCommentsComponent,
    DeleteAnalysisComponent,
    ChangeOfCustodyComponent,
    GenelistDialogComponent,
    ResetPasswordComponent,
    AcmgCalculatorComponent,
    OdinfilesListComponent,
    ClientDialogComponent,
    ChangePasswordComponent,
    RoleDialogComponent,
    UserDialogComponent,
    ModalComponentComponent,
    ConfidenceComponent,
    PopulationFrequenciesComponent,
    ClinicalClassificationComponent,
    PhenotypesComponent,
    GenesOfInterestComponent
  ],
  imports: [
    TreeTableModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    PopoverModule,
    AccordionModule,
    BootstrapModalModule.forRoot({ container: document.body }),
    RouterModule.forRoot(routes, { useHash: true }),
    DataTableModule,
    TooltipModule,
    PaginatorModule,
    ButtonModule,
    CalendarModule,
    MultiSelectModule,
    DynamicModule.withComponents([
      ConfidenceComponent,
      PopulationFrequenciesComponent,
      ClinicalClassificationComponent,
      PhenotypesComponent,
      GenesOfInterestComponent
    ]),
    NgxEditorModule,
    NgMultiSelectDropDownModule.forRoot(),
    CKEditorModule,
    TagInputModule,
    TypeaheadModule.forRoot(),
    DropdownModule
  ],

  providers: [
    MasterTablesService,
    MedixcelService,
    AuthenticationService,
    OpenAnalysisService,
    ReportTemplateService,
    AuthenticateService,
    AuthServiceService,
    AuthenticateGuardService,
    MessageService,
    UserManagementService,
    ReportModuleService,
    ProjectService, {
      provide: HTTP_INTERCEPTORS,
      useClass: CommonHttpInterceptor,
      multi: true
    },
    ClinicalNotesService,
    WindowRef
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
