import { Routes } from '@angular/router';

import {
    LoginComponent,
    DashboardComponent,
    OpenAnalysisComponent,
    ProcessAnalysisComponent,
    NewAnalysisComponent,
    GeneListComponent,
    ReportTemplateComponent,
    UserManagementComponent,
    MasterGeneComponent,
    MasterVariantComponent,
    UsersComponent,
    RolesComponent,
    ClientsComponent,
    ReportModuleComponent,
    ClinicalNotesComponent,
    MiscellaneousModuleComponent,
    AuditTrailComponent,
    MedixcelComponent,
    ClinicalReportComponent,
    PurpleReportComponent,
    NewPurpleReportComponent,
    DevelopedPurpleReportComponent
} from './components';

import { AuthenticateGuardService } from './common/services/authenticate-guard.service';
import { AuthServiceService } from './common/services/auth-service.service';

export const routes: Routes = [
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    },
    {
        path: 'app',
        component: DashboardComponent,
        canActivate: [AuthenticateGuardService, AuthServiceService],
        children: [
            {
                path: 'open-analysis/:analysis_id',
                component: OpenAnalysisComponent
            },
            {
                path: 'new-analysis',
                component: NewAnalysisComponent
            },
            {
                path: 'miscellaneous',
                component: MiscellaneousModuleComponent,
                children: [
                    {
                        path: 'create-gene',
                        component: GeneListComponent
                    },
                    {
                        path: 'create-clinical-notes',
                        component: ClinicalNotesComponent
                    },
                    {
                        path: 'audit-trail',
                        component: AuditTrailComponent
                    },
                    {
                        path: 'medixcel',
                        component: MedixcelComponent
                    }
                ]
            },
            {
                path: 'report-template/:analysis_id/:report_id/:draft',
                component: ReportTemplateComponent
            },
            {
                path: 'purple-template/:analysis_id/:report_id/:draft',
                component: DevelopedPurpleReportComponent
            },
            {
                path: 'process-analysis',
                component: ProcessAnalysisComponent
            },
            {
                path: 'user-management',
                component: UserManagementComponent,
                children: [
                    {
                        path: 'clients',
                        component: ClientsComponent
                    },
                    {
                        path: 'roles',
                        component: RolesComponent
                    },
                    {
                        path: 'users',
                        component: UsersComponent
                    }
                ]
            }, {
                path: 'clinical-report',
                component: ClinicalReportComponent,
                children: [
                    {
                        path: 'report-module',
                        component: ReportModuleComponent
                    }, {
                        path: 'purple-module',
                        component: PurpleReportComponent
                    },
                    {
                        path: 'new-purple/:template_id',
                        component: NewPurpleReportComponent
                    }
                ]
            },
            {
                path: 'master-gene',
                component: MasterGeneComponent
            },
            {
                path: 'master-variant',
                component: MasterVariantComponent
            }
        ]
    }
];
