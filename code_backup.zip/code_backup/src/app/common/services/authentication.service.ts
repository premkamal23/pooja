import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AuthenticationService {
  logoutURL = '/api/user/auditLogout';

  constructor(
    private http: HttpClient) {
    // required for login logout functionality
  }

  logout() {
    const time = new Date().getTime();
    const data = {
      logged_out_time: time,
      id: sessionStorage.getItem('response_id'),
      username: sessionStorage.getItem('user'),
      user_email: sessionStorage.getItem('email')
    };
    return this.http.post(this.logoutURL, data);
  }

  validateUserDetails(username, password, logged_in_time) {
    const data = {
      user_email: username,
      password: password,
      logged_in_time: logged_in_time
    };
    return this.http.post('/api/auth/login', data);
  }
}
