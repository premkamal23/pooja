import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { AuthenticateService } from './authenticate.service';

@Injectable()
export class AuthenticateGuardService implements CanActivate {

  constructor(
    private authService: AuthenticateService
    ) { }

  canActivate() {
    return this.authService.status !== 401;
  }

}
