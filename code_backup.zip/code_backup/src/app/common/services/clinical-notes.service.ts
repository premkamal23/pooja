import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ClinicalNotesService {

  constructor(
    private http: HttpClient
  ) { }

  getEditClinicalNotesById(notes_id) {
    return this.http.get('/api/clinicalNote/' + notes_id);
  }

  getAllClinicalNotes(sortBy, sortDir, offset, limit, filterPayload) {
    return this.http.post('/api/allClinicalNotes' + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit, filterPayload);
  }

  saveClinicalNotes(dataObj, flag) {
    return this.http.put('/api/clinicalNote/'+ flag, dataObj);
  }

  deleteClinicalNotes(note_id) {
    return this.http.delete('/api/deleteClinicalNote/' + note_id);
  }

  editClinicalNotes(dataObj, flag) {
    return this.http.post('/api/clinicalNote/'+ flag, dataObj);
  }

  getClinicalNotes() {
    return this.http.get('/api/allAvailableClinicalNotes');
  }
}
