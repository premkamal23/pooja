import { Injectable } from '@angular/core';

@Injectable()
export class AuthenticateService {

  msg: string;
  status: number;
  constructor() { 
    // required for the entry level check in the application
  }
}
