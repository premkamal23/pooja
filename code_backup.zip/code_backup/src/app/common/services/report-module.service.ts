import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ReportModuleService {

  constructor(
    private http: HttpClient
  ) { }

  getReportSections() {
    return this.http.get('/api/reportSections');
  }

  getAllReportData(sortBy, sortDir, offset, limit, filterPayload) {
    return this.http.post('/api/allTemplates' + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit, filterPayload);
  }

  saveReportTemplate(dataObj) {
    return this.http.post('/api/reportTemplate', dataObj);
  }

  deleteReportTemplate(template_id) {
    return this.http.delete('/api/deleteReportTemplate/' + template_id);
  }

  editReportTemplate(dataObj) {
    return this.http.put('/api/reportTemplate/', dataObj);
  }

  geteditReportSections(template_id) {
    return this.http.get('/api/template/' + template_id);
  }

  checkTestId(analysis_id) {
    return this.http.get('/api/check_for_test_template/' + analysis_id);
  }

  checkPurpleTestId(analysis_id) {
    return this.http.get('/api/purple_check_for_test_template/' + analysis_id);
  }

  checkAvailableSections(analysis_id) {
    return this.http.get('/api/variants_sections_applicable/' + analysis_id);
  }

  checkAvailablePurpleSections(analysis_id) {
    return this.http.get('/api/purple_variants_sections_applicable/' + analysis_id);
  }

  getSectionForReport(analysis_id) {
    return this.http.get('/api/variants_sections/' + analysis_id);
  }


  // Purple reports api

  getSections() {
    return this.http.get('/api/purpleReportSections');
  }

  getReportData(sortBy, sortDir, offset, limit, filterPayload) {
    return this.http.post('/api/allPurpleTemplates' + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit, filterPayload);
  }

  deleteReport(id) {
    return this.http.delete('/api/deletePurpleTemplate/' + id);
  }

  saveReportData(reportData) {
    return this.http.put('/api/purpleTemplate', reportData);
  }

  getEditedReportData(template_id) {
    return this.http.get('/api/purpleTemplate/' + template_id);
  }

  saveEditedReportData(reportData) {
    return this.http.post('/api/purpleTemplate', reportData);
  }


  checkReportType(analysis_id) {
    return this.http.post('/api/reportTemplateType/' + analysis_id, {});
  }

}
