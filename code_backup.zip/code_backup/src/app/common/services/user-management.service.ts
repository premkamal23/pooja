import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserManagementService {

  constructor(
    private http: HttpClient
  ) { }

  // clients Api..
  getAllClientsPages(sortBy, sortDir,offset, limit) {
    return this.http.get('/api/client/all?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit);
  }

  getAllClientsSearch(sortBy, sortDir,offset, limit, searchOptions) {
    return this.http.get('/api/client/all?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit + '&name=' + searchOptions);
  }

  getAllClients() {
    return this.http.get('/api/client/all');
  }

  getAllActivatedClients() {
    return this.http.get('/api/client/user/all');
  }

  createClient(client_name, folders) {
    const clientDetails = {
      'name': client_name,
      'folderNames': folders
    };
    return this.http.put('/api/client', clientDetails);
  }

  deleteClient(client_id) {
    return this.http.delete('/api/client/' + client_id);
  }

  editClient(client_id, client_name, folders, status) {
    const clientDetails = {
      'name': client_name,
      'folderNames': folders,
      'active': status
    };
    return this.http.post('/api/client/' + client_id, clientDetails);
  }

  getAllFolders() {
    return this.http.get('/api/folder/all');
  }

  getAllUsers(offset, limit, sortBy, sortDir, data) {
    return this.http.post('/api/user/all?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit, data);
  }

  createUser(first_name, last_name, email, role_id, password, confirm_password, designation, client_list) {
    const userDetails = {
      'first_name': first_name,
      'last_name': last_name,
      'email': email,
      'role_id': role_id,
      'password': password,
      'confirm_password': confirm_password,
      'designation': designation,
      'client_ids': client_list
    };
    return this.http.put('/api/user/sign-up', userDetails);
  }

  deleteUSer(user_id) {
    return this.http.delete('/api/user/' + user_id);
  }

  resetPassword(user_id, password, confPassword) {
    const passwordDetails = {
      'reset_password': password,
      'confirm_reset_password': confPassword

    };
    return this.http.post('/api/auth/reset/' + user_id, passwordDetails);
  }

  editUser(user_id, first_name, last_name, email, role_id, designation, active, client_ids) {
    const userDetails = {
      'user_id': user_id,
      'first_name': first_name,
      'last_name': last_name,
      'email': email,
      'role_id': role_id,
      'designation': designation,
      'active': active,
      'client_ids': client_ids
    };
    return this.http.post('/api/user/' + user_id, userDetails);
  }

  addUser(user_id, email, old_password, new_password, confirm_password) {
    const userDetails = {
      'user_id': user_id,
      'email': email,
      'old_password': old_password,
      'new_password': new_password,
      'confirm_password': confirm_password
    };
    return this.http.post('/api/auth/update/' + user_id, userDetails);
  }

  getAllpermissions() {
    return this.http.get('/api/permission/all');
  }

  getAllRolesForClient(offset, limit, sortBy, sortDir) {
    return this.http.get('/api/role/all?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit);
  }

  getAllRoles() {
    return this.http.get('/api/role/all');
  }

  getAllRolesForClientSearch(offset, limit, sortBy, sortDir, name, searchOption) {
    return this.http.
      get('/api/role/all?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit + '&name=' + searchOption);
  }

  createRole(role_name, permission_list) {
    const roleDetails = {
      'name': role_name,
      'permission_ids': permission_list

    };
    return this.http.put('/api/role', roleDetails);
  }

  deleteRole(role_id) {
    return this.http.delete('/api/role/' + role_id);
  }

  updateRole(role_id, name, permission_ids) {
    const userDetails = {
      'name': name,
      'permission_ids': permission_ids
    };
    return this.http.post('/api/role/' + role_id, userDetails);
  }
}
