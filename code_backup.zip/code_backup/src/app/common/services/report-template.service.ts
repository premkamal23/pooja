import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ReportTemplateService {

    constructor(private http: HttpClient) { }

    // draft, approve, release
    saveAsDraft(data) {
        return this.http.post('/api/saveDraft', data);
    }

    draftPurpleReport(data) {
        return this.http.post('/api/savePurpleDraft', data);
    }
    generatePDF(id) {
        return this.http.post('/api/generatePdf/' + id, {});
    }

    generatePurplePdf(report_id) {
        return this.http.post('/api/generatePdfPurple/' + report_id, {});
    }

    getDraftData(id) {
        return this.http.get('/api/savedDraftReport/' + id);
    }

    getPurpleDraftData(report_id) {
        return this.http.get('/api/savedDraftPurpleReport/' + report_id)
    }

    previewReport(id) {
        return this.http.get('/api/previewPdf', id);
    }

    downloadPdf(name) {
        return this.http.get(('/api/pathReportPdf/' + name));
    }

    getReleasedPdf(id) {
        return this.http.get(('/api/previewPdf/' + id));
    }


    checkForOnHold(id) {
        return this.http.get('/api/isHoldReport/' + id);
    }

    getDataBasedOnTemplate(analysis_id, data) {
        return this.http.post('/api/default_report/' + analysis_id, data);
    }

    getPurpleDataBasedOnTemplate(analysis_id, data) {
        return this.http.post('/api/purple_new_report_for_analysis/' + analysis_id, data);
    }

    previewNewReport(reportData) {
        return this.http.post('/api/generate_pdf_from_request', reportData);
    }

    previewPurpleReport(reportData) {
        return this.http.post('/api/generate_purple_pdf_from_request', reportData);
    }

    getApproversList(client_id) {
        return this.http.get('/api/user/client/' + client_id + '/approve');
    }

    saveApproverList(report_id, approvalToAdd) {
        return this.http.post('/api/saveSignature/' + report_id, approvalToAdd);
    }

    updatePurpleApprovers(report_id, approvals) {
        return this.http.post('/api/savePurpleReportSignature/' + report_id, approvals);
    }

    deleteApproverFromList(report_id, approverId) {
        return this.http.delete('/api/deleteSignature/' + report_id + '/' + approverId);
    }

    deleteApprovalsPurple(report_id, approverId) {
        return this.http.delete('/api/deletePurpleReportSignature/' + report_id + '/' + approverId);
    }

    updateMedStatus(report_id, status) {
        return this.http.post('/api/report/' + report_id + '/update_send_to_medixcel/' + status, {});
    }
}
