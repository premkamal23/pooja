import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class MedixcelService {

  constructor(
    private httpClient: HttpClient
  ) { }

  getAllMediReports(sortBy, sortDir, offset, limit, data) {
    return this.httpClient.post('/api/medixcel_report_audit_list?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit, data);
  }
}
