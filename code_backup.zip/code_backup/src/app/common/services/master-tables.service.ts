import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class MasterTablesService {

  constructor(
    private http: HttpClient
  ) { }

  getVariantData(column_name, sort_dir, offset, limit) {
    return this.http.
      get('/api/master/variants?sortBy=' + column_name + '&sortDir=' + sort_dir + '&offset=' + offset + '&limit=' + limit);
  }

  getFilteredData(column_name, sort_dir, offset, limit, request_data) {
    return this.http.
      post('/api/master/variantsFilter?sortBy=' + column_name + '&sortDir=' + sort_dir + '&offset=' + offset + '&limit=' + limit,
        request_data);
  }

  getGeneData(column_name, sort_dir, offset, limit) {
    return this.http.post('/api/genesFilter?sortBy=' + column_name + '&sortDir=' + sort_dir + '&offset=' + offset + '&limit=' + limit, {});
  }

  getOtherAnalysesDetails(id, sortBy, sort_dir, offset, limit, data) {
    return this.http.post('/api/analysesByVariant/' + id + '?sortBy=' + sortBy + '&sortDir=' + sort_dir + '&offset=' + offset + '&limit=' + limit, data);
  }

  getFilteredGeneData(column_name, sort_dir, offset, limit, request_data) {
    return this.http.
      post('/api/genesFilter?sortBy=' + column_name + '&sortDir=' + sort_dir + '&offset=' + offset + '&limit=' + limit,
        request_data);
  }

  getVariantByGene(gene, sortBy, sort_dir, offset, limit, request_data) {
    return this.http.post('/api/variantsByGene/' + gene + '?sortBy=' + sortBy + '&sortDir=' + sort_dir + '&offset=' + offset + '&limit=' + limit,
      request_data);
  }

  getGeneByVariant(gene_name) {
    return this.http.get('/api/gene/' + gene_name);
  }

  getVariantfromGene(variant_name) {
    return this.http.get('/api/master/variant/' + variant_name);
  }

  addVariantToMaster(data) {
    return this.http.post('/api/master/addMasterVariant', data);
  }

  getAllValueFields() {
    return this.http.get('/api/masterVariant/allFields');
  }
}
