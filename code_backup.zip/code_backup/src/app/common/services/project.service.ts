import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class ProjectService {
    headers: HttpHeaders;
    constructor(private http: HttpClient) {
    }

    getData(client_ids, sortBy, sortDir, search, offset, limit) {
        const postBody = {
            client_ids: client_ids,
            searchReq: search
        }
        return this.http.post('/api/dashboardPrimeNG' + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit, postBody);
    }

    getfileData(client_id, vcf, offset, limit, sortBy, sortDir, clientDetails) {
        return this.http.post('/api/browseNew/' + client_id + '/' + vcf + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit, clientDetails);
    }

    getRefreshedFileData(client_id, vcf, offset, limit, sortBy, sortDir) {
        return this.http.get('/api/browseNew/refresh/' + client_id + '/' + vcf + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit);
    }

    getfileName() {
        return this.http.get('/api/projects');
    }

    getClientName(clientName) {
        return this.http.get('/api/clientProjects/' + clientName);
    }

    getProjectName(client_ids, projectName) {
        const client_data = {
            'client_ids': client_ids
        };
        return this.http.post('/api/client/project/' + projectName, client_data);
    }

    getClientDetails(clientName) {
        return this.http.get('/api/client/' + clientName + '/project/all');
    }

    deleteAnalysis(url) {
        return this.http.delete(url);
    }

    checkForInProgressAnalysis() {
        return this.http.get('/api/analysis/isRunning');
    }

    createNewAnalysis(vcf, data) {
        return this.http.post('/api/createAnalysis' + '?vcf=' + vcf, data);
    }

    getUsersForClient(client_id) {
        return this.http.get('/api/user/client/' + client_id);
    }

    updateAnalysis(analysis_id, owner, email) {
        const data = {
            'analysisId': analysis_id,
            'ownerName': owner,
            'email': email
        };
        return this.http.post('/api/update-analysis/' + analysis_id, data);
    }

    exportToJson(report_id) {
        return this.http.get('/api/exportClinicalReport/' + report_id);
    }

    exportToJsonPurple(report_id, report_name) {
        return this.http.get('/api/exportClinicalReport/' + report_id + '/report?report_name=' + report_name);
    }

    editComments(analysis_id, data) {
        return this.http.post('/api/update-analysis/comments/' + analysis_id, data);
    }

    getPKIClass() {
        return this.http.get('/api/variant/pkiClassifications');
    }

    getauditTrail(data) {
        return this.http.post('/api/variant/auditTrails', data);
    }

    getalluserforAudit() {
        return this.http.get('/api/user/usersForAuditSearch');
    }

    getUserAudit(data) {
        return this.http.post('/api/user/loginAuditSearch', data);
    }

    getVariantAudit(data) {
        return this.http.post('/api/master/auditTrail', data);
    }

    getReportAudit(data) {
        return this.http.post('/api/autoReportAuditData', data);
    }

    getLogoDetails(offset, limit) {
        return this.http.get('/api/logo_file_list' + '?offset=' + offset + '&limit=' + limit);
    }

    getAnalysisClassification() {
        return this.http.get('/api/analysis-status-list');
    }

    updateAnalysisFlag(id, data) {
        return this.http.post('/api/update-analysis-status/' + id, data);
    }


    // auto reporting apis

    getFilterData() {
        return this.http.post('/api/analysisFilterData', {});
    }

    validateBeforeReport(offset, limit, sortBy, sortDir, client_ids, analysisIds, approver) {
        let data = {
            client_ids: client_ids,
            analysisIds: analysisIds,
            approver: approver
        };
        return this.http.post('/api/autoReportValidations' + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit, data);
    }

    generateBulkReport(client_ids, analysisIds, approver) {
        let data = {
            client_ids: client_ids,
            analysisIds: analysisIds,
            approver: approver
        };
        return this.http.post('/api/autoReport', data);
    }

    applyAnalysisFilter(sortBy, sortDir, offset, limit, client_ids, searchReq, analysisData) {
        let data = {
            client_ids: client_ids,
            searchReq: searchReq,
            analysisFilterData: {
                allClients: analysisData.allClients,
                pki_class_status_values: analysisData.pki_class_status_values,
                statusList: analysisData.statusList,
                types: analysisData.types,
                owners: analysisData.owners
            }
        }
        return this.http.post('/api/dashboardPrimeNG' + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit, data);
    }

    addVariant(data) {
        return this.http.post('/api/variant', data);
    }

    getTableContent(sortBy, sortDir, offset, limit, exportAll, requestbody) {
        return this.http.post('/api/analysisExportData' + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit + '&exportAll=' + exportAll, requestbody);
    }

    getStatusList() {
        return this.http.get('/api/getManualAnalysisStaus');
    }

    updateStatus(analysis_id, status) {
        return this.http.post('/api/updateManualStatus/' + analysis_id + '/' + status, {});
    }
}
