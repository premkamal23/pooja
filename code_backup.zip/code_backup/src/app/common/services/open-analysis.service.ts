import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class OpenAnalysisService {
    isEditFilter = false;
    gridVariantData = [];
    onHoldFlag = false;

    private messageSource = new BehaviorSubject({});
    currentMessage = this.messageSource.asObservable();

    constructor(
        private httpClient: HttpClient
    ) { }

    changeMessage(message: any) {
        this.messageSource.next(message)
    }

    checkIfOnHoldReport() {
        let hold = false;
        for (let i = 0; i < this.gridVariantData.length; i++) {
            if (this.gridVariantData[i].hold_report) {
                hold = true;
                break;
            }
        }
        return hold;
    }
    enableOnHoldFlag() {
        this.onHoldFlag = true;
    }
    disableOnHoldFlag() {
        this.onHoldFlag = false;
    }
    getOnHoldFlag() {
        return this.onHoldFlag;
    }

    getJbrowseLink(data) {
        return this.httpClient.get('/api/jBrowse?analysisId=' + data.analysisId + '&chrom=' + data.chrom + '&start=' + data.genomic_start + '&stop=' + data.genomic_stop);
    }
    deleteFilter(id) {
        return this.httpClient.delete('/api/filter/?name=' + id);
    }

    setIsEditFilter() {
        this.isEditFilter = true;
    }
    checkIfIsEditFilter() {
        return this.isEditFilter;
    }
    unSetIsEditFilter() {
        this.isEditFilter = false;
    }
    getOmimData(data) {
        return this.httpClient.get('/api/omim/' + data);
    }

    getOtherAnalysesDetails(id, offset, limit, sortBy, sortDir, data) {
        return this.httpClient.post('/api/analysesByVariant/' + id + '?sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit , data, {});
    }

    getSubTypeData(location) {
        return this.httpClient.get('/api/subTypes/' + location);
    }

    markVariantsAsHiddden(analysis_id, variants_ids) {
        const variantsData = {
            'analysis_id': analysis_id,
            'variantIds': variants_ids
        }
        return this.httpClient.post('/api/hideVariants', variantsData);
    }

    markVariantsAsUnhide(analysis_id) {
        return this.httpClient.post('/api/unhideVariants/' + analysis_id, {});
    }

    getHiddenDataCount(id, gene_class, location, sub_type) {
        return this.httpClient.post('/api/hiddenVariantsDetails?analysis_id=' + id + '&gene_class=' + gene_class + '&location=' + location + '&sub_type=' + sub_type + '&is_Show_As_Hidden=false', {});
    }

    checkforSampleFilter(analysis_id) {
        return this.httpClient.get('/api/checkIfSampleFilter/' + analysis_id);
    }

    getPayloadForSampleFilter(analysis_id) {
        return this.httpClient.get('/api/sampleFilter/' + analysis_id);
    }

    getHiddenVariantCount(url, id, gene_class, location, sub_type, sortBy, sortDir, offset, limit, data) {
        return this.httpClient.post(url + '?analysis_id=' + id + '&gene_class=' + gene_class + '&location=' + location + '&sub_type=' + sub_type + '&sortBy=' + sortBy + '&sortDir=' + sortDir + '&offset=' + offset + '&limit=' + limit + '&is_Show_As_Hidden=true', data);
    }

    getVariantForReport(analysis_id) {
        const data = {
            marked_for_report: true
        };
        return this.httpClient.post('/api/variants?analysis_id=' + analysis_id + '&sub_type=00', data);
    }

    updateSampleNotes(id, comments) {
        const request_body = {
            comment: comments
        };
        return this.httpClient.post('/api/update-analysis-comment/' + id, request_body);
    }

    saveRefiningFilter(filter_payload) {
        return this.httpClient.post('/api/filter', filter_payload);
    }

    editRefiningFilter(filter_payload) {
        return this.httpClient.put('/api/filter', filter_payload);
    }

    unselectHiddenVariants(analysis_id, variants_ids) {
        const variantsData = {
            'analysis_id': analysis_id,
            'variantIds': variants_ids
        }
        return this.httpClient.post('/api/variant/deselectShowHidden', variantsData);
    }

    getGeneList() {
        return this.httpClient.get('/api/genes_list');
    }

    deselectSingleVariant(analysis_id, chromStartStopRef) {
        const data = {
            'analysis_id': analysis_id,
            'variantIds': [chromStartStopRef]
        }
        return this.httpClient.post('/api/variant/deselectSingleShowHidden', data);
    }

    deleteSampleFilter(analysis_id) {
        return this.httpClient.delete('/api/deleteSampleFilter/' + analysis_id);
    }

    updateVariant(data) {
        return this.httpClient.post('/api/updateVariant', data);
    }

    getFilters(analysis_id) {
        return this.httpClient.get('/api/allFilters/' + analysis_id);
    }
}
