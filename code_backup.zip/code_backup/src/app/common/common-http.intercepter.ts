import { Injectable } from '@angular/core';
import {
    HttpEvent,
    HttpInterceptor,
    HttpHandler,
    HttpRequest,
    HttpResponse,
    HttpErrorResponse
} from '@angular/common/http';
import { AuthenticateService } from '../common/services/authenticate.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/do'
import { AuthenticationService } from '../common/services/authentication.service';

@Injectable()
export class CommonHttpInterceptor implements HttpInterceptor {
    msg: string;
    constructor(
        private router: Router,
        private auth: AuthenticateService,
        private service: AuthenticationService
    ) {

    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const reqClone = req.clone({
            //url: `http://10.53.18.133:8080` + req.url,
            url: `http://pts00051:8080` + req.url,
            // url: req.url,
            setHeaders: req.url.endsWith('login')
                ? { 'Content-Type': 'application/json' }
                : req.url.endsWith('geneFile')
                    ? { 'Authorization': sessionStorage.getItem('Authorization') }
                    : req.url.endsWith('auditLogout') ? { 'Content-Type': 'application/json' }
                        : { 'Authorization': sessionStorage.getItem('Authorization'), 'Content-Type': 'application/json' }
        });
        return next.handle(reqClone).do((event: HttpEvent<any>) => {
            if (event instanceof HttpResponse) {
                this.auth.status = event.status;
            }
        }, (error: any) => {
            if (error instanceof HttpErrorResponse) {
                this.auth.status = error.status;
                this.auth.msg = error.error.message;
                if (error.status === 401) {
                    this.service.logout().subscribe((response: any) => {
                        sessionStorage.removeItem('Authorization');
                        sessionStorage.removeItem('user');
                        sessionStorage.removeItem('user_id');
                        sessionStorage.removeItem('designation');
                        sessionStorage.removeItem('sessionFilters');
                        sessionStorage.removeItem('permissions');
                        sessionStorage.removeItem('clients');
                        sessionStorage.removeItem('anaysisFilters');
                        sessionStorage.removeItem('response_id');
                        this.router.navigate(['/login']);
                    });
                }
            }
        });
    }
}
